"""
core/pipeline.py – FlakyGuard's three nested fixing loops.

Paper §III-C:
  Outer loop  (M iterations): rebuild context from scratch each time.
  Middle loop (P iterations): generate a high-level "thought" (root cause
                               + fixing plan) given the current context.
  Inner loop  (N iterations): produce, apply, and validate a concrete patch
                               for each thought.

The first patch that passes build + test validation is saved and returned.
"""

from __future__ import annotations
import logging
import os

from core.types import TestInput, FlakyInfo, Context, Fix
from core.prompts import make_thought_prompt, make_fix_prompt
from analysis.graph import CallGraphBuilder, files_near_test
from analysis.smart_search import smart_bfs
from editing.search_replace import apply_fix, revert_all, parse_fix, write_patch_file
from utils.llm import complete
from utils.runner import validate_fix
from utils.simplifier import simplify_test, extract_test_func

logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
)


# ── Context collection ────────────────────────────────────────────────────────

def collect_context(
    test_input: TestInput,
    flaky_info: FlakyInfo,
    k: int = 3,
    depth_limit: int = -1,
    max_funcs: int = 5,
) -> Context:
    """
    Build the call graph for files near the test and run smart BFS
    to collect the most relevant function nodes.

    Returns a Context with func_nodes and imports.
    """
    test_file_abs = os.path.join(test_input.repo_root, test_input.test_file)

    # Files in scope: sibling + parent directories of the test file
    scope_files = files_near_test(test_file_abs, up_levels=2, language=test_input.language)
    # Always include the test file itself
    if test_file_abs not in scope_files:
        scope_files.append(test_file_abs)

    # Build the static call graph
    builder = CallGraphBuilder(test_input.repo_root, scope_files, language=test_input.language)
    graph = builder.build()

    problem_statement = (
        f"Flaky test '{test_input.test_func}/{test_input.test_case}'. "
        f"Error: {flaky_info.error[:300]}"
    )

    # Smart BFS starting from the test function
    relevant_nodes = smart_bfs(
        graph=graph,
        start_funcs=[test_input.test_func],
        problem_statement=problem_statement,
        k=k,
        depth_limit=depth_limit,
        F=max_funcs,
        callee_only=True,
    )

    # Extract imports from each file
    imports: dict[str, str] = {}
    for fd in relevant_nodes:
        fp = fd.filepath
        if fp not in imports:
            imports[fp] = _extract_imports(fp, test_input.language)

    ctx = Context(func_nodes=relevant_nodes, imports=imports)
    logger.info("Context: %d function nodes from %d files",
                len(ctx.func_nodes), len({f.filepath for f in ctx.func_nodes}))
    return ctx


def _extract_imports(filepath: str, language: str) -> str:
    """Extract the import block from a source file (simple regex approach)."""
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            source = f.read()
    except OSError:
        return ""

    lang = language.lower()
    if lang == "go":
        import re
        m = re.search(r'import\s*\(([^)]*)\)', source, re.DOTALL)
        if m:
            return "import (\n" + m.group(1) + ")\n"
        # single-line import
        m2 = re.search(r'import\s+"[^"]+"', source)
        return m2.group(0) if m2 else ""
    elif lang == "python":
        import re
        lines = source.splitlines()
        import_lines = [l for l in lines if l.startswith("import ") or l.startswith("from ")]
        return "\n".join(import_lines)
    return ""


def _format_context(context: Context) -> str:
    """Format context nodes into a string for the LLM prompt."""
    sections: list[str] = []
    seen_files: set[str] = set()

    for fd in context.func_nodes:
        fp = fd.filepath
        if fp not in seen_files:
            seen_files.add(fp)
            imp = context.imports.get(fp, "")
            if imp:
                sections.append(f"=== {fp} (imports) ===\n{imp}\n")

        sections.append(f"=== {fp} ===\n{fd.source}\n")

    return "\n".join(sections)


# ── Thought generation ────────────────────────────────────────────────────────

def generate_thought(
    test_input: TestInput,
    flaky_info: FlakyInfo,
    context: Context,
    failed_thoughts: list[str],
) -> str:
    """Generate a root-cause + fixing-plan thought using the LLM."""
    prompt = make_thought_prompt(
        language=test_input.language,
        test_func=test_input.test_func,
        test_case=test_input.test_case,
        error=flaky_info.error,
        error_trace=flaky_info.error_trace,
        context=_format_context(context),
        failed_thoughts=failed_thoughts if failed_thoughts else None,
    )
    thought = complete(prompt, temperature=0.1)
    logger.info("Thought: %s", thought[:120].replace("\n", " "))
    return thought


# ── Fix generation ────────────────────────────────────────────────────────────

def generate_fix(
    test_input: TestInput,
    flaky_info: FlakyInfo,
    context: Context,
    thought: str,
) -> Fix | None:
    """Ask the LLM to produce a concrete patch given the thought."""
    test_file_abs = os.path.join(test_input.repo_root, test_input.test_file)
    try:
        with open(test_file_abs, "r", encoding="utf-8", errors="replace") as f:
            file_source = f.read()
    except OSError:
        logger.error("Cannot read test file: %s", test_file_abs)
        return None

    original_test = extract_test_func(file_source, test_input.test_func, test_input.language) or file_source
    simplified_test = simplify_test(original_test, test_input.test_case, test_input.language)

    prompt = make_fix_prompt(
        language=test_input.language,
        test_func=test_input.test_func,
        test_case=test_input.test_case,
        simplified_test=simplified_test,
        original_test=original_test,
        error=flaky_info.error,
        error_trace=flaky_info.error_trace,
        context=_format_context(context),
        thought=thought,
    )
    response = complete(prompt, temperature=0.1)
    fix = parse_fix(response, default_filepath=test_input.test_file)
    if not fix.edits:
        logger.warning("LLM produced no SEARCH/REPLACE edits.")
        return None
    return fix


# ── Main pipeline ─────────────────────────────────────────────────────────────

def run_pipeline(
    test_input: TestInput,
    flaky_info: FlakyInfo,
    M: int = 3,    # outer: context collection attempts
    P: int = 2,    # middle: thoughts per context
    N: int = 3,    # inner: fix attempts per thought
    k: int = 3,    # smart BFS children per node
    depth_limit: int = -1,
    max_funcs: int = 5,
    output_dir: str = "patches",
    validation_runs: int = 10,
) -> tuple[bool, str]:
    """
    FlakyGuard's three-loop fixing pipeline.

    Returns:
        (True,  explanation)  if a fix was found and validated.
        (False, error_msg)    if no fix was found within the budget.
    """
    failed_thoughts: list[str] = []

    for m_iter in range(1, M + 1):
        logger.info("─── Outer loop %d/%d: collecting context ───", m_iter, M)
        try:
            context = collect_context(
                test_input, flaky_info, k=k,
                depth_limit=depth_limit, max_funcs=max_funcs,
            )
        except Exception as exc:
            logger.error("Context collection failed: %s", exc)
            context = Context()  # empty context – still try with just the test

        for p_iter in range(1, P + 1):
            logger.info("  Middle loop %d/%d: generating thought", p_iter, P)
            thought = generate_thought(test_input, flaky_info, context, failed_thoughts)

            for n_iter in range(1, N + 1):
                logger.info("    Inner loop %d/%d: generating fix", n_iter, N)
                fix = generate_fix(test_input, flaky_info, context, thought)
                if fix is None:
                    continue

                # Apply fix
                ok, result = apply_fix(fix, test_input.repo_root)
                if not ok:
                    logger.warning("    Apply failed: %s", result)
                    continue

                backups = result  # type: ignore[assignment]

                # Validate fix
                passed = validate_fix(test_input, runs=validation_runs)
                if passed:
                    # Save patch and revert source tree
                    patch_path = write_patch_file(backups, output_dir,
                                                  prefix=test_input.test_func)
                    revert_all(backups)
                    logger.info("✓ Fix validated! Patch saved to: %s", patch_path)
                    return True, fix.explanation or "(no explanation)"
                else:
                    logger.info("    Validation failed – reverting")
                    revert_all(backups)

            # Record this thought as failed so the next thought avoids it
            failed_thoughts.append(thought[:300])

    return False, f"No fix found after {M}×{P}×{N} = {M*P*N} attempts."
