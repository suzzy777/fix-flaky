"""
core/types.py – shared dataclasses for FlakyGuard Simple.

These mirror the paper's concepts closely:
  TestInput  – what the user provides
  FlakyInfo  – captured failure details (error, trace, location)
  Context    – relevant functions collected by smart graph search
  Fix        – LLM-generated patch (search/replace edits + explanation)
"""

from __future__ import annotations
import dataclasses
from typing import Optional


@dataclasses.dataclass
class TestInput:
    """Everything needed to locate and run the flaky test."""
    repo_root: str          # absolute path to repository root
    test_file: str          # path to the test file (relative to repo_root)
    test_func: str          # e.g. "TestAddProgram"
    test_case: str          # e.g. "validation and call UpdateInfo"
    language: str = "go"    # "go" | "python" | "java"
    # How to run the test – a shell command template.
    # Use {test_file} and {test_func} as placeholders.
    run_cmd: str = "go test -v -run {test_func} ./{test_dir}/..."
    # How many times to run during reproduction / validation
    repro_runs: int = 100


@dataclasses.dataclass
class FlakyInfo:
    """Captured details of a reproduced flaky failure."""
    error: str            # short error message / assertion failure
    error_trace: str      # full stack trace
    # File + line where the assertion / error was raised
    error_file: str = ""
    error_line: int = 0


@dataclasses.dataclass
class FuncNode:
    """
    A function definition extracted from source code.
    Mirrors a tree-sitter node; kept as plain text for portability.
    """
    name: str
    filepath: str          # absolute path
    start_line: int
    end_line: int
    source: str            # full function source text


@dataclasses.dataclass
class Context:
    """
    Code context collected by smart graph search.
    Maps filepath -> list of relevant FuncNodes in that file.
    """
    func_nodes: list[FuncNode] = dataclasses.field(default_factory=list)
    imports: dict[str, str] = dataclasses.field(default_factory=dict)  # filepath -> import block


@dataclasses.dataclass
class SearchReplaceEdit:
    """One SEARCH/REPLACE block produced by the LLM."""
    filepath: str
    search_text: str
    replace_text: str


@dataclasses.dataclass
class Fix:
    """A proposed fix: a set of search/replace edits + explanation."""
    edits: list[SearchReplaceEdit]
    explanation: str = ""
