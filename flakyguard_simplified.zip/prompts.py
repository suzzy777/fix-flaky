"""
core/prompts.py – all LLM prompt templates for FlakyGuard Simple.

Keeping prompts in one file makes them easy to compare, tune, or
replace for ablation studies.
"""

from __future__ import annotations

# ── Output format ─────────────────────────────────────────────────────────────

SEARCH_REPLACE_FORMAT = """\
## Output Format

Produce fixes as SEARCH/REPLACE blocks.  For each change:

1. Write the target file path on its own line (relative to repo root).
2. Open a fenced code block.
3. Mark the original code with `<<<<<<< SEARCH`, then `=======`, then the
   replacement with `>>>>>>> REPLACE`.
4. Close the fence.

Example:

src/service_test.go
```go
<<<<<<< SEARCH
    result := doThing()
    assert.Equal(t, expected, result)
=======
    result := doThing()
    require.Eventually(t, func() bool {
        return doThing() == expected
    }, 2*time.Second, 10*time.Millisecond)
>>>>>>> REPLACE
```

After the blocks, wrap a brief root-cause explanation in:
<EXPLANATION>
What caused the flakiness and how the fix addresses it.
</EXPLANATION>

Rules:
- Only modify TEST code, not production code (unless clearly buggy).
- The SEARCH block must match the original file exactly.
- Do not include surrounding context lines that you are not changing.
- Multiple SEARCH/REPLACE blocks are allowed.
"""

# ── Thought / root-cause prompt ───────────────────────────────────────────────

THOUGHT_PROMPT_TEMPLATE = """\
You are an expert at fixing flaky tests in {language}.

## Failing Test Information

Test function: {test_func}
Test case:     {test_case}

Error:
```
{error}
```

Stack trace:
```
{error_trace}
```

## Relevant Production Code (from call graph context)

{context}

## Task

Identify the root cause of the flakiness and propose a high-level fixing
strategy.  Respond with:

1. **Root cause category** (one of: schedule_randomness, map_iteration,
   timestamp_discrepancy, state_pollution, time_dependent, other)
2. **Root cause explanation** (2-4 sentences)
3. **Fixing plan** (concrete steps)

{failed_thoughts_section}
"""

FAILED_THOUGHTS_SECTION = """\
## Previously attempted strategies that FAILED (do not repeat):

{failed_thoughts}

Please propose a different strategy.
"""

# ── Fix prompt ────────────────────────────────────────────────────────────────

FIX_PROMPT_TEMPLATE = """\
You are an expert at fixing flaky tests in {language}.

## Failing Test Information

Test function:      {test_func}
Test case:          {test_case}

**Simplified test** (for reference – shows only the failing case):
```{language}
{simplified_test}
```

**Full original test** (edit this):
```{language}
{original_test}
```

Error:
```
{error}
```

Stack trace:
```
{error_trace}
```

## Relevant Production Code

{context}

## Root Cause Analysis

{thought}

## Common Flaky-Test Patterns

1. **Schedule randomness / goroutines** – unsynchronized goroutines; use
   WaitGroup, channels, or Eventually helpers.
2. **Random map iteration** – Go maps iterate in random order; sort before
   comparing, or use ElementsMatch.
3. **Timestamp discrepancy** – two `time.Now()` calls capture different
   instants; use a fixed time or compare with tolerance.
4. **State pollution** – global/env-var state shared between parallel tests;
   use `t.Setenv`, `t.Cleanup`, or per-test setup.
5. **Time-dependent** – wall-clock boundary conditions; shift time values
   to stay safely within bounds.

{output_format}
"""

# ── LLM-select prompt (used internally by smart_search) ──────────────────────

SELECT_PROMPT_TEMPLATE = """\
Problem: {problem_statement}

{current_func_section}

Select the {k} most relevant functions from the candidates below that are
likely involved in the flaky behavior.
Return ONLY their indices inside <INDICES> tags (comma-separated).

Candidates:
{candidates}

Example: <INDICES>0,2</INDICES>
"""

# ── Build-error fix prompt ────────────────────────────────────────────────────

BUILD_FIX_PROMPT_TEMPLATE = """\
You are an expert {language} developer.

The following code modification caused a build error.

Original file ({filepath}):
```{language}
{original}
```

Modified file (after applying the fix):
```{language}
{modified}
```

Build error:
```
{build_error}
```

Please produce a corrected version using SEARCH/REPLACE blocks so that the
file compiles without errors.  Only fix compilation errors; do not change
the intended logic.

{output_format}
"""


# ── Helper constructors ───────────────────────────────────────────────────────

def make_thought_prompt(
    language: str,
    test_func: str,
    test_case: str,
    error: str,
    error_trace: str,
    context: str,
    failed_thoughts: list[str] | None = None,
) -> str:
    failed_section = ""
    if failed_thoughts:
        joined = "\n\n".join(f"- {t}" for t in failed_thoughts)
        failed_section = FAILED_THOUGHTS_SECTION.format(failed_thoughts=joined)

    return THOUGHT_PROMPT_TEMPLATE.format(
        language=language,
        test_func=test_func,
        test_case=test_case,
        error=error,
        error_trace=error_trace,
        context=context,
        failed_thoughts_section=failed_section,
    )


def make_fix_prompt(
    language: str,
    test_func: str,
    test_case: str,
    simplified_test: str,
    original_test: str,
    error: str,
    error_trace: str,
    context: str,
    thought: str,
) -> str:
    return FIX_PROMPT_TEMPLATE.format(
        language=language,
        test_func=test_func,
        test_case=test_case,
        simplified_test=simplified_test,
        original_test=original_test,
        error=error,
        error_trace=error_trace,
        context=context,
        thought=thought,
        output_format=SEARCH_REPLACE_FORMAT,
    )
