# FlakyGuard Simple

A simplified, self-contained reimplementation of the FlakyGuard methodology
([Li et al., ASE 2025](https://doi.org/10.1109/ASE63991.2025.00179)) for use as a research baseline.

## Architecture

```
flakyguard_simple/
├── core/
│   ├── types.py          # Shared dataclasses (TestInput, FlakyInfo, Context, Fix)
│   ├── prompts.py        # All LLM prompt templates
│   └── pipeline.py       # Main fixing pipeline (outer/middle/inner loops)
├── analysis/
│   ├── graph.py          # Static call-graph builder (tree-sitter, language-agnostic)
│   └── smart_search.py   # LLM-guided BFS over the call graph
├── editing/
│   └── search_replace.py # SEARCH/REPLACE patch parsing and application
├── utils/
│   ├── llm.py            # Thin OpenAI/Anthropic wrapper with retries
│   ├── runner.py         # Test runner abstraction (pytest / go test / bazel)
│   └── simplifier.py     # Table-driven test simplification (Go/Python)
└── flakyguard.py         # CLI entry point
```

## Methodology

FlakyGuard addresses the **context problem** in LLM-based flaky-test repair:

1. **Reproduce** – run the test N times to capture a real failure + stack trace.
2. **Build call graph** – parse the codebase with tree-sitter into a static graph of
   function definitions and call references (filtered to files covered by the test).
3. **Smart BFS** – an LLM iteratively selects which callee nodes to expand, so only
   the most relevant functions (up to `F` total) are included in the prompt.
4. **Simplification** – for table-driven tests, strip out all sibling test cases so
   the LLM focuses only on the failing case.
5. **Fix loop** – nested loops (M × P × N) generate thoughts → patches →
   validate (build + re-run test). First passing patch is saved.

## Quick Start

```bash
pip install -r requirements.txt

# Set your LLM key
export OPENAI_API_KEY=sk-...   # or ANTHROPIC_API_KEY

# Fix a flaky test
python flakyguard.py \
  --repo /path/to/repo \
  --test-file src/service_test.go \
  --test-func TestAddProgram \
  --test-case "validation and call UpdateInfo" \
  --language go \
  --runner "go test ./..."
```

## Parameters (matching the paper)

| Flag | Default | Paper notation |
|------|---------|---------------|
| `--runs` | 100 | N (failure reproduction runs) |
| `--context-attempts` | 3 | M (outer loop) |
| `--thoughts` | 2 | P (middle loop) |
| `--fix-attempts` | 3 | N (inner loop) |
| `--max-funcs` | 5 | F (post-processing filter) |
| `--depth` | ∞ | d (BFS depth limit) |
| `--children-per-node` | 3 | k (children selected per node) |

## Requirements

```
openai>=1.0          # or anthropic>=0.25
tree-sitter>=0.22
tree-sitter-go       # for Go codebases
tree-sitter-python   # for Python codebases
tree-sitter-java     # for Java codebases
```
