"""
utils/runner.py – run tests and capture flaky failures.

The paper runs the test N times and extracts:
  - error message
  - stack trace
  - file + line of the failing assertion
"""

from __future__ import annotations
import os
import re
import subprocess
import logging
from core.types import TestInput, FlakyInfo

logger = logging.getLogger(__name__)


def _build_cmd(test_input: TestInput) -> str:
    """Expand the run_cmd template for the given test input."""
    test_dir = os.path.dirname(test_input.test_file)
    return test_input.run_cmd.format(
        test_func=test_input.test_func,
        test_case=test_input.test_case,
        test_file=test_input.test_file,
        test_dir=test_dir or ".",
    )


def _run_once(cmd: str, cwd: str, timeout: int = 120) -> tuple[bool, str]:
    """Run cmd, return (passed, combined_output)."""
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=cwd,
            capture_output=True, text=True, timeout=timeout,
        )
        output = result.stdout + result.stderr
        passed = result.returncode == 0
        return passed, output
    except subprocess.TimeoutExpired:
        return False, "TIMEOUT"


def _extract_flaky_info(output: str, test_input: TestInput) -> FlakyInfo | None:
    """
    Parse a test failure output into a FlakyInfo.
    Handles Go, Python (pytest), and Java (JUnit) output formats.
    """
    lang = test_input.language.lower()

    if lang == "go":
        return _parse_go_failure(output)
    elif lang == "python":
        return _parse_python_failure(output)
    elif lang == "java":
        return _parse_java_failure(output)
    else:
        # Generic fallback: just capture raw output
        if output.strip():
            return FlakyInfo(error=output[:500], error_trace=output)
        return None


# ── Go ──────────────────────────────────────────────────────────────────────

def _parse_go_failure(output: str) -> FlakyInfo | None:
    """Parse go test -v output for failure details."""
    if "FAIL" not in output and "panic" not in output:
        return None

    # Extract the error lines (lines starting with "--- FAIL" or assertion lines)
    error_lines: list[str] = []
    trace_lines: list[str] = []
    in_trace = False

    for line in output.splitlines():
        stripped = line.strip()
        if stripped.startswith("--- FAIL") or "Error:" in stripped or "FAIL\t" in stripped:
            error_lines.append(stripped)
        if re.match(r"\s+\S+\.go:\d+", line) or stripped.startswith("goroutine"):
            in_trace = True
        if in_trace:
            trace_lines.append(line)

    error = "\n".join(error_lines[:10]) or output[:300]
    trace = "\n".join(trace_lines[:40]) or ""

    # Try to extract file + line from first trace entry
    error_file, error_line = "", 0
    m = re.search(r"(\S+\.go):(\d+)", trace)
    if m:
        error_file, error_line = m.group(1), int(m.group(2))

    return FlakyInfo(
        error=error,
        error_trace=trace,
        error_file=error_file,
        error_line=error_line,
    )


# ── Python ───────────────────────────────────────────────────────────────────

def _parse_python_failure(output: str) -> FlakyInfo | None:
    """Parse pytest output for failure details."""
    if "FAILED" not in output and "ERROR" not in output and "assert" not in output.lower():
        return None

    # Capture the FAILURES section
    failure_section = ""
    m = re.search(r"={3,} FAILURES ={3,}(.*?)(?:={3,}|\Z)", output, re.DOTALL)
    if m:
        failure_section = m.group(1)

    error = ""
    em = re.search(r"(AssertionError.*|E\s+assert.*|Exception.*)", failure_section)
    if em:
        error = em.group(0)[:300]
    else:
        error = failure_section[:300] or output[:300]

    error_file, error_line = "", 0
    fm = re.search(r"(\S+\.py):(\d+)", output)
    if fm:
        error_file, error_line = fm.group(1), int(fm.group(2))

    return FlakyInfo(
        error=error,
        error_trace=failure_section or output[:1000],
        error_file=error_file,
        error_line=error_line,
    )


# ── Java ─────────────────────────────────────────────────────────────────────

def _parse_java_failure(output: str) -> FlakyInfo | None:
    """Parse JUnit / Maven Surefire output."""
    if "FAILURE" not in output and "ERROR" not in output:
        return None

    error_lines = [l for l in output.splitlines() if "Exception" in l or "AssertionError" in l]
    error = "\n".join(error_lines[:5]) or output[:300]

    error_file, error_line = "", 0
    m = re.search(r"\((\w+\.java):(\d+)\)", output)
    if m:
        error_file, error_line = m.group(1), int(m.group(2))

    return FlakyInfo(
        error=error,
        error_trace=output[:2000],
        error_file=error_file,
        error_line=error_line,
    )


# ── Public API ───────────────────────────────────────────────────────────────

def reproduce_failure(test_input: TestInput) -> FlakyInfo | None:
    """
    Run the test up to `test_input.repro_runs` times.
    Return the first FlakyInfo captured, or None if no failure observed.

    This mirrors the paper's reproduction step:
      "execute the test case N times; if no failures occur, execute the
       entire test target N times again and filter results."
    """
    cmd = _build_cmd(test_input)
    logger.info("Reproducing flaky test: %s (up to %d runs)", cmd, test_input.repro_runs)

    for i in range(test_input.repro_runs):
        passed, output = _run_once(cmd, cwd=test_input.repo_root)
        if not passed:
            info = _extract_flaky_info(output, test_input)
            if info:
                logger.info("Failure reproduced on run %d/%d", i + 1, test_input.repro_runs)
                return info
            # Non-zero exit but no parseable failure → keep trying

    logger.warning("No failure reproduced after %d runs.", test_input.repro_runs)
    return None


def validate_fix(test_input: TestInput, runs: int = 10) -> bool:
    """
    Return True if the test passes all `runs` consecutive runs after a fix.
    Mirrors the paper's validation step.
    """
    cmd = _build_cmd(test_input)
    for i in range(runs):
        passed, output = _run_once(cmd, cwd=test_input.repo_root)
        if not passed:
            logger.info("Validation failed on run %d/%d", i + 1, runs)
            return False
    logger.info("Fix validated: test passed %d/%d runs.", runs, runs)
    return True
