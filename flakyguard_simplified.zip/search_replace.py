"""
editing/search_replace.py – parse and apply SEARCH/REPLACE patches.

The LLM produces edits in this format (from Aider / the original code):

    path/to/file.go
    ```go
    <<<<<<< SEARCH
    old code
    =======
    new code
    >>>>>>> REPLACE
    ```

Multiple blocks may appear in a single response.
Each block is parsed into a SearchReplaceEdit and applied atomically:
  - All search texts are verified to exist before any writes.
  - On failure, all files are restored from backup.
"""

from __future__ import annotations
import os
import re
import shutil
import logging
import tempfile
from core.types import SearchReplaceEdit, Fix

logger = logging.getLogger(__name__)

# ── Parsing ───────────────────────────────────────────────────────────────────

# Matches optional filename line, then a fenced code block with SEARCH/REPLACE
_BLOCK_RE = re.compile(
    r'(?:^(.+?)\n)?'                     # optional filename line
    r'```[^\n]*\n'                        # opening fence
    r'<<<<<<< SEARCH\n'
    r'(.*?)'                             # search text
    r'=======\n'
    r'(.*?)'                             # replace text
    r'>>>>>>> REPLACE\n'
    r'```',
    re.DOTALL | re.MULTILINE,
)

# Also accept the simpler format without a code fence
_BLOCK_RE_NOFENCE = re.compile(
    r'<<<<<<< SEARCH\n(.*?)=======\n(.*?)>>>>>>> REPLACE',
    re.DOTALL,
)


def parse_edits(llm_response: str, default_filepath: str = "") -> list[SearchReplaceEdit]:
    """
    Extract all SEARCH/REPLACE blocks from an LLM response.

    Args:
        llm_response:     The raw string returned by the LLM.
        default_filepath: Used when no filename is specified in the block.

    Returns:
        List of SearchReplaceEdit objects.
    """
    edits: list[SearchReplaceEdit] = []
    seen_positions: set[int] = set()

    for m in _BLOCK_RE.finditer(llm_response):
        start = m.start()
        if start in seen_positions:
            continue
        seen_positions.add(start)

        filename_raw = (m.group(1) or "").strip()
        search_text  = m.group(2).rstrip("\n")
        replace_text = m.group(3).rstrip("\n")

        # Clean up the filename (strip markdown/backticks)
        filepath = re.sub(r'[`*]', '', filename_raw).strip() or default_filepath

        edits.append(SearchReplaceEdit(
            filepath=filepath,
            search_text=search_text,
            replace_text=replace_text,
        ))

    # Fallback: simpler format (no fence)
    if not edits:
        for m in _BLOCK_RE_NOFENCE.finditer(llm_response):
            edits.append(SearchReplaceEdit(
                filepath=default_filepath,
                search_text=m.group(1).rstrip("\n"),
                replace_text=m.group(2).rstrip("\n"),
            ))

    return edits


def parse_explanation(llm_response: str) -> str:
    """Extract text between <EXPLANATION> tags."""
    m = re.search(r"<EXPLANATION>(.*?)</EXPLANATION>", llm_response, re.DOTALL)
    return m.group(1).strip() if m else ""


def parse_fix(llm_response: str, default_filepath: str = "") -> Fix:
    """Parse a complete Fix (edits + explanation) from an LLM response."""
    edits = parse_edits(llm_response, default_filepath=default_filepath)
    explanation = parse_explanation(llm_response)
    return Fix(edits=edits, explanation=explanation)


# ── Application ───────────────────────────────────────────────────────────────

class FileBackup:
    """Saves and restores a single file."""

    def __init__(self, filepath: str):
        self.filepath = filepath
        self._backup: str | None = None

    def save(self) -> bool:
        try:
            with open(self.filepath, "r", encoding="utf-8", errors="replace") as f:
                self._backup = f.read()
            return True
        except OSError as e:
            logger.error("Backup failed for %s: %s", self.filepath, e)
            return False

    def revert(self) -> bool:
        if self._backup is None:
            return False
        try:
            with open(self.filepath, "w", encoding="utf-8") as f:
                f.write(self._backup)
            return True
        except OSError as e:
            logger.error("Revert failed for %s: %s", self.filepath, e)
            return False


def _apply_one_edit(content: str, edit: SearchReplaceEdit) -> tuple[bool, str]:
    """Apply a single search/replace edit to content. Returns (success, new_content)."""
    if edit.search_text not in content:
        # Try normalizing whitespace
        norm_content = re.sub(r'\r\n', '\n', content)
        norm_search  = re.sub(r'\r\n', '\n', edit.search_text)
        if norm_search not in norm_content:
            return False, content
        return True, norm_content.replace(norm_search, edit.replace_text, 1)
    return True, content.replace(edit.search_text, edit.replace_text, 1)


def apply_fix(fix: Fix, repo_root: str) -> tuple[bool, dict[str, FileBackup] | str]:
    """
    Apply all edits in a Fix atomically.

    Returns:
        (True,  {filepath: FileBackup})  on success
        (False, error_message: str)      on failure – files are restored
    """
    if not fix.edits:
        return False, "No edits to apply"

    # Resolve all filepaths first
    resolved: list[tuple[str, SearchReplaceEdit]] = []
    for edit in fix.edits:
        fp = edit.filepath
        if not os.path.isabs(fp):
            fp = os.path.join(repo_root, fp)
        if not os.path.isfile(fp):
            return False, f"File not found: {fp}"
        resolved.append((fp, edit))

    # Pre-check: verify all search texts exist (before touching any file)
    for fp, edit in resolved:
        with open(fp, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        if edit.search_text not in content:
            norm = re.sub(r'\r\n', '\n', content)
            if re.sub(r'\r\n', '\n', edit.search_text) not in norm:
                return False, (
                    f"Pre-check failed: search text not found in {fp}:\n"
                    f"{edit.search_text[:200]}"
                )

    # Back up all affected files
    backups: dict[str, FileBackup] = {}
    for fp, _ in resolved:
        if fp not in backups:
            b = FileBackup(fp)
            if not b.save():
                return False, f"Could not back up {fp}"
            backups[fp] = b

    # Apply edits per file
    file_contents: dict[str, str] = {fp: backups[fp]._backup for fp in backups}  # type: ignore[index]
    for fp, edit in resolved:
        ok, new_content = _apply_one_edit(file_contents[fp], edit)
        if not ok:
            # Revert all
            for b in backups.values():
                b.revert()
            return False, f"Could not apply edit to {fp}"
        file_contents[fp] = new_content

    # Write all files
    try:
        for fp, content in file_contents.items():
            with open(fp, "w", encoding="utf-8") as f:
                f.write(content)
    except OSError as e:
        for b in backups.values():
            b.revert()
        return False, f"Write error: {e}"

    return True, backups


def revert_all(backups: dict[str, FileBackup]) -> None:
    """Revert all backed-up files."""
    for b in backups.values():
        b.revert()


def write_patch_file(backups: dict[str, FileBackup], output_dir: str, prefix: str = "fix") -> str:
    """
    Write unified diff patch files to output_dir.
    Returns the path to the directory containing the patches.
    """
    import difflib, datetime
    os.makedirs(output_dir, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    patch_path = os.path.join(output_dir, f"{prefix}_{ts}.patch")
    with open(patch_path, "w", encoding="utf-8") as pf:
        for filepath, backup in backups.items():
            original = (backup._backup or "").splitlines(keepends=True)
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    modified = f.readlines()
            except OSError:
                continue
            diff = list(difflib.unified_diff(
                original, modified,
                fromfile=f"a/{os.path.basename(filepath)}",
                tofile=f"b/{os.path.basename(filepath)}",
            ))
            pf.writelines(diff)
    return patch_path
