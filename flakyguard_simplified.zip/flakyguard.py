#!/usr/bin/env python3
"""
flakyguard.py – CLI entry point for FlakyGuard Simple.

Usage:
    python flakyguard.py \\
        --repo       /path/to/repo \\
        --test-file  src/backend_test.go \\
        --test-func  TestAddProgram \\
        --test-case  "validation and call UpdateInfo" \\
        --language   go \\
        --runner     "go test -v -count=1 -run {test_func} ./{test_dir}/..." \\
        --runs       100

The tool:
  1. Reproduces the flaky failure.
  2. Collects context via LLM-guided smart BFS over the call graph.
  3. Generates and validates patches in nested loops (M × P × N).
  4. Saves the first validated patch as a .patch file.
"""

import argparse
import logging
import os
import sys

# Ensure local packages are importable when run directly
sys.path.insert(0, os.path.dirname(__file__))

from core.types import TestInput
from core.pipeline import run_pipeline
from utils.runner import reproduce_failure

logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(
        description="FlakyGuard Simple – automated flaky-test repair."
    )

    # Required
    p.add_argument("--repo",       required=True, help="Absolute path to repository root")
    p.add_argument("--test-file",  required=True, help="Test file path (relative to --repo)")
    p.add_argument("--test-func",  required=True, help="Test function name, e.g. TestAddProgram")
    p.add_argument("--test-case",  required=True, help="Test case name / sub-test name")

    # Optional
    p.add_argument("--language",  default="go",
                   choices=["go", "python", "java"],
                   help="Source language (default: go)")
    p.add_argument("--runner",    default="go test -v -count=1 -run {test_func} ./{test_dir}/...",
                   help="Shell command template for running the test")
    p.add_argument("--runs",      type=int, default=100,
                   help="Max reproduction runs (default: 100)")

    # Loop parameters (paper defaults)
    p.add_argument("--context-attempts", type=int, default=3,
                   help="Outer loop M: context collection retries (default: 3)")
    p.add_argument("--thoughts",         type=int, default=2,
                   help="Middle loop P: thoughts per context (default: 2)")
    p.add_argument("--fix-attempts",     type=int, default=3,
                   help="Inner loop N: fix attempts per thought (default: 3)")
    p.add_argument("--children",         type=int, default=3,
                   help="Smart BFS k: children selected per node (default: 3)")
    p.add_argument("--max-funcs",        type=int, default=5,
                   help="Global filter F: max functions in context (default: 5)")
    p.add_argument("--depth",            type=int, default=-1,
                   help="BFS depth limit, -1 = unlimited (default: -1)")
    p.add_argument("--validation-runs",  type=int, default=10,
                   help="Runs to confirm fix stability (default: 10)")

    # Output
    p.add_argument("--output-dir", default="patches",
                   help="Directory to save patch files (default: ./patches)")
    p.add_argument("--verbose", action="store_true", help="Verbose logging")

    return p.parse_args()


def main():
    args = parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    test_input = TestInput(
        repo_root=os.path.abspath(args.repo),
        test_file=args.test_file,
        test_func=args.test_func,
        test_case=args.test_case,
        language=args.language,
        run_cmd=args.runner,
        repro_runs=args.runs,
    )

    # ── Step 1: Reproduce the failure ────────────────────────────────────────
    print(f"\n[1/3] Reproducing flaky failure (up to {args.runs} runs)…")
    flaky_info = reproduce_failure(test_input)
    if flaky_info is None:
        print("✗ Could not reproduce a failure. Test may not be flaky in this environment.")
        sys.exit(1)

    print(f"✓ Failure reproduced.")
    print(f"  Error: {flaky_info.error[:120]}")

    # ── Step 2: Run the fixing pipeline ──────────────────────────────────────
    print(f"\n[2/3] Running fixing pipeline (M={args.context_attempts} × "
          f"P={args.thoughts} × N={args.fix_attempts})…")

    output_dir = os.path.join(test_input.repo_root, args.output_dir)
    success, message = run_pipeline(
        test_input=test_input,
        flaky_info=flaky_info,
        M=args.context_attempts,
        P=args.thoughts,
        N=args.fix_attempts,
        k=args.children,
        depth_limit=args.depth,
        max_funcs=args.max_funcs,
        output_dir=output_dir,
        validation_runs=args.validation_runs,
    )

    # ── Step 3: Report ────────────────────────────────────────────────────────
    print(f"\n[3/3] Result:")
    if success:
        print(f"✓ Fix found and validated.")
        print(f"  Root cause: {message}")
        print(f"  Patch saved to: {output_dir}/")
    else:
        print(f"✗ No fix found: {message}")
        sys.exit(2)


if __name__ == "__main__":
    main()
