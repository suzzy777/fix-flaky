#!/bin/bash

set -e

echo "Setting up FlakyGuard environment..."

# Check if running in correct directory
if [ ! -f "flakyguard/README.md" ]; then
    echo "Error: Please run this script from the artifact root directory"
    echo "Expected to find: flakyguard/README.md"
    exit 1
fi

SCRIPT_DIR="$(pwd)"
VENV_DIR="$SCRIPT_DIR/venv"
FLAKYGUARD_DIR="$SCRIPT_DIR/flakyguard"

echo "Working in: $SCRIPT_DIR"

# Detect OS like build-grammars.sh does
OS=$(uname -s)

# Step 1: Install system dependencies based on platform
echo "Installing system dependencies..."
if [ "$OS" = "Darwin" ]; then
    echo "Detected macOS"
    # macOS uses standard gcc, no additional packages needed
    if ! command -v gcc &> /dev/null; then
        echo "Please install Xcode command line tools: xcode-select --install"
        exit 1
    fi
    
    # Check Bazel version
    if command -v bazel &> /dev/null; then
        CURRENT_VERSION=$(bazel --version | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' | head -1)
        if [ "$CURRENT_VERSION" != "5.4.1" ]; then
            echo "Warning: Current Bazel version is $CURRENT_VERSION, but FlakyGuard requires 5.4.1"
            echo "Please change to Bazel 5.4.1 for compatibility with WORKSPACE files"
            exit 1
        fi
        echo "Bazel: $(bazel --version)"
    else
        echo "Installing Bazel 5.4.1..."
        ARCH=$(uname -m)
        [ "$ARCH" = "x86_64" ] && BAZEL_ARCH="darwin-x86_64" || BAZEL_ARCH="darwin-arm64"
        wget -O /tmp/bazel "https://github.com/bazelbuild/bazel/releases/download/5.4.1/bazel-5.4.1-${BAZEL_ARCH}"
        sudo mv /tmp/bazel /usr/local/bin/bazel
        sudo chmod +x /usr/local/bin/bazel
        echo "Bazel 5.4.1 installed"
    fi
    
elif [ "$OS" = "Linux" ]; then
    echo "Detected Linux"
    echo "Installing gcc-aarch64-linux-gnu package for cross-compilation..."
    sudo apt-get update -qq
    sudo apt-get install -y gcc-aarch64-linux-gnu python3-venv python3-pip
    
    # Check Bazel version
    if command -v bazel &> /dev/null; then
        CURRENT_VERSION=$(bazel --version | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' | head -1)
        if [ "$CURRENT_VERSION" != "5.4.1" ]; then
            echo "Warning: Current Bazel version is $CURRENT_VERSION, but FlakyGuard requires 5.4.1"
            echo "Please change to Bazel 5.4.1 for compatibility with WORKSPACE files"
            exit 1
        fi
        echo "Bazel: $(bazel --version)"
    else
        echo "Installing Bazel 5.4.1..."
        ARCH=$(uname -m)
        [ "$ARCH" = "x86_64" ] && BAZEL_ARCH="linux-x86_64" || BAZEL_ARCH="linux-arm64"
        wget -O /tmp/bazel "https://github.com/bazelbuild/bazel/releases/download/5.4.1/bazel-5.4.1-${BAZEL_ARCH}"
        sudo mv /tmp/bazel /usr/local/bin/bazel
        sudo chmod +x /usr/local/bin/bazel
        echo "Bazel 5.4.1 installed"
    fi
    
else
    echo "Unsupported operating system: $OS"
    exit 1
fi

# Step 2: Create and activate virtual environment
echo "Setting up Python virtual environment..."
if [ -d "$VENV_DIR" ]; then
    echo "Removing existing venv..."
    rm -rf "$VENV_DIR"
fi

python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

# Create a clean pip configuration for this virtual environment
mkdir -p "$VENV_DIR/pip"
cat > "$VENV_DIR/pip/pip.conf" << EOF
[global]
index-url = https://pypi.org/simple/
EOF

# Step 3: Install Python dependencies with exact versions
echo "Installing Python packages..."

# Use the clean pip configuration
export PIP_CONFIG_FILE="$VENV_DIR/pip/pip.conf"

pip install --upgrade pip --no-cache-dir
pip install "tree-sitter==0.21.0" --no-cache-dir
pip install openai networkx sourcelocation pocketflow --no-cache-dir

# Step 4: Install FlakyGuard in editable mode
echo "Installing FlakyGuard..."
pip install -e "$FLAKYGUARD_DIR" --no-cache-dir

# Step 5: Build tree-sitter grammars using existing script
echo "Building tree-sitter grammars..."
cd "$FLAKYGUARD_DIR/llm/tree-sitter-grammars"
bash build-grammars.sh
cd "$SCRIPT_DIR"

# Step 6: Verify installation
echo "Verifying installation..."
source "$VENV_DIR/bin/activate"
export PYTHONPATH="$FLAKYGUARD_DIR:$PYTHONPATH"

# Test import
python3 -c "
try:
    from flakyguard.core.flaky_fixing import TestInput
    print('FlakyGuard imports successfully')
except ImportError as e:
    print(f'Import failed: {e}')
    exit(1)
"

# Count tree-sitter files (different counts for different platforms)
SO_COUNT=$(find "$FLAKYGUARD_DIR/llm/tree-sitter-grammars" -name "*.so" | wc -l)
if [ "$OS" = "Darwin" ]; then
    EXPECTED_COUNT=3
elif [ "$OS" = "Linux" ]; then
    EXPECTED_COUNT=6
fi

if [ "$SO_COUNT" -eq "$EXPECTED_COUNT" ]; then
    echo "Tree-sitter grammars built successfully ($SO_COUNT .so files for $OS)"
else
    echo "Tree-sitter build incomplete (expected $EXPECTED_COUNT .so files for $OS, found $SO_COUNT)"
    exit 1
fi

echo ""
echo "FlakyGuard environment setup complete!"
echo ""
echo "Prerequisites verified:"
echo "- Bazel: $(bazel --version)"
echo "- Python virtual environment with dependencies"
echo "- Tree-sitter grammars built successfully"
echo ""
echo "To use FlakyGuard:"
echo "1. Set your OpenAI API configuration:"
echo "   export OPENAI_API_KEY=\"your-openai-api-key\""
echo "   export OPENAI_CHAT_MODEL=\"o1\"  # or gpt-4, gpt-3.5-turbo, etc."
echo ""
echo "2. Run FlakyGuard on an example (virtual environment is auto-activated):"
echo "   bash flakyguard/scripts/flakyguard_lite.sh ./examples/floating-point \"//:go_default_test\" TestAccumulateSum"
echo ""
echo "Note: The script automatically activates the virtual environment and sets PYTHONPATH."
echo "See README.md for more detailed usage instructions."