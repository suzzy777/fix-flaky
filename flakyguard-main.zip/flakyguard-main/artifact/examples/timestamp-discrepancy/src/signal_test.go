package main

import (
	"testing"
	"time"
)

func TestSignalProcessor_ProcessSignal(t *testing.T) {
	lastSignalTime = time.Time{}
	callCount = 0
	
	signal1 := getMockSignal()
	signal2 := getMockSignal()
	
	result := CompareSessions(*signal1, *signal2)
	
	if !result.IsEqual {
		t.Error("Expected signals to have equal timestamps")
	}
}

