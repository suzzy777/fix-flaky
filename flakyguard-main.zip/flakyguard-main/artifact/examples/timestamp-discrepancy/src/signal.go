package main

import (
	"time"
)

type DocstoreTime time.Time

type Signal struct {
	UpdatedAt               DocstoreTime
	LastProcessingEventTime int64
	CreatedAt               DocstoreTime
	// other fields omitted for brevity
}

var lastSignalTime time.Time
var callCount int

func getMockSignal() *Signal {
	callCount++
	currentTime := time.Now().UTC()
	
	if callCount == 2 {
		if currentTime.UnixNano()%2 == 0 && !lastSignalTime.IsZero() {
			currentTime = lastSignalTime
		} else {
			currentTime = currentTime.Add(time.Millisecond)
		}
	}
	lastSignalTime = currentTime
	
	fiveMinsAgo := time.Now().Add(-5 * time.Minute).UnixMilli()
	return &Signal{
		UpdatedAt:               DocstoreTime(currentTime),
		LastProcessingEventTime: fiveMinsAgo,
		CreatedAt:               DocstoreTime(currentTime),
	}
}

func CompareSessions(signal1, signal2 Signal) ComparisonResult {
	return ComparisonResult{
		IsEqual: signal1.UpdatedAt == signal2.UpdatedAt &&
			signal1.CreatedAt == signal2.CreatedAt &&
			signal1.LastProcessingEventTime == signal2.LastProcessingEventTime,
	}
}

type ComparisonResult struct {
	IsEqual bool
}