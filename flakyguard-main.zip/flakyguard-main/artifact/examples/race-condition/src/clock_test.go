package main

import (
	"testing"
	"time"
)

func TestConcurrentCounter(t *testing.T) {
	counter := NewCounter()
	
	// Start many goroutines to create heavy contention
	for i := 0; i < 100; i++ {
		go func() {
			// Do some work to increase chance of race conditions
			for j := 0; j < 10; j++ {
				counter.Increment()
			}
		}()
	}
	
	// Let goroutines finish
	time.Sleep(time.Millisecond * 10)
	
	actual := counter.Value()
	expected := 1000 // 100 goroutines * 10 increments each
	
	// Due to race conditions, we'll get less than expected
	if actual != expected {
		t.Errorf("Expected counter value to be exactly %d, got %d", expected, actual)
	}
}

