package main

import (
	"sync"
	"sync/atomic"
	"time"
)

type SafeMock struct {
	nanos    atomic.Int64
	mu       sync.Mutex
	channels []chan time.Time
}

func NewSafeMock() *SafeMock {
	return &SafeMock{
		channels: make([]chan time.Time, 0),
	}
}

func (sm *SafeMock) Tick(d time.Duration) <-chan time.Time {
	ch := make(chan time.Time, 1)
	sm.mu.Lock()
	sm.channels = append(sm.channels, ch)
	sm.mu.Unlock()
	return ch
}

func (sm *SafeMock) Set(t time.Time) {
	sm.nanos.Store(t.UnixNano())
	
	// Send current time to all channels
	sm.mu.Lock()
	for _, ch := range sm.channels {
		select {
		case ch <- t:
		default:
		}
	}
	sm.mu.Unlock()
}

func (sm *SafeMock) Now() time.Time {
	return time.Unix(0, sm.nanos.Load())
}

// Counter represents a non-thread-safe counter
type Counter struct {
	value int
}

func NewCounter() *Counter {
	return &Counter{value: 0}
}

func (c *Counter) Increment() {
	temp := c.value
	temp++
	c.value = temp
}

func (c *Counter) Value() int {
	return c.value
}