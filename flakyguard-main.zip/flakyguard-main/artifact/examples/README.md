# Go Flaky Test Examples

Collection of common flaky test patterns in Go. These examples demonstrate real-world scenarios where tests pass inconsistently due to non-deterministic behavior.

## Test Categories

### Floating Point Precision (`floating-point/`)
Tests that fail due to floating-point precision issues and exact equality comparisons.

**Root cause**: IEEE 754 floating-point representation cannot exactly represent all decimal numbers.

**Failure modes**:
- `TestAccumulateSum` uses random values and expects sum >= 10.5, but random inputs can produce smaller sums
- `TestCalculateArea` randomly selects reduction values where `math.Ceil()` vs direct calculation sometimes produce different results based on whether the intermediate calculation has fractional parts
- `TestDivideNumbers` expects exact match with hardcoded `0.3333333333333333` for `1/3` division

### Map Iteration Ordering (`map-ordering/`)
Tests that assume deterministic iteration order over Go maps.

**Root cause**: Go intentionally randomizes map iteration order to prevent reliance on undefined behavior.

**Failure modes**:
- `TestGenerateValidationEvents` expects first result to be "user1" with "acceptance_rate"
- Map iteration order is randomized each run, so any key-value pair can appear first
- Test fails when different elements appear in first position due to Go's randomization

### Race Conditions (`race-condition/`)
Tests with unsynchronized concurrent access to shared memory.

**Root cause**: Multiple goroutines accessing shared state without proper synchronization primitives.

**Failure modes**:
- `TestConcurrentCounter` spawns 100 goroutines that each increment a counter 10 times
- Expects exactly 1000 total increments, but race conditions cause lost updates
- Non-atomic read-modify-write operations allow multiple goroutines to overwrite each other's changes
- Results vary between runs (e.g., 990, 995, 1000) depending on timing and scheduler behavior

### Random Behavior (`random-behavior/`)
Tests that make deterministic assumptions about random number generation.

**Root cause**: Unseeded random number generators produce unpredictable output by design.

**Failure modes**:
- `TestRandomNumber` generates random number 1-10 and expects ≤ 5, failing ~50% of the time
- `TestRandomSort` shuffles array and expects first element ≤ 3, but any element can appear first
- Tests rely on probability without controlling randomness through seeding or mocking

### Time-Dependent Behavior (`time-dependent/`)
Tests that depend on current system time and exhibit boundary condition failures.

**Root cause**: Using `time.Now()` in tests without accounting for timing edge cases.

**Failure modes**:
- `TestTimeBoundary` calculates "3 months ago" from current time
- Date arithmetic fails at month boundaries due to varying month lengths
- Test behavior depends on when it's executed, making results non-reproducible

### Schedule Randomness (`schedule-randomness/`)
Tests that depend on goroutine scheduling order without proper synchronization.

**Root cause**: Go scheduler timing is non-deterministic and not guaranteed to complete within arbitrary time windows.

**Failure modes**:
- `TestGoroutineScheduling` starts background goroutine and waits 10 microseconds
- Scheduler may not complete goroutine execution within the fixed time window
- Test results depend on system load, CPU scheduling, and runtime behavior

### Test Pollution (`test-pollution/`)
Parallel tests that interfere with each other through shared global state.

**Root cause**: Multiple tests modifying the same global variables and environment concurrently.

**Failure modes**:
- Tests marked with `t.Parallel()` run simultaneously
- `TestInitConfig` sets environment variables and updates global config
- `TestGetConfig` clears environment variables and resets global config
- `TestSetDebugMode` also modifies global state
- Concurrent modifications create unpredictable test interactions and race conditions

### Timestamp Discrepancy (`timestamp-discrepancy/`)
Tests that expect identical timestamps from multiple `time.Now()` calls.

**Root cause**: System clock advances between consecutive function calls, even at nanosecond precision.

**Failure modes**:
- `TestSignalProcessor_ProcessSignal` calls `getMockSignal()` twice
- Each call captures `time.Now().UTC()` and expects identical timestamps
- Time advances between calls, causing timestamp comparison failures
- Contains additional timing manipulation logic that introduces further non-determinism

## Running the Examples

Each directory contains a complete test suite demonstrating flaky behavior.

**Single test run:**
```bash
cd floating-point
bazel test //:go_default_test
```

**Multiple runs to observe flakiness:**
```bash
bazel test //:go_default_test --runs_per_test=20
```

Running multiple times reveals the non-deterministic behavior where some executions pass and others fail.

## Automated Analysis with FlakyGuard Lite

Use FlakyGuard Lite to automatically detect and analyze flaky test patterns:

```bash
# Floating Point Precision
bash flakyguard/scripts/flakyguard_lite.sh ./examples/floating-point "//:go_default_test" TestAccumulateSum

# Map Iteration Ordering  
bash flakyguard/scripts/flakyguard_lite.sh ./examples/map-ordering "//:go_default_test" TestGenerateValidationEvents

# Race Conditions
bash flakyguard/scripts/flakyguard_lite.sh ./examples/race-condition "//:go_default_test" TestConcurrentCounter

# Random Behavior
bash flakyguard/scripts/flakyguard_lite.sh ./examples/random-behavior "//:go_default_test" TestRandomNumber

# Time-Dependent Behavior
bash flakyguard/scripts/flakyguard_lite.sh ./examples/time-dependent "//:go_default_test" TestTimeBoundary

# Schedule Randomness
bash flakyguard/scripts/flakyguard_lite.sh ./examples/schedule-randomness "//:go_default_test" TestGoroutineScheduling

# Test Pollution
bash flakyguard/scripts/flakyguard_lite.sh ./examples/test-pollution "//:go_default_test" TestInitConfig

# Timestamp Discrepancy
bash flakyguard/scripts/flakyguard_lite.sh ./examples/timestamp-discrepancy "//:go_default_test" TestSignalProcessor_ProcessSignal
```

## Common Patterns and Solutions

These examples represent real flaky test patterns found in production codebases:

- **Floating-point operations**: Use tolerance-based comparisons instead of exact equality
- **Map iteration**: Avoid assumptions about iteration order; use sorted keys when order matters
- **Concurrency**: Implement proper synchronization with mutexes, channels, or wait groups
- **Random behavior**: Control randomness through seeding or deterministic mocking
- **Time dependencies**: Mock system time or use fixed timestamps in tests
- **Global state**: Isolate tests to prevent interference between parallel executions

Flaky tests reduce confidence in test suites and can mask real bugs. Address these patterns early to maintain reliable CI/CD pipelines.