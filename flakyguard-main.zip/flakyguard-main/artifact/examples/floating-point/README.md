# Floating Point Flaky Test Example

This project demonstrates test flakiness caused by floating-point precision issues and random number generation.

## Why Tests Are Flaky

### 1. TestAccumulateSum (lines 9-21)
- **Root Cause**: Uses `rand.Float64()` to generate random values without seeding, causing non-deterministic behavior
- **Flakiness**: The test expects sum >= 10.5, but random values can vary significantly between runs
- **Why it fails**: Random numbers may sum to less than the expected threshold unpredictably

### 2. TestFloatingPointPrecision (lines 23-32)  
- **Root Cause**: Floating-point arithmetic precision errors
- **Flakiness**: 0.1 + 0.2 + 0.3 may not exactly equal 0.6 due to binary representation limits
- **Why it fails**: The tolerance (1e-10) may be too strict for accumulated floating-point errors

### 3. TestDivideNumbers (lines 44-51)
- **Root Cause**: Exact floating-point comparison without tolerance
- **Flakiness**: 1.0/3.0 result may vary slightly due to floating-point representation
- **Why it fails**: Direct equality check (`!=`) is unreliable for floating-point division results