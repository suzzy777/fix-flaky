package main

import (
	"math"
	"math/rand"
	"testing"
)

func TestAccumulateSum(t *testing.T) {
	reductionAmounts := []float64{0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1}
	for i := 0; i < 10; i++ {
		reductionAmounts = append(reductionAmounts, rand.Float64())
	}
	
	sum := AccumulateSum(reductionAmounts)
	expectedSum := 10.5
	
	if sum < expectedSum {
		t.Errorf("Expected sum >= %f, got %f", expectedSum, sum)
	}
}

func TestFloatingPointPrecision(t *testing.T) {
	values := []float64{0.1, 0.2, 0.3}
	sum := AccumulateSum(values)
	expected := 0.6
	
	tolerance := 1e-10
	if math.Abs(sum-expected) > tolerance {
		t.Errorf("Expected sum %f (±%e), got %f", expected, tolerance, sum)
	}
}

func TestCalculateArea(t *testing.T) {
	// Create test that sometimes passes and sometimes fails
	// Use a value that sometimes results in whole numbers
	candidates := []float64{0.0, 0.1, 0.125, 0.2, 0.25, 0.333, 0.375, 0.4, 0.5}
	
	// Pick a random candidate value  
	randomIndex := rand.Intn(len(candidates))
	reduction := candidates[randomIndex]
	
	totalCount := 8.0 // Smaller number to increase chance of whole results
	
	// Method 1: Using math.Ceil (rounds up)
	expectedCount := math.Ceil((1.0 - reduction) * totalCount)
	radius1 := expectedCount / 10.0
	area1 := CalculateArea(radius1)
	
	// Method 2: Using direct multiplication 
	directCount := (1.0 - reduction) * totalCount
	radius2 := directCount / 10.0
	area2 := CalculateArea(radius2)
	
	// This will pass when the calculation results in a whole number
	// but fail when math.Ceil rounds up from a fractional result
	if area1 != area2 {
		t.Errorf("Expected areas to be equal for reduction %f: %f vs %f (counts: %f vs %f)", 
			reduction, area1, area2, expectedCount, directCount)
	}
}

func TestDivideNumbers(t *testing.T) {
	result := DivideNumbers(1.0, 3.0)
	expected := 0.3333333333333333
	
	if result != expected {
		t.Errorf("Expected result %f, got %f", expected, result)
	}
}