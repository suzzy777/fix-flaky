package main

import (
	"math"
)

func CalculateDistance(x1, y1, x2, y2 float64) float64 {
	dx := x2 - x1
	dy := y2 - y1
	return math.Sqrt(dx*dx + dy*dy)
}

func CalculateArea(radius float64) float64 {
	return math.Pi * radius * radius
}

func DivideNumbers(a, b float64) float64 {
	return a / b
}

func AccumulateSum(values []float64) float64 {
	sum := 0.0
	for _, v := range values {
		sum += v
	}
	return sum
}