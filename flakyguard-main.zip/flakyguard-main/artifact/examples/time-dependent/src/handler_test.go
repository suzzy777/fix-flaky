package main

import (
	"context"
	"testing"
	"time"
)

func TestTimeBoundary(t *testing.T) {
	handler := NewHandler()
	ctx := context.Background()
	
	cutoffTime := time.Now().UTC().AddDate(0, -3, 0)
	beginTime := TimeToMS(cutoffTime)
	
	request := &GetSupplyChangesRequest{
		StartTime: beginTime,
	}
	
	_, err := handler.GetSupplyChanges(ctx, request)
	if err != nil {
		t.Errorf("Expected no error, but got: %v", err)
	}
}