package main

import (
	"context"
	"errors"
	"time"
)

const Age = 3 // Age in months

// Global cutoff calculated at startup
var cutoff = time.Now().UTC().AddDate(0, -Age, 0)

type GetSupplyChangesRequest struct {
	StartTime int64
}

type Handler struct{}

func NewHandler() *Handler {
	return &Handler{}
}

func (h *Handler) GetSupplyChanges(ctx context.Context, request *GetSupplyChangesRequest) (interface{}, error) {
	// Validate the age of the request
	if err := h.validateAge(request.StartTime); err != nil {
		return nil, err
	}
	
	return map[string]string{"status": "success"}, nil
}

func (h *Handler) validateAge(beginTimeMS int64) error {
	beginTime := time.Unix(0, beginTimeMS*int64(time.Millisecond))
	// Use the global cutoff
	
	if beginTime.Before(cutoff) {
		return errors.New("request is too old")
	}
	return nil
}

func TimeToMS(t time.Time) int64 {
	return t.UnixNano() / int64(time.Millisecond)
}