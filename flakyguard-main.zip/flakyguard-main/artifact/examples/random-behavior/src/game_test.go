package main

import (
	"testing"
)

func TestRandomNumber(t *testing.T) {
	num := GenerateRandomNumber(1, 10)
	
	if num > 5 {
		t.Errorf("Expected random number <= 5, got %d", num)
	}
}

func TestRandomSort(t *testing.T) {
	input := []int{1, 2, 3, 4, 5}
	result := RandomSort(input)
	
	if len(result) > 0 && result[0] > 3 {
		t.Errorf("Expected first element to be <= 3, got %d", result[0])
	}
}