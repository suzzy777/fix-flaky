package main

import (
	"math/rand"
)

type GameResult struct {
	Score    int
	Level    int
	Achieved bool
}

func PlayGame() *GameResult {
	// Simulate game outcome
	score := rand.Intn(1000)
	level := rand.Intn(10) + 1
	achieved := rand.Float64() < 0.7
	
	return &GameResult{
		Score:    score,
		Level:    level,
		Achieved: achieved,
	}
}

func CalculateBonus(result *GameResult) int {
	if !result.Achieved {
		return 0
	}
	
	bonus := result.Score / 10
	if result.Level >= 5 {
		bonus *= 2
	}
	
	return bonus
}

func GenerateRandomNumber(min, max int) int {
	return rand.Intn(max-min+1) + min
}

func RandomSort(input []int) []int {
	// Create a copy to avoid modifying the original
	result := make([]int, len(input))
	copy(result, input)
	
	// Fisher-Yates shuffle
	for i := len(result) - 1; i > 0; i-- {
		j := rand.Intn(i + 1)
		result[i], result[j] = result[j], result[i]
	}
	
	return result
}