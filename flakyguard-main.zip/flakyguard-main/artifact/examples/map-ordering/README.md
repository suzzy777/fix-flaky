# Map Ordering Flaky Test Example

This project demonstrates test flakiness caused by Go's non-deterministic map iteration order.

## Why Tests Are Flaky

### TestGenerateValidationEvents (lines 7-43)
- **Root Cause**: Go maps have random iteration order since Go 1.0 for security reasons
- **Flakiness**: The test assumes `actualRes[0].SubjectID == "user1"` and `actualRes[0].Name == "acceptance_rate"`
- **Why it fails**: 
  - Map iteration over `subjects` (line 19) produces non-deterministic order
  - Nested map iteration over `*metricSet` (line 21) also has random order
  - The first event `actualRes[0]` could be from any subject with any metric name
- **Impact**: Test will randomly pass/fail depending on which map entry is processed first