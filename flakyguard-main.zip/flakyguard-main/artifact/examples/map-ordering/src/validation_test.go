package main

import (
	"testing"
)

func TestGenerateValidationEvents(t *testing.T) {
	subjects := map[string]*MetricSet{
		"user1": {
			"acceptance_rate":   0.85,
			"cancellation_rate": 0.15,
			"completion_rate":   0.95,
			"error_rate":        0.05,
		},
		"user2": {
			"acceptance_rate":   0.90,
			"cancellation_rate": 0.10,
			"completion_rate":   0.88,
			"error_rate":        0.12,
		},
		"user3": {
			"acceptance_rate":   0.75,
			"cancellation_rate": 0.25,
			"completion_rate":   0.80,
			"error_rate":        0.20,
		},
	}
	
	actualRes := GenerateValidationEvents(subjects)
	
	if len(actualRes) != 12 {
		t.Errorf("Expected 12 events, got %d", len(actualRes))
		return
	}
	
	if actualRes[0].SubjectID != "user1" {
		t.Errorf("Expected first event from user1, got %s", actualRes[0].SubjectID)
	}
	
	if actualRes[0].Name != "acceptance_rate" {
		t.Errorf("Expected first metric to be acceptance_rate, got %s", actualRes[0].Name)
	}
}

