package main

import (
	"fmt"
)

type MetricSet map[string]float64

type ValidationEvent struct {
	SubjectID string
	Name      string
	Value     float64
}

func GenerateValidationEvents(subjects map[string]*MetricSet) []*ValidationEvent {
	events := make([]*ValidationEvent, 0)
	
	// iterate over all subjects and their metrics
	for subjectID, metricSet := range subjects {
		// iterate over each metric
		for metricName, value := range *metricSet {
			event := &ValidationEvent{
				SubjectID: subjectID,
				Name:      metricName,
				Value:     value,
			}
			events = append(events, event)
		}
	}
	return events
}

func main() {
	subjects := map[string]*MetricSet{
		"user1": {"metric1": 1.0, "metric2": 2.0},
		"user2": {"metric1": 3.0, "metric2": 4.0},
	}
	
	events := GenerateValidationEvents(subjects)
	fmt.Printf("Generated %d validation events\n", len(events))
}