package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestInitConfig(t *testing.T) {
	t.Parallel()
	
	os.Setenv("DEBUG", "true")
	os.Setenv("MAX_ITEMS", "200")
	os.Setenv("API_KEY", "test-key")
	
	InitConfig()
	
	config := GetConfig()
	if !config.Debug {
		t.Error("Expected debug to be true")
	}
	
	if config.MaxItems != 200 {
		t.Errorf("Expected max items to be 200, got %d", config.MaxItems)
	}
	
	if config.APIKey != "test-key" {
		t.Errorf("Expected API key to be 'test-key', got %s", config.APIKey)
	}
}

func TestGetConfig(t *testing.T) {
	t.Parallel()
	
	os.Unsetenv("DEBUG")
	os.Unsetenv("MAX_ITEMS")
	os.Unsetenv("API_KEY")
	
	GlobalConfig = nil
	
	config := GetConfig()
	
	if config.Debug {
		t.Error("Expected debug to be false")
	}
	
	if config.MaxItems != 100 {
		t.Errorf("Expected max items to be 100, got %d", config.MaxItems)
	}
	
	if config.APIKey != "default-key" {
		t.Errorf("Expected API key to be 'default-key', got %s", config.APIKey)
	}
}

func TestSetDebugMode(t *testing.T) {
	t.Parallel()
	
	GlobalConfig = nil
	InitConfig()
	
	SetDebugMode(true)
	config := GetConfig()
	
	if !config.Debug {
		t.Error("Expected debug to be true after setting")
	}
}

func TestXMLProcessor_Write_Integration_File(t *testing.T) {
	testFolder := "/tmp/asset"
	testOutputPattern := filepath.Join(testFolder, "%locale%", "output.xml")
	
	tests := []struct {
		name      string
		validator func(t *testing.T)
	}{
		{
			name: "only es locale",
			validator: func(t *testing.T) {
				esFileContent, err := readFileContent("/tmp/asset/es/output.xml")
				if err != nil {
					t.Errorf("Expected no error reading es file, got %v", err)
					return
				}
				if esFileContent != "expected_content" {
					t.Errorf("Expected es file to contain 'expected_content'")
				}
				
				_, err = readFileContent("/tmp/asset/fr/output.xml")
				if err == nil {
					t.Errorf("Expected error reading fr file, but got none")
				}
			},
		},
		{
			name: "both locales exist",
			validator: func(t *testing.T) {
				esFileContent, err := readFileContent("/tmp/asset/es/output.xml")
				if err != nil {
					t.Errorf("Expected no error reading es file, got %v", err)
					return
				}
				if esFileContent != "expected_content" {
					t.Errorf("Expected es file to contain 'expected_content'")
				}
				
				frFileContent, err := readFileContent("/tmp/asset/fr/output.xml")
				if err != nil {
					t.Errorf("Expected no error reading fr file, got %v", err)
					return
				}
				if frFileContent != "expected_content" {
					t.Errorf("Expected fr file to contain 'expected_content'")
				}
			},
		},
	}
	
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			os.RemoveAll(testFolder)
			os.MkdirAll(testFolder, folderPermission)
			os.MkdirAll(filepath.Join(testFolder, "es"), folderPermission)
			os.MkdirAll(filepath.Join(testFolder, "fr"), folderPermission)
			
			processor := &XMLProcessor{}
			err := processor.Write(testOutputPattern, "es", "expected_content")
			if err != nil {
				t.Errorf("Expected no error writing file, got %v", err)
			}
			
			if tt.name == "both locales exist" {
				err = processor.Write(testOutputPattern, "fr", "expected_content")
				if err != nil {
					t.Errorf("Expected no error writing fr file, got %v", err)
				}
			}
			
			if tt.validator != nil {
				tt.validator(t)
			}
		})
	}
}

