package main

import (
	"io/ioutil"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

var (
	GlobalConfig *Config
)

type Config struct {
	Debug     bool
	MaxItems  int
	APIKey    string
}

func InitConfig() {
	GlobalConfig = &Config{
		Debug:    false,
		MaxItems: 100,
		APIKey:   "default-key",
	}
	
	// Override with environment variables
	if debug := os.Getenv("DEBUG"); debug != "" {
		GlobalConfig.Debug = debug == "true"
	}
	
	if maxItems := os.Getenv("MAX_ITEMS"); maxItems != "" {
		if val, err := strconv.Atoi(maxItems); err == nil {
			GlobalConfig.MaxItems = val
		}
	}
	
	if apiKey := os.Getenv("API_KEY"); apiKey != "" {
		GlobalConfig.APIKey = apiKey
	}
}

func GetConfig() *Config {
	if GlobalConfig == nil {
		InitConfig()
	}
	return GlobalConfig
}

func SetDebugMode(enabled bool) {
	GetConfig().Debug = enabled
}

// Filesystem utilities
const folderPermission = 0755

type XMLProcessor struct{}

func (p *XMLProcessor) Write(outputPattern string, locale string, content string) error {
	// Replace %locale% placeholder with actual locale
	outputPath := strings.Replace(outputPattern, "%locale%", locale, -1)
	
	// Create directory if it doesn't exist
	if err := os.MkdirAll(filepath.Dir(outputPath), folderPermission); err != nil {
		return err
	}
	
	return ioutil.WriteFile(outputPath, []byte(content), 0644)
}

func readFileContent(filePath string) (string, error) {
	content, err := ioutil.ReadFile(filePath)
	if err != nil {
		return "", err
	}
	return string(content), nil
}