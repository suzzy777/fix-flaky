package main

import (
	"context"
	"sync"
)

type Info struct {
	ID    string
	Email string
	Valid bool
}

type Program struct {
	Name  string
	Email string
}

type Request struct {
	Program *Program
}

type Database interface {
	GetInfo(ctx context.Context, id string, email string) (*Info, error)
	UpdateInfo(ctx context.Context, data *Info) error
}

type MockDatabase struct {
	mu       sync.Mutex
	infos    map[string]*Info
	updateCalled bool
}

func NewMockDatabase() *MockDatabase {
	return &MockDatabase{
		infos: make(map[string]*Info),
	}
}

func (db *MockDatabase) GetInfo(ctx context.Context, id string, email string) (*Info, error) {
	return &Info{
		ID:    id,
		Email: email,
		Valid: false,
	}, nil
}

func (db *MockDatabase) UpdateInfo(ctx context.Context, data *Info) error {
	db.mu.Lock()
	defer db.mu.Unlock()
	data.Valid = true
	db.infos[data.ID] = data
	db.updateCalled = true
	return nil
}

func (db *MockDatabase) WasUpdateCalled() bool {
	db.mu.Lock()
	defer db.mu.Unlock()
	return db.updateCalled
}

func (db *MockDatabase) GetUpdateResult(id string) *Info {
	db.mu.Lock()
	defer db.mu.Unlock()
	return db.infos[id]
}

func (db *MockDatabase) GetUpdateCount() int {
	db.mu.Lock()
	defer db.mu.Unlock()
	return len(db.infos)
}

type Controller struct {
	db Database
}

func NewController(db Database) *Controller {
	return &Controller{db: db}
}

func (c *Controller) AddProgram(ctx context.Context, program *Program) error {
	errorMap := ValidateIdentity(ctx, program, c)
	if len(errorMap) > 0 {
		return nil // For simplicity, we don't return errors
	}
	return nil
}

func ValidateIdentity(ctx context.Context, program *Program, c *Controller) map[string]string {
	data, err := c.db.GetInfo(ctx, "123", program.Email)
	if err != nil {
		return map[string]string{"error": "failed to get info"}
	}
	
	go c.db.UpdateInfo(ctx, data)
	
	return map[string]string{}
}

type Handler struct {
	controller *Controller
}

func NewHandler(controller *Controller) *Handler {
	return &Handler{controller: controller}
}

func (h *Handler) AddProgram(ctx context.Context, request *Request) error {
	return h.controller.AddProgram(ctx, request.Program)
}

type Validator struct {
	controller *Controller
}

func NewValidator(controller *Controller) *Validator {
	return &Validator{controller: controller}
}

func (v *Validator) ValidateProgram(ctx context.Context, program *Program) error {
	go func() {
		data, _ := v.controller.db.GetInfo(ctx, "concurrent-123", program.Email)
		v.controller.db.UpdateInfo(ctx, data)
	}()
	return nil
}