package main

import (
	"sync"
	"sync/atomic"
	"time"
)

type TimestampedCounter struct {
	value     atomic.Int64
	timestamp atomic.Int64
	mu        sync.Mutex
	updates   []CounterUpdate
}

type CounterUpdate struct {
	Value     int64
	Timestamp int64
}

func NewTimestampedCounter() *TimestampedCounter {
	return &TimestampedCounter{
		updates: make([]CounterUpdate, 0),
	}
}

func (tc *TimestampedCounter) Increment() {
	// Value and timestamp updates are not atomic together
	newValue := tc.value.Add(1)
	newTimestamp := time.Now().UnixNano()
	tc.timestamp.Store(newTimestamp)
	
	// Record the update
	tc.mu.Lock()
	tc.updates = append(tc.updates, CounterUpdate{
		Value:     newValue,
		Timestamp: newTimestamp,
	})
	tc.mu.Unlock()
}

func (tc *TimestampedCounter) GetValue() int64 {
	return tc.value.Load()
}

func (tc *TimestampedCounter) GetTimestamp() int64 {
	return tc.timestamp.Load()
}

func (tc *TimestampedCounter) GetUpdates() []CounterUpdate {
	tc.mu.Lock()
	defer tc.mu.Unlock()
	
	result := make([]CounterUpdate, len(tc.updates))
	copy(result, tc.updates)
	return result
}

func (tc *TimestampedCounter) ValidateMonotonicity() bool {
	updates := tc.GetUpdates()
	
	for i := 1; i < len(updates); i++ {
		// Check timestamps are monotonic
		if updates[i].Timestamp < updates[i-1].Timestamp {
			return false
		}
		// Check if values are monotonic
		if updates[i].Value < updates[i-1].Value {
			return false
		}
	}
	return true
}