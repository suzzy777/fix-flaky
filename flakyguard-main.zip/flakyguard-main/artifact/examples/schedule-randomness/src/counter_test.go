package main

import (
	"runtime"
	"sync"
	"testing"
	"time"
)

func TestCounterIncrement(t *testing.T) {
	counter := NewTimestampedCounter()
	
	done := make(chan bool, 3)
	
	go func() {
		counter.Increment()
		done <- true
	}()
	
	go func() {
		counter.Increment()
		done <- true
	}()
	
	go func() {
		counter.Increment()
		done <- true
	}()
	
	for i := 0; i < 3; i++ {
		<-done
	}
	
	expectedValue := int64(3)
	actualValue := counter.GetValue()
	if actualValue != expectedValue {
		t.Errorf("Expected final value %d, got %d", expectedValue, actualValue)
	}
	
	if !counter.ValidateMonotonicity() {
		t.Error("Counter updates are not monotonic")
	}
}

func TestConcurrentIncrements(t *testing.T) {
	counter := NewTimestampedCounter()
	
	startTime := time.Now().UnixNano()
	ready := make(chan bool, 5)
	
	for i := 0; i < 5; i++ {
		go func() {
			ready <- true
			counter.Increment()
		}()
	}
	
	for i := 0; i < 5; i++ {
		<-ready
	}
	
	runtime.Gosched()
	
	finalTimestamp := counter.GetTimestamp()
	finalValue := counter.GetValue()
	
	if finalValue != 5 {
		t.Errorf("Expected 5 increments, got %d", finalValue)
	}
	
	if finalTimestamp < startTime {
		t.Error("Final timestamp should be after start time")
	}
}