package main

import (
	"context"
	"testing"
	"time"
)

func TestGoroutineScheduling(t *testing.T) {
	mockDB := NewMockDatabase()
	controller := NewController(mockDB)
	handler := NewHandler(controller)
	
	request := &Request{
		Program: &Program{
			Name:  "test-program",
			Email: "test@example.com",
		},
	}
	
	err := handler.AddProgram(context.Background(), request)
	if err != nil {
		t.Errorf("Expected no error, got %v", err)
	}
	
	time.Sleep(time.Microsecond * 10)
	
	if !mockDB.WasUpdateCalled() {
		t.Errorf("Expected UpdateInfo to be called, but it wasn't")
	}
}

