# FlakyGuard

FlakyGuard automatically detects and fixes flaky tests in software projects using large language models guided by dynamic call graph analysis. This tool addresses the context problem in LLM-based flaky test repair by providing precisely the right amount of code context needed for effective analysis and fixing.

## Installation

### Prerequisites

- Python 3.8+
- Bazel build system
- Go toolchain
- Linux/macOS system
- OpenAI API access or compatible LLM service

### Quick Setup

Run the automated setup script from the artifact root directory:

```bash
bash setup_environment.sh
```

This script will:
- Install required system dependencies (gcc-aarch64-linux-gnu on Linux)
- Create a Python virtual environment
- Install all Python dependencies with correct versions
- Build tree-sitter grammars for all supported languages
- Verify the installation

### Manual Setup

If you prefer manual installation:

```bash
# 1. Install system dependencies
# On Linux:
sudo apt-get install gcc-aarch64-linux-gnu python3-venv python3-pip
# On macOS: ensure Xcode command line tools are installed

# 2. Create virtual environment
python3 -m venv venv
source venv/bin/activate

# 3. Install Python dependencies
pip install "tree-sitter==0.21.0" openai networkx sourcelocation pocketflow
pip install -e flakyguard

# 4. Build tree-sitter grammars
cd flakyguard/llm/tree-sitter-grammars
bash build-grammars.sh
cd ../../../

# 5. Set Python path
export PYTHONPATH="$(pwd)/flakyguard:$PYTHONPATH"
```

## Usage

### Environment Activation

Before running FlakyGuard, activate the environment:

```bash
# Activate virtual environment
source venv/bin/activate

# Set Python path
export PYTHONPATH="$(pwd)/flakyguard:$PYTHONPATH"
```

### Command Line Interface

**FlakyGuard Lite** (recommended for most use cases):
```bash
bash flakyguard/scripts/flakyguard_lite.sh <project_path> <test_target> <test_case>

# Example
bash flakyguard/scripts/flakyguard_lite.sh ./examples/floating-point "//:go_default_test" "TestAccumulateSum"
```

**Direct Python execution** (for advanced configuration):
```bash
python3 -m flakyguard.core.flaky_fixing_driver \
  --test-target //path/to:test \
  --test-case TestMethodName \
  --monorepo-root /path/to/project \
  --max-attempts 3 \
  --model o1 \
  --temperature 0.1
```

### Input Format

FlakyGuard accepts flaky test reports from ticketing systems in conventional Bazel format:
- `test_target`: Bazel target containing multiple test functions (e.g., `//src/main:unit_tests`)
- `test_func`: Go test function containing multiple test cases following table-driven testing patterns
- `test_case`: Specific test case within the function that exhibits flaky behavior

### Parameters

- `--test-target`: Bazel test target
- `--test-case`: Specific test method name
- `--monorepo-root`: Project root directory
- `--max-attempts`: Maximum fix attempts (default: 3)
- `--model`: LLM model selection (default: o1)
- `--temperature`: LLM temperature (default: 0.1)
- `--verbose`: Enable detailed logging

## Architecture

```
flakyguard/
├── core/                          # Main fixing engine
│   ├── flaky_fixing_driver.py     # CLI entry point
│   ├── flaky_fixing_flow.py       # Workflow orchestration using pocketflow
│   ├── flaky_fixing.py            # Core fixing logic and problem representation
│   ├── context_collection.py      # Graph-based context gathering
│   └── prompts.py                 # LLM prompt templates
├── analysis/                      # Code analysis components
│   ├── repograph/                 # Call graph analysis and traversal
│   └── domain_specific/           # Specialized analyzers
│       ├── flakytest/             # Flaky test detection and validation
│       └── compilation_defect/    # Build error analysis
├── editing/                       # Code modification utilities
│   ├── search_and_replace_editing.py
│   └── search_replace_editor.py
├── llm/                          # Language model integration
│   ├── llm.py                    # LLM interface and completion logic
│   ├── tree_sitter_util.py       # Code parsing with Tree-sitter
│   └── tree-sitter-grammars/     # Language grammar binaries
├── utils/                        # Supporting utilities
│   ├── coverage/                 # Test coverage computation
│   ├── test_helper/              # Test discovery and manipulation
│   └── bazel_cmd.py             # Bazel build system integration
└── scripts/
    └── flakyguard_lite.sh        # Convenient shell wrapper
```

## Problem Statement

Flaky tests non-deterministically pass or fail when rerun on identical code, creating significant challenges in software development. When tests fail, developers cannot distinguish between real bugs and test flakiness, forcing them to spend time investigating false alarms and blocking code deployment until all failures are resolved.

Existing LLM-based repair approaches like FlakyDoctor suffer from the **context problem**:

- **Too little context**: Providing only test code causes LLMs to miss critical production code information necessary for proper reasoning and root cause analysis
- **Too much context**: Including entire codebases (100K+ LOCs in medium-sized industrial services) overwhelms LLMs, diffusing attention and degrading performance on complex reasoning tasks

FlakyGuard solves this by treating code as a graph structure and using LLM-guided exploration of dynamic call graphs to identify precisely the right amount of context for effective repair and clear root cause explanations.

## Technical Approach

### Dynamic Call Graph Construction

A **Dynamic Call Graph (DCG)** is a graph representation of function call relationships captured during actual program execution, as opposed to static call graphs which are derived from source code analysis. FlakyGuard uses a DCG approach that is equivalent to the methodology described in the paper, i.e., it produces the same DCG, with a slightly simplified implementation which helps simplify our tool release process.

FlakyGuard constructs call graphs from actual test execution rather than static analysis: It constructs the repograph to represent the code and then leverage teh runtime test coverage to prune the un-executed nodes, thereby ensuring the final DCG is equivalent to the approach in the paper. 


### LLM-Guided Graph Traversal

FlakyGuard addresses the context problem through selective graph exploration rather than naive BFS/DFS that would include entire graphs:

**Smart Graph Traversal Algorithm:**
1. Start from root nodes (test functions) in the dynamic call graph
2. At each traversal level:
   - Collect all direct child functions
   - Use LLM to select up to k most relevant children based on flaky test error context
   - Add selected nodes to traversal queue
3. Continue until depth limit d or no more relevant nodes found
4. **Global post-processing**: LLM selects up to F most relevant functions from entire traversal result

This approach enables reaching critical information at arbitrary depths (overcoming depth-limited approaches like RepoGraph) while maintaining manageable context sizes for effective LLM reasoning.

### Multi-Loop Fix Generation

FlakyGuard employs three nested loops with progressively enriched prompts:

**Outer loop (M iterations)**: Context collection rounds
- Collect new contexts from dynamic call graph traversal
- Uses flakiness information and failure details

**Middle loop (P iterations)**: High-level thought generation  
- Generate thoughts containing root cause category, detailed explanation, and fixing strategy
- Incorporates context from graph traversal
- Records failed thoughts to avoid ineffective strategies (Reflection paradigm)

**Inner loop (N iterations)**: Fix generation and validation
- Generate specific code fixes aligned with high-level thoughts  
- Apply fixes using test simplification and patch transplantation
- Validate through build compilation and test execution (N repetitions)
- Revert and iterate if validation fails

### Test Simplification and Patch Transplantation

Industrial Go codebases predominantly use table-driven testing patterns. FlakyGuard includes specialized handling:

- **Test simplification**: AST-based extraction of specific test cases from table structures
- **Patch transplantation**: Applies fixes from simplified code back to original table-driven tests
- **Ambiguity resolution**: Handles search-and-replace challenges in complex test structures

Before flakiness reproduction, FlakyGuard simplifies the test function T_orig to keep only the targeted test case while removing all other sibling test cases, yielding a simplified test function T_simp. The LLM generates fixes for T_simp, then FlakyGuard transplants these edits back to the full context using a two-step AST-based approach that preserves fixes outside the test table while maintaining the original table structure.

## Workflow

### 1. Failure Reproduction

FlakyGuard first reproduces the flaky behavior:
- Execute test N times (default: 1000)
- If no failures occur, execute entire test target and filter results
- Extract error messages, stack traces, assertion details, and file paths

### 2. Dynamic Call Graph Construction

We capture the dynamic call graph specific to the test run, by building the repograph and the leveraging the runtime coverage information to prune the graph. 

### 3. Context Collection

Using the smart graph traversal algorithm:
1. Start from test function root nodes
2. LLM selects most relevant child functions at each level
3. Continue traversal until depth limit or no relevant nodes remain
4. Final selection of most relevant functions globally

### 4. Fix Generation and Validation

- **Build validation**: Ensure modified code compiles successfully
- **Test validation**: Rerun test N times, requiring all runs to pass
- **Best-effort repair**: Attempt to fix compilation errors using LLM
- **Developer review**: Submit successful fixes for code review

## Supported Flaky Test Categories

Based on evaluation of 197 real-world flaky tests in industrial repositories:

- **Schedule Randomness (37%)**: Non-deterministic thread scheduling in concurrent programs
  - Go `select` statements with multiple ready cases
  - Asynchronous operations not properly synchronized
  - Atomicity violations in multi-threaded code
- **Random iteration of unordered collections (33%)**: Map iteration order assumptions
  - Go map iteration producing different orders across executions
  - Tests expecting fixed element ordering from unordered data structures
- **Timestamp Discrepancy (12%)**: Different `time.Now()` calls in expected vs actual values
  - Data structures with timestamp fields set at different execution points
  - Timing-sensitive comparisons failing due to millisecond differences
- **Pollution (8%)**: Shared state contamination between parallel tests
  - Global environment variables modified by concurrent tests
  - Shared file system paths causing interference
  - Database state leaking between test runs
- **Time-dependent Flakiness (7%)**: Tests relying on wall clock time progression
  - Deep call chains with time-dependent validation logic
  - Race conditions between test setup and time-sensitive production code
- **Others (3%)**: Miscellaneous categories including statistical sampling and random input validation

## Examples

### Schedule Randomness Fix

**Before (flaky)**:
```go
func TestEmitLoop(t *testing.T) {
    // select statement is non-deterministic when multiple cases are ready
    select {
    case <-ticker.C:
        // executes one iteration
    case <-ctx.Done():
        // executes two iterations, fails mock expectation
    }
}
```

**After (fixed)**:
```go
func TestEmitLoop(t *testing.T) {
    // Increase timerPeriod so ticker.C becomes ready later than ctx.Done()
    timerPeriod := 5 * time.Second // was 1 * time.Second
    // Now first case is reliably selected
}
```

### Random Map Iteration Fix

**Before (flaky)**:
```go
func TestMapOrder(t *testing.T) {
    input := formatFromMap(data) // map iteration order varies
    mock.EXPECT().Call(input)    // only accepts specific string order
}
```

**After (fixed)**:
```go
func TestMapOrder(t *testing.T) {
    // Use custom matcher that accepts alternative input strings
    mock.EXPECT().Call(gomock.Any()).Do(func(input string) {
        assert.Contains(t, []string{expected1, expected2}, input)
    })
}
```

### Timestamp Discrepancy Fix

**Before (flaky)**:
```go
func TestTimestamp(t *testing.T) {
    expected := createExpected() // calls time.Now()
    actual := processData()      // also calls time.Now()
    assert.Equal(t, expected, actual) // fails due to timing difference
}
```

**After (fixed)**:
```go
func TestTimestamp(t *testing.T) {
    fixedTime := time.Now()
    expected := createExpectedWithTime(fixedTime)
    actual := processDataWithTime(fixedTime)
    assert.Equal(t, expected, actual)
}
```

## Configuration

### Environment Variables

```bash
# Required
export OPENAI_API_KEY="your-api-key"
export PYTHONPATH="/path/to/flakyguard:$PYTHONPATH"

# Optional
export OPENAI_BASE_URL="https://api.openai.com/v1"
export BAZEL_OPTS="--test_output=all"
```

### Tunable Parameters

- **Depth limit (d)**: Maximum graph traversal depth (default: unlimited)
- **Children per node (k)**: Maximum LLM-selected children per node
- **Fix attempts (N)**: Fixes generated per high-level thought
- **Thoughts (P)**: High-level thoughts generated per context
- **Context iterations (M)**: Context collection rounds

**Default experimental setup:**
- M=3 (context collection rounds)
- P=2 (thoughts per context)  
- N=3 (fixes per thought)
- d=infinite (depth limit)
- F=5 (max functions retained in post-processing)

## Evaluation Results

**6-month deployment on real-world industrial repositories:**
- **197 flaky tests** analyzed across Go monorepo
- **71.6% reproduction rate** (141 tests successfully reproduced failures)
- **47.6% repair rate** (67 fixes generated for reproducible tests)  
- **51.8% developer acceptance rate** (35 fixes accepted and landed)
- **22%+ improvement** over state-of-the-art LLM-based approaches (Agentless, AutoCodeRover, RepoGraph)
- **100% of developers** found root cause explanations useful in anonymous surveys

## Output

### Log Files

Execution logs are saved to `<project>/bazel-out/flakyguard_lite/log_<timestamp>` containing:
- Failure reproduction details
- Call graph construction progress
- Context collection decisions
- Fix generation and validation results

### Generated Fixes

Successful fixes include:
- Modified test code with clear annotations
- Root cause analysis and explanation
- Fixing strategy rationale
- Validation test results

## Troubleshooting

### Common Issues

**API Rate Limiting (HTTP 429)**:
- Tool implements automatic exponential backoff
- Monitor logs for retry patterns
- Consider distributing load across API endpoints

**Timeouts**:
- Default timeout: 1 hour (configurable in script)
- Break large test suites into smaller components
- Optimize context size through parameter tuning

**No Failures Reproduced**:
- Try running with increased repetitions (--runs-per-test=2000)
- Enable race detection flag for schedule randomness issues
- Check test target specification format

### Debug Mode

Enable verbose logging for detailed execution traces:
```bash
python3 -m flakyguard.core.flaky_fixing_driver --verbose \
  --test-target //your:test --test-case YourTest
```

## Development

### Extending FlakyGuard

**Adding new flaky test categories**:
1. Implement analyzer in `analysis/domain_specific/`
2. Add classification logic in `core/flaky_fixing.py`
3. Define prompt templates in `core/prompts.py`

**Language support**:
1. Add Tree-sitter grammar to `llm/tree-sitter-grammars/`
2. Update language definitions in `definitions/language.py`
3. Extend parsing logic in `llm/tree_sitter_util.py`

**Build system integration**:
1. Extend `utils/bazel_cmd.py` for new build commands
2. Add test discovery in `utils/test_helper/`
3. Update scope definitions for project structures
