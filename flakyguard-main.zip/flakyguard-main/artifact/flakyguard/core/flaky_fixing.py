"""The building blocks of flaky test fixing, to be used in flaky_fixing_flow.py.

It has these basic steps:
- Problem -> Context
- Context -> Fix
- Fix -> Apply
- Apply -> Validate
"""

from __future__ import annotations

import dataclasses
import logging
import os

logger = logging.getLogger(__name__)

from flakyguard.analysis.domain_specific.flakytest.flakyinfo import FlakyInfo
from flakyguard.analysis.domain_specific.flakytest.validate_flakiness_gone import validate_flakiness_gone
from flakyguard.editing.search_replace_editor import (
    SearchReplaceEdit,
    apply_edits_by_file_atomically,
    extract_explanation,
    extract_search_replace_edits,
    get_search_replace_edits_and_explanation_format,
)
from flakyguard.utils.method_utils import get_method_name
from flakyguard.utils.fix_build_errors import fix_build_errors
from flakyguard.llm.llm import LLMWrapper
from flakyguard.utils.test_helper.finder import get_test_func_node_from_file
from flakyguard.utils.test_helper.simplification_and_patching import (
    get_original_and_simplified_test_func,
)
from flakyguard.analysis.repograph.ast_util import TreesitterNode
from flakyguard.analysis.repograph.repograph_graph import RepographBuilder
from flakyguard.core.context_collection import (
    _extract_imports_from_file,
    search_func_nodes_with_builder,
)
from flakyguard.core.loader import get_best_practices
from flakyguard.core.prompts import get_flaky_test_fixing_prompt

# Constant temperature for LLM
TEMPERATURE = 0.1
MODEL = "drfix/drfix-sonnet4"
MAX_FIX_BUILD_RETRIES = 3


@dataclasses.dataclass
class Problem:
    test_input: TestInput
    flaky_info: FlakyInfo
    builder: RepographBuilder | None = None


@dataclasses.dataclass
class Context:
    file_to_func_nodes: dict[str, list[TreesitterNode]]
    file_to_imports: dict[str, list[TreesitterNode]]



@dataclasses.dataclass
class Fix:
    edits_by_file: dict[str, list[SearchReplaceEdit]]
    explanation: str


@dataclasses.dataclass
class TestInput:
    """Input configuration for a test to be fixed."""

    test_target: str
    test_case: str
    monorepo_root: str
    test_file: str | None = None
    language: str = "go"
    test_speed: int = 2


def problem_to_context(problem: Problem) -> Context | None:
    """Convert a Problem to Context by gathering relevant code context."""
    try:
        # Check if builder is available
        if not problem.builder:
            return None

        full_test_file_path = os.path.join(problem.test_input.monorepo_root, problem.test_input.test_file)
        
        test_func_name = None
        test_func_node = get_test_func_node_from_file(full_test_file_path, problem.test_input.test_case)
        
        if test_func_node:
            test_func_name = get_method_name(test_func_node)
        
        if not test_func_name:
            return None

        # Perform search using the pre-setup builder
        context_func_nodes = search_func_nodes_with_builder([test_func_name], problem.builder, problem.test_input, problem.flaky_info, callee_only=True)

        # Group nodes by filename
        file_to_func_nodes = {}
        all_files = set()
        if context_func_nodes:
            for node in context_func_nodes:
                if node.filename not in file_to_func_nodes:
                    file_to_func_nodes[node.filename] = []
                file_to_func_nodes[node.filename].append(node)
                all_files.add(node.filename)

        # Add the test file to the list of files to extract imports from
        all_files.add(full_test_file_path)

        # Extract imports from ALL files in the context
        file_to_imports = {}
        for filepath in all_files:
            import_string = _extract_imports_from_file(filepath, problem.test_input.language)
            if import_string:
                file_to_imports[filepath] = import_string

        context = Context(file_to_func_nodes=file_to_func_nodes, file_to_imports=file_to_imports)
        return context

    except Exception as e:
        logger.error(f"Error in problem_to_context: {e}")
        return None


def context_to_fix(problem: Problem, context: Context, model: str = MODEL, temperature: float = TEMPERATURE) -> Fix | None:
    """Convert Problem and Context to Fix using LLM analysis."""
    try:
        full_test_file_path = os.path.join(problem.test_input.monorepo_root, problem.test_input.test_file)

        # Get simplified test content WITHOUT modifying the file, which serves as a guidance or reference for the LLM.
        original_test_func_str, simplified_test_func_str = get_original_and_simplified_test_func(
            full_test_file_path,
            problem.test_input.test_case,
        )

        # Format context nodes for prompt
        formatted_context = ""
        formatted_sections = []

        if context.file_to_func_nodes:
            for filename, nodes in context.file_to_func_nodes.items():
                for node in nodes:
                    node_text = node.node.text.decode()
                    formatted_sections.append(f"=== {filename} ===\n{node_text}\n")
                if filename in context.file_to_imports:
                    imports_text = context.file_to_imports[filename]
                    formatted_sections.append(f"=== {filename} (imports) ===\n{imports_text}\n")

        if formatted_sections:
            formatted_context = "\n".join(formatted_sections)

        prompt = get_flaky_test_fixing_prompt(
            simplified_test_code=simplified_test_func_str or "",
            original_test_code=original_test_func_str or "",
            assertion_failures=problem.flaky_info.error,
            error_trace=problem.flaky_info.error_trace,
            code_context=formatted_context,
            language=problem.test_input.language,
            output_format=get_search_replace_edits_and_explanation_format(),
            best_practices=get_best_practices(),
        )

        # this produces the list of search/replace edits, the imports needed and the explanation of root cause.
        llm = LLMWrapper.get_instance()
        response = llm.get_completion(message=prompt, temperature=temperature, model=model)

        if not response:
            return None

        # Parse response to extract search-replace edits and explanation
        explanation = extract_explanation(response) or ""

        # Extract search-replace edits from response using the proper format
        all_edits = extract_search_replace_edits(response)

        # Group edits by full filepath (resolve paths)
        edits_by_file = {}
        for edit in all_edits:
            # If the edit doesn't specify a filepath, use the test file
            filepath = edit.filepath if edit.filepath else problem.test_input.test_file

            if not os.path.isabs(filepath):
                full_filepath = os.path.join(problem.test_input.monorepo_root, filepath)
            else:
                full_filepath = filepath

            if full_filepath not in edits_by_file:
                edits_by_file[full_filepath] = []
            edits_by_file[full_filepath].append(edit)

        return Fix(edits_by_file=edits_by_file, explanation=explanation)

    except Exception as e:
        print(f"Error in context_to_fix: {e}")
        return None


def apply_fix(fix: Fix) -> tuple[bool, dict | str]:
    """Apply the search-replace edits from the Fix object.

    Returns:
        On success: (True, dict mapping filepath to FileBackup objects)
        On failure: (False, error_message: str)
    """

    if not fix.edits_by_file:
        return False, "No search-replace edits to apply"

    try:
        # Use the new edits_by_file atomic method (no need for monorepo_root since paths are already resolved)
        success, result = apply_edits_by_file_atomically(fix.edits_by_file)

        return success, result

    except Exception as e:
        return False, f"Error applying fix: {str(e)}"


def validate_fix(test_input: TestInput, files_modified: list[str] | None = None) -> bool:
    """Validate that the fix actually resolves the flakiness.

    Args:
        test_input: Test input configuration
        files_modified: List of files that were modified by the fix

    This function now includes build error fixing to increase the chance of success:
    1. Attempts to fix format, import, and compilation errors
    2. Validates that the fix resolves the flakiness
    """

    # Try to fix build errors up to MAX_FIX_BUILD_RETRIES times
    fix_build_result = None
    for _ in range(MAX_FIX_BUILD_RETRIES):
        fix_build_result = fix_build_errors(
            files_modified=files_modified,
            test_target=test_input.test_target,
            monorepo_root=test_input.monorepo_root,
            language=test_input.language,
        )

        if fix_build_result.success:
            break  # Success, no need to retry

    if not fix_build_result or not fix_build_result.success:
        return False  # validation fails after all retries

    # Validate that the fix resolves the flakiness
    is_fixed, _ = validate_flakiness_gone(
        test_target=test_input.test_target,
        test_case=test_input.test_case,
        monorepo_root=test_input.monorepo_root,
    )

    return is_fixed
