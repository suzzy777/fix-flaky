"""
Prompt utilities for flakyguard_lite with enhanced table-driven testing guidance.
"""

from __future__ import annotations

from flakyguard.core.loader import get_best_practices, get_table_driven_testing_guidance
from flakyguard.definitions.language import Language


def get_flaky_test_fixing_prompt(
    simplified_test_code: str,
    original_test_code: str,
    assertion_failures: str,
    error_trace: str,
    code_context: str,
    language: Language,
    output_format: str,
    best_practices: str | None = None,
) -> str:
    """
    Generate a comprehensive prompt for fixing flaky tests with enhanced guidance.

    Args:
        simplified_test_code: Simplified version for LLM reference
        original_test_code: Original test code to be edited
        assertion_failures: Error messages from the flaky test
        error_trace: Stack trace of the failure
        code_context: Additional context about the test
        language: Programming language for the test
        output_format: Format instructions for the LLM output
        best_practices: Additional best practices guidance for fixing flaky tests
    """
    best_practices_text = best_practices or get_best_practices()

    return f"""You are an expert at fixing flaky tests in {language}. Your goal is to identify and fix the root cause of non-deterministic test behavior.

{get_table_driven_testing_guidance()}

{best_practices_text}

## Test Analysis

**Simplified test for reference (to help you understand the structure):**
```{language}
{simplified_test_code}
```

**Original test to be fixed:**
```{language}
{original_test_code}
```

**Error messages:**
```
{assertion_failures}
```

**Stack trace:**
```
{error_trace}
```

**Additional context:**
```
{code_context}
```

## Common Flaky Test Patterns to Look For

1. **Random Map Iteration**: `for k, v := range map` iterates in random order
2. **Timing Issues**: Race conditions, goroutines finishing in different orders
3. **Shared State**: Global variables or shared resources between tests
4. **Non-deterministic Algorithms**: Random number generation, UUID generation
5. **External Dependencies**: Network calls, file system, time-dependent code

## Fixing Strategy

1. **Analyze the error**: Look for patterns indicating non-deterministic behavior
2. **Identify the root cause**: Map iteration, timing, shared state, etc.
3. **Apply appropriate fix**:
   - Sort collections before comparison
   - Use deterministic test data
   - Isolate test state
   - Add proper synchronization
   - Mock non-deterministic dependencies

4. **Focus on the specific failing test case** rather than modifying shared setup
5. **Fix the test logic instead of the code under test, unless you strongly believe that the code under test is buggy.**


{output_format}

## Required Output

Please analyze the test failure and provide:

1. **The necessary fixes** using the SEARCH/REPLACE format above, note the search should be with respect to the original test function.
2. **A brief explanation** wrapped in EXPLANATION tags if using the combined format.
"""
