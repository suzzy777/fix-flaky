"""Context gathering utilities for flaky test fixing."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from flakyguard.analysis.domain_specific.flakytest.flakyinfo import FlakyInfo
from flakyguard.utils.coverage.compute_coverage import compute_coverage
from flakyguard.analysis.repograph.ast_util import TreesitterNode
from flakyguard.analysis.repograph.filter import coverage_filter
from flakyguard.analysis.repograph.repograph_graph import RepographBuilder
from flakyguard.analysis.repograph.repograph_search import RepographSearcher, SearchStrategy
from flakyguard.analysis.repograph.scope.coverage_scope import coverage_scope
from flakyguard.analysis.repograph.scope.file_scope import file_scope_relative
from flakyguard.definitions.language import Language
from flakyguard.llm import tree_sitter_util as ts_util


def get_context_files(monorepo_root: str, test_target: str, test_case: str, test_file: str, language: Language) -> set[str]:
    """Get context files using intersection of 3 scopes: test coverage, parent's parent, and bazel deps."""
    try:
        # 1. Test coverage scope
        coverage_files = coverage_scope(monorepo_root, test_target, test_case, include_test_files=True, retries=10, language=language)

        # 2. Local folder's parent's parent (up_level=2)
        file_scope_files = set(file_scope_relative(monorepo_root, test_file, up_level=2, include_test=True))

        if coverage_files and file_scope_files:
            common_files = coverage_files & file_scope_files
        else:
            common_files = coverage_files or file_scope_files or set()
            
        # Add relative test file
        relative_test_file = test_file.replace(monorepo_root, "").strip("/") if test_file.startswith(monorepo_root) else test_file
        if relative_test_file not in common_files:
            common_files.add(relative_test_file)

        return common_files

    except Exception as e:
        logger.error(f"Error in get_context_files: {e}")
        return set()


def setup_repograph_builder(test_input) -> RepographBuilder | None:
    """Setup RepographBuilder with coverage filtering - takes test_input and handles all setup."""
    try:
        # Get context files for additional information
        context_files = get_context_files(
            test_input.monorepo_root,
            test_input.test_target,
            test_input.test_case,
            test_input.test_file,
            test_input.language,
        )

        # Get coverage report for filtering
        coverage_report = compute_coverage(
            test_input.monorepo_root,
            test_input.test_target,
            test_input.test_case,
            include_test_files=True,
            language=test_input.language,
        )

        # Create coverage filter function
        is_python = test_input.language == "python"

        def filter_func(tag):
            return coverage_filter(coverage_report, tag, is_python)

        # Create RepographBuilder with coverage filter
        builder = RepographBuilder(test_input.monorepo_root, context_files, filter_func)
        return builder

    except Exception as e:
        logger.error(f"Error in setup_repograph_builder: {e}")
        return None


def search_func_nodes_with_builder(
    start_funcs: list[str], builder, test_input, flaky_info: FlakyInfo, depth_limit: int = -1, callee_only: bool = False, callers_only: bool = False
) -> list[TreesitterNode]:
    """Perform search using pre-setup RepographBuilder - can be parallelized in future."""
    try:
        # Create repograph searcher with pre-filtered builder
        problem_statement = f"Flaky test: {test_input.test_case}. Error: {flaky_info.error}"
        searcher = RepographSearcher(problem_statement=problem_statement, builder=builder, callee_only=callee_only, callers_only=callers_only)

        # Use smart BFS to find relevant functions (already filtered by coverage)
        relevant_tags = searcher.search(
            start_funcs=start_funcs,
            strategy=SearchStrategy.SMART_BFS,
            depth_limit=depth_limit,  # Limit depth to avoid too much context
        )

        tree_sitter_nodes = builder.tags_to_treesitter_nodes(relevant_tags)
        return tree_sitter_nodes

    except Exception as e:
        logger.error(f"Error in search_func_nodes_with_builder: {e}")
        return []


def _extract_imports_from_file(filepath: str, language: Language) -> str | None:
    """Extract import declarations from a file using tree-sitter.

    Args:
        filepath: Path to the file
        language: Programming language for tree-sitter parsing

    Returns:
        List of ImportWrapper objects or None if extraction fails
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            file_content = f.read()

        # Use tree-sitter to find ALL import declarations
        parser, _ = ts_util.create_parser(language)
        tree = parser.parse(file_content.encode("utf-8"))

        import_node_types = ts_util.IMPORT_NODE_TYPES[language]
        
        # Find all import_declaration nodes
        import_nodes = ts_util.find_nodes_by_type(tree.root_node, import_node_types)
        
        if import_nodes:
            first_import_node = import_nodes[0]
            last_import_node = import_nodes[-1]
            extracted_content = file_content[first_import_node.start_byte:last_import_node.end_byte]
            return extracted_content
        else:
            return ""
            
    except Exception as e:
        logger.error(f"Error in _extract_imports_from_file: {e}")
        return ""
