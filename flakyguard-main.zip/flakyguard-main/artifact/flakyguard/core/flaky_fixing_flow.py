"""Flaky test fixing flow using pocketflow framework.

This module refactors the flaky test fixing workflow into a structured flow
using the pocketflow framework.
"""

from __future__ import annotations

import logging

from pocketflow import Flow, Node

from flakyguard.analysis.domain_specific.flakytest.collect_flakytest import collect_flakytest
from flakyguard.editing.search_replace_editor import precheck_edits_by_file, create_patch_files
from flakyguard.utils.test_helper.finder import find_test_file_with_test_case
from .context_collection import setup_repograph_builder
from .flaky_fixing import Problem, TestInput, apply_fix, context_to_fix, problem_to_context, validate_fix

MAX_ATTEMPTS = 3
VERBOSE = True  # Global flag for verbose logging
logger = logging.getLogger(__name__)
# configure logging to show timestamp
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")


def clean_data_for_restart(data):
    """Clean data dictionary keeping only essential keys for restart.

    Args:
        data: The data dictionary to clean
        extra_keys: Additional keys to keep beyond test_input and problem
    """
    essential_keys = ["test_input", "problem", "attempts", "model", "temperature"]

    essential_data = {key: data[key] for key in essential_keys if key in data}
    data.clear()
    data.update(essential_data)


class SetupProblemNode(Node):
    """Node to detect flaky test, setup RepographBuilder, and create Problem object."""

    def prep(self, data):
        if VERBOSE:
            logger.info("SetupProblemNode: Detecting flaky test and setting up problem")
        return data.get("test_input")

    def exec(self, test_input: TestInput):
        if not test_input:
            return None, "No test input provided"

        # Ensure test_input.test_file is set
        if not test_input.test_file:
            test_input.test_file = find_test_file_with_test_case(test_input.test_target, test_input.test_case, test_input.monorepo_root)

        if not test_input.test_file:
            return None, "Test file not found"

        # Test speed determines number of runs: fast tests (speed >= 5) need fewer runs
        runs_per_test = 300 if test_input.test_speed >= 5 else 1000

        # Detect flakiness
        flaky_info = collect_flakytest(
            test_target=test_input.test_target,
            test_case=test_input.test_case,
            monorepo_root=test_input.monorepo_root,
            runs_per_test=runs_per_test,
        )

        if not flaky_info:
            return None, "No flaky behavior detected"

        # Setup repograph builder
        builder = setup_repograph_builder(test_input)

        return Problem(test_input=test_input, flaky_info=flaky_info, builder=builder), None

    def post(self, data, prep_res, exec_res):
        problem, error = exec_res
        if problem is None:
            data["error"] = error
            return "fail"

        data["problem"] = problem
        return "produce_fix"


class ProblemToFixNode(Node):
    """Node to convert Problem to Fix by gathering context and generating fix."""

    def prep(self, data):
        attempts = data.get("attempts", 0) + 1
        data["attempts"] = attempts

        if VERBOSE:
            logger.info(f"ProblemToFixNode: Starting fix generation (attempt {attempts}/{MAX_ATTEMPTS})")

        if attempts <= MAX_ATTEMPTS:
            problem = data.get("problem")
            model = data.get("model", "drfix/drfix-sonnet4")
            temperature = data.get("temperature", 0.1)
            return (problem, model, temperature)
        else:
            return None

    def exec(self, prep_res):
        if not prep_res:
            return None, "No prep result provided"
        problem, model, temperature = prep_res
        if not problem:
            return None, "No problem provided"

        try:
            # First convert problem to context
            context = problem_to_context(problem)
            if not context:
                return None, "Failed to generate context from problem"

            # Then convert problem and context to fix
            fix = context_to_fix(problem, context, model=model, temperature=temperature)
            if not fix or not fix.edits_by_file:
                return None, "Failed to generate fix from context"

            is_valid, validation_error = precheck_edits_by_file(fix.edits_by_file)
            if not is_valid:
                return None, f"Generated fix failed validation: {validation_error}"

            return fix, None

        except Exception as e:
            return None, f"Exception during fix generation: {str(e)}"

    def post(self, data, prep_res, exec_res):
        fix, error = exec_res
        if fix is None:
            attempts = data.get("attempts", 0)
            data["error"] = f"Failed to generate fix on attempt {attempts}: {error}"
            if attempts >= MAX_ATTEMPTS:
                return "fail"
            else:
                clean_data_for_restart(data)
                return "restart"

        data["fix"] = fix
        return "apply"


class ApplyAndValidateFixNode(Node):
    """Node to apply the fix and validate it, reverting if either step fails."""

    def prep(self, data):
        test_input = data.get("test_input")
        fix = data.get("fix")
        if VERBOSE:
            logger.info("ApplyAndValidateFixNode: Applying fix to files and validating")
        return (test_input, fix) if test_input and fix else None

    def exec(self, prep_res):
        if not prep_res:
            return False, "No prep result"

        test_input, fix = prep_res
        backups = None

        apply_success, apply_result = apply_fix(fix)
        if not apply_success:
            return False, f"Apply failed: {apply_result}"

        backups = apply_result  # Store backups for potential revert

        # Validate the fix
        files_modified = list(fix.edits_by_file.keys()) if fix.edits_by_file else None
        validate_success = validate_fix(test_input, files_modified)
        if not validate_success:
            # Validation failed - revert
            for backup in backups.values():
                backup.revert()
            return False, "Validation failed"

        # Validation successful - create patch files and then revert
        try:
            patches_dir = create_patch_files(backups, test_input.monorepo_root, test_input.test_target, test_input.test_case)
            if VERBOSE:
                logger.info(f"Patch files saved to: {patches_dir}")
            
            # Revert files back to original state
            for backup in backups.values():
                backup.revert()
            
            if VERBOSE:
                logger.info("Files reverted to original state after saving patches")
            
            return True, f"Success - patches saved to {patches_dir}"
        except Exception as e:
            # If patch creation fails, still revert the files
            for backup in backups.values():
                backup.revert()
            return False, f"Fix validation succeeded but patch creation failed: {str(e)}"

    def post(self, data, prep_res, exec_res):
        success, error = exec_res
        if not success:
            data["error"] = error
            clean_data_for_restart(data)
            return "restart"

        data["apply_success"] = success
        data["validate_success"] = success
        return "done"


class EndNode(Node):
    pass


def flaky_fixing_flow(
    test_input: TestInput, max_attempts: int = 3, verbose: bool = True, model: str = "drfix/drfix-sonnet4", temperature: float = 0.1
) -> tuple[bool, str | None]:
    """Main function to fix a flaky test using the pocketflow framework with retry logic.

    Args:
        test_input: Test input containing target, case, and monorepo root
        max_attempts: Maximum number of fix generation attempts (default: 3)
        verbose: Enable verbose logging (default: True)
        model: Model to use for LLM completion (default: drfix/drfix-sonnet4)
        temperature: Temperature for LLM completion (default: 0.1)

    Returns:
        Tuple of (success, error_message_or_explanation)
    """
    global MAX_ATTEMPTS
    MAX_ATTEMPTS = max_attempts

    global VERBOSE
    VERBOSE = verbose

    # Track attempts
    data = {"test_input": test_input, "attempts": 0, "model": model, "temperature": temperature}
    end_node = EndNode()
    # Create all nodes
    setup_node = SetupProblemNode()
    problem_to_fix_node = ProblemToFixNode()
    apply_and_validate_node = ApplyAndValidateFixNode()

    # Connect nodes with labels
    setup_node - "produce_fix" >> problem_to_fix_node
    setup_node - "fail" >> end_node  # Flow will terminate

    problem_to_fix_node - "apply" >> apply_and_validate_node
    problem_to_fix_node - "restart" >> problem_to_fix_node  # Retry same node

    apply_and_validate_node - "done" >> end_node  # Success - flow terminates
    apply_and_validate_node - "restart" >> problem_to_fix_node  # Restart from fix

    # Create and run the flow
    flow = Flow(start=setup_node)
    flow.run(data)

    # Check results
    if data.get("validate_success"):
        explanation = data.get("fix", {}).explanation if hasattr(data.get("fix", {}), "explanation") else None
        return True, explanation
    else:
        error_message = data.get("error", "Unknown error occurred")
        return False, error_message
