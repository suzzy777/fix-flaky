"""
Utility for loading text prompt files.
"""

from __future__ import annotations

from pathlib import Path


def load_prompt(prompt_name: str) -> str:
    """
    Load a prompt from a text file.

    Args:
        prompt_name: Name of the prompt file (without .txt extension)

    Returns:
        The content of the prompt file

    Raises:
        FileNotFoundError: If the prompt file doesn't exist
    """
    prompt_dir = Path(__file__).parent
    prompt_file = prompt_dir / f"{prompt_name}.txt"

    if not prompt_file.exists():
        raise FileNotFoundError(f"Prompt file not found: {prompt_file}")

    with open(prompt_file, "r", encoding="utf-8") as f:
        return f.read()


def get_table_driven_testing_guidance() -> str:
    """Get guidance for working with table-driven tests in Go."""
    return load_prompt("table_driven")


def get_best_practices() -> str:
    """Get best practices for fixing flaky tests."""
    return load_prompt("best_practices")
