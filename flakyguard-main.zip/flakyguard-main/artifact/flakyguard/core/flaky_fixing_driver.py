"""Single run driver for flaky test fixing.

Example:
$ python -m flakyguard.core.flaky_fixing_driver --test-target //path/to/your:test_target --test-case TestYourCase --monorepo-root /path/to/your/project

"""

from __future__ import annotations

import argparse
import time

from flakyguard.core.flaky_fixing import TestInput
from flakyguard.core.flaky_fixing_flow import flaky_fixing_flow






def main():
    parser = argparse.ArgumentParser(description="Flaky test fixing driver for single runs")
    parser.add_argument("--test-target", required=True, help="Test target (e.g., //path/to:test)")
    parser.add_argument("--test-case", required=True, help="Test case name")
    parser.add_argument("--monorepo-root", default=".", help="Monorepo root path")

    parser.add_argument("--max-attempts", type=int, default=3, help="Maximum number of attempts to fix the flaky test")
    parser.add_argument("--test-speed", type=int, default=2, help="Test speed rating (default: 2)")
    parser.add_argument("--verbose", action="store_true", default=True, help="Enable verbose logging")
    parser.add_argument("--no-verbose", dest="verbose", action="store_false", help="Disable verbose logging")

    # Model and temperature parameters
    parser.add_argument("--model", default="o1", help="Model to use for LLM completion (default: o1)")
    parser.add_argument("--temperature", type=float, default=0.1, help="Temperature for LLM completion (default: 0.1)")


    args = parser.parse_args()

    test_input = TestInput(test_target=args.test_target, test_case=args.test_case, monorepo_root=args.monorepo_root, test_speed=args.test_speed)

    print(f"Running flaky test fixing on {args.test_target}::{args.test_case}")
    start_time = time.time()

    # Execute flaky fixing flow directly
    success, explanation_or_error = flaky_fixing_flow(test_input, max_attempts=args.max_attempts, verbose=args.verbose, model=args.model, temperature=args.temperature)
    runtime = time.time() - start_time

    print(f"============\nsuccess: {success}\nexplanation_or_error: {explanation_or_error}\n============")


if __name__ == "__main__":
    main()
