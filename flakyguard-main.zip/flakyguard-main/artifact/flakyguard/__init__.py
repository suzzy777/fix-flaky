"""FlakyGuard - Automated flaky test detection and fixing tool."""

__version__ = "1.0.0"
__author__ = "Development Team"
__email__ = "tools@example.com"

# Import main components
try:
    from flakyguard.core.flaky_fixing import TestInput
    from flakyguard.core.flaky_fixing_flow import flaky_fixing_flow

    __all__ = ["TestInput", "flaky_fixing_flow"]
except ImportError:
    # Handle import errors gracefully during installation
    __all__ = []
