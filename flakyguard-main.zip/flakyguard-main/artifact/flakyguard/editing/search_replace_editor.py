"""
Search-and-replace editing functionality for flakyguard_lite.

This module provides robust editing capabilities using the search-and-replace mechanism
from neural_linters, avoiding fragile AST-based patching.
"""

from __future__ import annotations
import re
import os
from typing import NamedTuple

from flakyguard.editing.file_backup import FileBackup
from flakyguard.editing.search_and_replace_editing import (
    DEFAULT_FENCE,
    find_original_update_blocks,
    system_reminder,
)
import difflib
import datetime


class SearchReplaceEdit(NamedTuple):
    """Represents a single search-and-replace edit operation."""

    filepath: str
    search_text: str
    replace_text: str


class EditResult(NamedTuple):
    """Result of applying edits."""

    success: bool
    content: str
    error_message: str = ""


def extract_search_replace_edits(llm_response: str) -> list[SearchReplaceEdit]:
    """
    Extract search-and-replace edits from LLM response.

    Expected format:
    path/to/filename.go
    ```go
    <<<<<<< SEARCH
    original code
    =======
    new code
    >>>>>>> REPLACE
    ```

    Args:
        llm_response: The LLM response containing search-replace blocks

    Returns:
        List of SearchReplaceEdit objects with filepath information
    """
    edits = []
    try:
        blocks = find_original_update_blocks(llm_response, fence=DEFAULT_FENCE)
        for filename, search_text, replace_text in blocks:
            edits.append(SearchReplaceEdit(filepath=filename, search_text=search_text.rstrip(), replace_text=replace_text.rstrip()))
    except Exception as e:
        print(f"Failed to parse search-replace blocks: {e}")
        # Continue with empty list - will be handled by caller

    return edits


def extract_explanation(llm_response: str) -> str | None:
    """
    Extract explanation from LLM response.

    Expected format:
    <EXPLANATION>
    Brief explanation of what was causing the flakiness and how the fix addresses it.
    </EXPLANATION>

    Args:
        llm_response: The LLM response containing explanation tags

    Returns:
        Explanation text if found, None otherwise
    """

    explanation_match = re.search(r"<EXPLANATION>(.*?)</EXPLANATION>", llm_response, re.DOTALL)
    if explanation_match:
        return explanation_match.group(1).strip()
    return None


def apply_search_replace_edits_to_file(filepath: str, edits: list[SearchReplaceEdit]) -> EditResult:
    """
    Apply a list of search-and-replace edits to a file with pre-check validation.

    Args:
        filepath: Path to the file to modify
        edits: List of search-replace edits to apply to this file

    Returns:
        EditResult with success status and updated content or error message
    """
    if not edits:
        return EditResult(success=False, content="", error_message="No edits to apply")

    try:
        # Read current file content
        with open(filepath, "r", encoding="utf-8") as f:
            original_content = f.read()

        # Pre-check: verify all search texts exist in the original content
        for i, edit in enumerate(edits):
            if edit.search_text not in original_content:
                error_msg = f"Pre-check failed for edit {i + 1} in {filepath}: Search text not found:\n{edit.search_text[:200]}..."
                return EditResult(success=False, content=original_content, error_message=error_msg)

        # Apply edits sequentially if all pre-checks pass
        current_content = original_content
        for i, edit in enumerate(edits):
            if edit.search_text in current_content:
                # Replace only the first occurrence to be predictable
                current_content = current_content.replace(edit.search_text, edit.replace_text, 1)
            else:
                # This could happen since early replacement could have changed the content.
                error_msg = f"Edit {i + 1} for {filepath}: Search text not found during application:\n{edit.search_text[:200]}..."
                return EditResult(success=False, content=original_content, error_message=error_msg)

        # Write updated content to file
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(current_content)
            f.flush()
            os.fsync(f.fileno())

        return EditResult(success=True, content=current_content, error_message="")

    except Exception as e:
        return EditResult(success=False, content="", error_message=f"Error applying edits to {filepath}: {str(e)}")


def precheck_edits_by_file(edits_by_file: dict[str, list[SearchReplaceEdit]]) -> tuple[bool, str]:
    """
    Pre-check that all search texts exist in their respective files.

    Args:
        edits_by_file: Dict mapping full file paths to lists of SearchReplaceEdit objects

    Returns:
        Tuple of (success: bool, error_message: str). On success, error_message is empty.
    """
    try:
        # Validate all edits for each file
        for full_filepath, file_edits in edits_by_file.items():
            if not os.path.exists(full_filepath):
                return False, f"File does not exist: {full_filepath}"

            # Read file content once for validation
            with open(full_filepath, "r", encoding="utf-8") as f:
                content = f.read()

            # Check all search texts exist in this file
            for i, edit in enumerate(file_edits):
                if edit.search_text not in content:
                    return False, f"Pre-validation failed for edit {i + 1} in {full_filepath}: Search text not found:\n{edit.search_text[:200]}..."

        return True, ""

    except Exception as e:
        return False, f"Error during pre-check: {str(e)}"


def apply_edits_by_file_atomically(edits_by_file: dict[str, list[SearchReplaceEdit]]) -> tuple[bool, str | dict[str, FileBackup]]:
    """
    Apply search-replace edits grouped by file atomically - either all succeed or all are reverted.

    Args:
        edits_by_file: Dict mapping full file paths to lists of SearchReplaceEdit objects

    Returns:
        On success: Tuple of (True, dict mapping filepath to FileBackup objects)
        On failure: Tuple of (False, error_message: str)
    """
    try:
        if not edits_by_file:  # trivially success if no edits
            return True, {}

        # Phase 1: Create backups for all files that will be modified
        backups = {}
        try:
            for full_filepath in edits_by_file.keys():
                # Create backup
                backup = FileBackup(full_filepath)
                backups[full_filepath] = backup

            # Phase 2: Apply all edits
            for full_filepath, file_edits in edits_by_file.items():
                result = apply_search_replace_edits_to_file(full_filepath, file_edits)

                if not result.success:
                    # If any edit fails, we'll revert all changes
                    raise ValueError(f"Edit failed for {full_filepath}: {result.error_message}")

            # Phase 3: Success - return backups for caller to manage
            return True, backups

        except Exception as e:
            # Phase 4: Revert all changes on any failure
            for backup in backups.values():
                backup.revert()

            return False, f"Atomic operation failed, all changes reverted: {str(e)}"

    except Exception as e:
        return False, f"Error in atomic search-replace operation: {str(e)}"




def get_search_replace_output_format() -> str:
    """Get instructions for search-replace output format."""
    fence = DEFAULT_FENCE

    return f"""## Required Output Format

{system_reminder.format(fence=fence)}

## Example for Go files:

path/to/filename.go
{fence[0]}go
<<<<<<< SEARCH
	for name, test := range tests {{
		t.Run(name, func(t *testing.T) {{
			result := processData(test.input)
			assert.Equal(t, test.expected, result)
		}})
	}}
=======
	for name, test := range tests {{
		t.Run(name, func(t *testing.T) {{
			result := processData(test.input)
			// Sort to avoid map iteration order issues
			sort.Strings(result)
			expected := test.expected
			sort.Strings(expected)
			assert.Equal(t, expected, result)
		}})
	}}
>>>>>>> REPLACE
{fence[1]}

**For imports, include them as part of your search-replace edits:**
- If you need to add imports, include the import section in your SEARCH/REPLACE blocks to avoid search ambiguity.
- Do not use separate import tags - handle imports just like any other code changes
- This makes the editing more consistent and allows for better control over import placement

**CRITICAL SEARCH/REPLACE REQUIREMENTS:**
1. **EXACT MATCHING ONLY** - Every character in SEARCH block must match the file exactly
2. **Copy-paste from provided code context** - Don't retype, copy the exact text shown
3. **Preserve all whitespace** - tabs, spaces, indentation must match exactly
4. **Keep search blocks small** - 2-6 lines maximum to ensure accuracy
5. **Choose distinctive code** - avoid generic patterns that might appear multiple times
6. **Include enough context** - add surrounding lines to make the search unique
7. **Verify before submitting** - mentally check if your SEARCH text exists in the provided code
8. **Prefer editing tests, not production code** - unless clearly necessary, target the failing test file first
 9. **Avoid large import block edits** - only modify imports if essential; anchor on a small unique snippet
10. **Never truncate SEARCH patterns** - do not use ellipses (...) or [...] or incomplete code in SEARCH blocks
"""


def get_search_replace_edits_and_explanation_format() -> str:
    """Get instructions for search-replace output format with explanation tags."""
    base_format = get_search_replace_output_format()

    explanation_format = """
## Explanation Format

**A brief explanation** wrapped in EXPLANATION tags:

```
<EXPLANATION>
Brief explanation of what was causing the flakiness and how the fix addresses it.
</EXPLANATION>
```
"""

    return base_format + explanation_format


def create_patch_files(backups: dict[str, FileBackup], monorepo_root: str, test_target: str, test_case: str) -> str:
    """Create patch files from the applied changes and save them to patches directory.
    
    Args:
        backups: Dict mapping filepath to FileBackup objects containing original content
        monorepo_root: Root directory of the monorepo
        test_target: The test target (e.g., "//path/to:test")
        test_case: The test case name
        
    Returns:
        Path to the patches directory created
    """
    # Create patches directory
    patches_dir = os.path.join(monorepo_root, "patches")
    os.makedirs(patches_dir, exist_ok=True)
    
    # Create a timestamp for unique patch naming
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Sanitize test target and case for filename
    safe_target = test_target.replace("//", "").replace(":", "_").replace("/", "_")
    safe_case = test_case.replace("::", "_")
    
    patch_base_name = f"{safe_target}_{safe_case}_{timestamp}"
    
    for filepath, backup in backups.items():
        # Read current (modified) content
        with open(filepath, "r", encoding="utf-8") as f:
            current_content = f.read()
        
        # Generate unified diff
        original_lines = backup.content_backup.splitlines(keepends=True)
        current_lines = current_content.splitlines(keepends=True)
        
        # Create relative path for patch header
        rel_filepath = os.path.relpath(filepath, monorepo_root)
        
        diff = difflib.unified_diff(
            original_lines,
            current_lines,
            fromfile=f"a/{rel_filepath}",
            tofile=f"b/{rel_filepath}",
            lineterm=""
        )
        
        # Write patch file
        patch_filename = f"{patch_base_name}_{os.path.basename(rel_filepath)}.patch"
        patch_path = os.path.join(patches_dir, patch_filename)
        
        with open(patch_path, "w", encoding="utf-8") as f:
            f.write("".join(diff))
    
    return patches_dir
