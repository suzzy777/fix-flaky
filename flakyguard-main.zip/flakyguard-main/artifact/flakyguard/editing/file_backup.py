"""File backup functionality for atomic editing operations."""

from __future__ import annotations


class FileBackup:
    """Holds the backup of a file, used for reverting the file to its original state."""

    def __init__(self, file_path: str):
        self.file_path = file_path
        with open(file_path, "r", encoding="utf-8") as f:
            self.content_backup = f.read()

    def revert(self):
        """Reverts the file to the original state."""
        with open(self.file_path, "w", encoding="utf-8") as f:
            f.write(self.content_backup)
