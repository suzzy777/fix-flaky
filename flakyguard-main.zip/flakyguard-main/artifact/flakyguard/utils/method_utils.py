from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import tree_sitter as ts

def get_method_name(func_node: ts.Node) -> str | None:
    """Extract method name from a function node."""
    ts_node = func_node
    func_name_node = ts_node.child_by_field_name("name")
    
    if func_name_node:
        method_name = func_name_node.text.decode()
        return method_name
    
    return None
