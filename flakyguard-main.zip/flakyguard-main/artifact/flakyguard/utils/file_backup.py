from __future__ import annotations

import dataclasses


@dataclasses.dataclass
class FileBackup:
    """Holds the backup of a file, used for reverting the file to its original state."""

    # The file path of the file that is being tracked
    file_path: str
    # The content of the file at the time of the snapshot
    content_backup: str

    def __init__(self, file_path: str):
        self.file_path = file_path
        with open(file_path) as f:
            self.content_backup = f.read()

    def revert(self):
        """Reverts the file to the original state."""
        with open(self.file_path, "w") as f:
            f.write(self.content_backup)
