from __future__ import annotations

import os
from typing import TYPE_CHECKING

import flakyguard.llm.tree_sitter_util as ts_util

if TYPE_CHECKING:
    import tree_sitter as ts


def get_root_from_content(content: str, language: str = "go") -> ts.Node:
    """Parse content string and return the root AST node."""
    parser, _ = ts_util.create_parser(language)
    tree = parser.parse(content.encode())
    return tree.root_node


def get_root_from_file(file_abs_path: str) -> ts.Node:
    """Parse a file and return the root AST node."""
    file_ext = os.path.splitext(file_abs_path)[1]  # for example: .java
    language = file_ext[1:]
    # Map common file extensions to tree-sitter language names
    language = {
        "py": "python",
        "go": "go",
        "java": "java",
    }.get(language, language)

    parser, _ = ts_util.create_parser(language)
    with open(file_abs_path) as f:
        content = f.read()
    tree = parser.parse(content.encode())
    return tree.root_node
