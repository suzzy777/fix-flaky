# This file defines the Edit class, which is a container of a single change. It also has the logic to validate edits do not overlap.
# edit_tracker.py will apply a set of non-overlapping edits.
# Note: the edit start and end are character offsets, not byte offsets!
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import tree_sitter as ts


class Edit:
    """An Edit describes the replacement of a portion of a text file."""

    def __init__(self, new: str, start: int, end: int):
        self.new = new
        self.start = start  # Note this is the character offset, not byte offset!
        self.end = end  # exclusive

    def __repr__(self):
        return f"{{Start:{self.start}, End:{self.end}, New:{self.new!r}}}"


def replace_edit(node: ts.Node, new_content: str, file_content: str):
    """Replace the content of a Tree-sitter node with new_content."""
    start = len(
        file_content.encode()[: node.start_byte].decode(),
    )  # start byte offset -> start character offset
    end = len(
        file_content.encode()[: node.end_byte].decode(),
    )  # both end_byte and end are exclusive
    return Edit(new=new_content, start=start, end=end)


def insert_after_edit(node: ts.Node, new_content: str, file_content: str):
    """Insert new_content right after a Tree-sitter node."""
    end = len(
        file_content.encode()[: node.end_byte].decode(),
    )  # both end_byte and end are exclusive
    return Edit(new=new_content, start=end, end=end)




def apply_edits(src: str, edits: list[Edit]) -> str:
    """Apply a sequence of edits to the src buffer and return the result."""
    edits, size, err = validate(src, edits)
    if err is not None:
        raise ValueError(err)

    # Apply edits
    out = []
    last_end = 0
    for edit in edits:
        if last_end < edit.start:
            out.append(src[last_end : edit.start])
        out.append(edit.new)
        last_end = edit.end
    out.append(src[last_end:])

    result = "".join(out)
    if len(result) != size:
        raise RuntimeError("wrong size")

    return result




def validate(src: str, edits: list[Edit]) -> tuple[list[Edit], int, str | None]:
    """Validate that edits are consistent with the src and return output size."""
    edits = sorted(edits, key=lambda e: (e.start, e.end))

    size = len(src)
    last_end = 0
    for edit in edits:
        if not (0 <= edit.start <= edit.end <= len(src)):
            return [], 0, "diff has out-of-bounds edits"
        if edit.start < last_end:
            return [], 0, "diff has overlapping edits"
        size += len(edit.new) + edit.start - edit.end
        last_end = edit.end

    return edits, size, None
