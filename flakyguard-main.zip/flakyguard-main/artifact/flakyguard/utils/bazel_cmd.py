from __future__ import annotations

import os
import subprocess


def run_format_cmd(format_cmd: str, monorepo_root: str) -> tuple[str, str, int]:
    prefix = f"cd {monorepo_root} && WORKSPACE_ROOT={monorepo_root} PROJECT_ROOT={monorepo_root}"
    result = subprocess.run(
        f"{prefix} {format_cmd}",
        capture_output=True,
        text=True,
        cwd=monorepo_root,
        shell=True,
    )
    return result.stdout, result.stderr, result.returncode


def run_bazel_cmd(bazel_cmd: str, monorepo_root: str) -> tuple[str, str, int]:
    if not bazel_cmd.startswith("bazel"):
        raise ValueError("The bazel command must start with 'bazel'")

    prefix = f"cd {monorepo_root} && WORKSPACE_ROOT={monorepo_root} PROJECT_ROOT={monorepo_root}"
    result = subprocess.run(
        f"{prefix} {bazel_cmd}",
        capture_output=True,
        text=True,
        cwd=monorepo_root,
        shell=True,
    )
    return result.stdout, result.stderr, result.returncode
