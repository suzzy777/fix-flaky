from __future__ import annotations
import os
import json
import subprocess
import tempfile
from typing import Any

known_rule_classes = [
    "py_binary",
    "py_test",
    "py_library",
    "go_binary",
    "go_test",
    "go_library",
]


def execute_bazel_query(
    cwd: str,
    targets: list[str],
    query_deps: bool = False,
    query_rdeps: bool = False,
    query_rdeps_universe: str | None = None,
    query_depth: int | None = None,
    query_kinds: list[str] | None = None,
    query_filter: str | None = None,
    bazel_binary: str = "bazel",
) -> list[dict[str, Any]]:
    """
    Execute a bazel query to get dependency closure of targets.

    :param cwd: working directory to execute the query
    :param targets: list of Bazel targets to query
    :param query_deps: whether to query dependencies (deps)
    :param query_rdeps: whether to query reverse dependencies (rdeps)
    :param query_rdeps_universe: universe for rdeps query (default: //...)
    :param query_depth: depth limit for deps/rdeps query
    :param query_kinds: filter by rule kinds
    :param query_filter: regex filter for target names
    :param bazel_binary: path to bazel binary
    :return: list of target information as dictionaries
    """
    if not targets:
        raise ValueError("targets list cannot be empty")

    if query_deps and query_rdeps:
        raise ValueError("query_deps and query_rdeps cannot be used together")

    # Create query string
    query_string = _build_query_string(
        targets=targets,
        query_deps=query_deps,
        query_rdeps=query_rdeps,
        query_rdeps_universe=query_rdeps_universe,
        query_depth=query_depth,
        query_kinds=query_kinds,
        query_filter=query_filter,
    )

    # Create temporary query file
    query_file = tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".query")
    try:
        query_file.write(query_string)
        query_file.close()

        # Execute bazel query
        cmd = [
            bazel_binary,
            "query",
            "--output=streamed_jsonproto",
            "--order_output=no",
            "--query_file",
            query_file.name,
        ]
        result = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
        )

        # Parse JSON results
        outputs = []
        for line in result.stdout.strip().split("\n"):
            if line.strip():
                try:
                    outputs.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        return outputs

    finally:
        # Clean up query file

        try:
            os.unlink(query_file.name)
        except OSError:
            pass


def _build_query_string(
    targets: list[str],
    query_deps: bool = False,
    query_rdeps: bool = False,
    query_rdeps_universe: str | None = None,
    query_depth: int | None = None,
    query_kinds: list[str] | None = None,
    query_filter: str | None = None,
) -> str:
    """
    Build Bazel query string for deps/rdeps with optional depth and filters.

    :param targets: list of target names
    :param query_deps: whether to get dependencies
    :param query_rdeps: whether to get reverse dependencies
    :param query_rdeps_universe: universe for rdeps
    :param query_depth: depth limit
    :param query_kinds: filter by rule kinds
    :param query_filter: regex filter
    :return: Bazel query string
    """
    # Join targets with union operator
    query_string = " + ".join([f'"{target}"' for target in targets])

    # Apply deps/rdeps with optional depth
    if query_deps or query_rdeps:
        if query_rdeps:
            query_fun = "rdeps"
            universe = query_rdeps_universe if query_rdeps_universe else "//..."
            query_string = f'"{universe}", {query_string}'
        else:
            query_fun = "deps"

        if query_depth is not None:
            query_string = f"{query_fun}({query_string}, {query_depth})"
        else:
            query_string = f"{query_fun}({query_string})"

    # Apply filters
    if query_kinds:
        kinds_pattern = "|".join(query_kinds)
        query_string = f'kind("{kinds_pattern}", {query_string})'

    if query_filter:
        query_string = f'filter(".*{query_filter}.*", {query_string})'

    return query_string


def filter_results(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    filtered_results = []
    for result in results:
        if result.get("type") == "RULE":
            rule = result.get("rule", {})
        rule_class = rule.get("ruleClass")
        if rule_class not in known_rule_classes:
            continue
        target_name = rule.get("name")
        if target_name is not None and target_name.startswith("//"):
            filtered_results.append(result)
    return filtered_results


def get_target_deps(
    cwd: str,
    targets: list[str],
    depth: int | None = None,
    bazel_binary: str = "bazel",
) -> list[dict[str, Any]]:
    """
    Convenience function to get dependencies of targets.

    :param cwd: working directory
    :param targets: list of target names
    :param depth: optional depth limit
    :param bazel_binary: path to bazel binary
    :return: list of dependency targets
    """
    results = execute_bazel_query(
        cwd=cwd,
        targets=targets,
        query_deps=True,
        query_depth=depth,
        bazel_binary=bazel_binary,
    )
    return filter_results(results)


def get_target_rdeps(
    cwd: str,
    targets: list[str],
    universe: str | None = None,
    depth: int | None = None,
    bazel_binary: str = "bazel",
) -> list[dict[str, Any]]:
    """
    Convenience function to get reverse dependencies of targets.

    :param cwd: working directory
    :param targets: list of target names
    :param universe: universe for rdeps query
    :param depth: optional depth limit
    :param bazel_binary: path to bazel binary
    :return: list of reverse dependency targets
    """
    if universe is not None and universe == "//...":
        raise ValueError("universe cannot be //... for rdeps query because it is too large.")

    results = execute_bazel_query(
        cwd=cwd,
        targets=targets,
        query_rdeps=True,
        query_rdeps_universe=universe,
        query_depth=depth,
        bazel_binary=bazel_binary,
    )
    return filter_results(results)
