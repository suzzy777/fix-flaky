
query_deps:
find deps or rdeps of targets

target_resolver:
resolve the targets of the given files
resolve the detailed info of the given targets
