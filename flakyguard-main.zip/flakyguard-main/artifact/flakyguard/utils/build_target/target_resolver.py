from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
import logging
import json

logger = logging.getLogger(__name__)

known_rule_classes = [
    "py_binary",
    "py_test",
    "py_library",
    "go_binary",
    "go_test",
    "go_library",
    "java_library",
    "java_binary",
    "java_test",
]


def infer_within(files: list[str]) -> dict[str, list[str]]:
    """Infer the within folder from the files."""
    # group them by their prefix, first 3 segments
    within = {}
    for file in files:
        prefix = "/".join(file.split("/")[:3])
        if prefix not in within:
            within[prefix] = []
        within[prefix].append(file)
    return within


@dataclass
class TargetInfo:
    """Information about a Bazel target."""

    name: str
    rule_class: str
    srcs: set[str]
    deps: set[str] = None
    tags: set[str] = None

    def __post_init__(self):
        if self.deps is None:
            self.deps = set()
        if self.tags is None:
            self.tags = set()


def extract_targets_from_bazel_query_result(result: str) -> list[TargetInfo]:
    targets = []
    for line in result.stdout.strip().split("\n"):
        if line.strip():
            try:
                data = json.loads(line)
                if data.get("type") == "RULE":
                    rule = data.get("rule", {})
                    rule_class = rule.get("ruleClass", "")
                    if rule_class not in known_rule_classes:
                        continue
                    attributes = rule["attribute"]
                    srcs = []
                    deps = []
                    tags = []
                    for attr in attributes:
                        if attr.get("name") == "srcs":
                            srcs = attr.get("stringListValue", [])
                        elif attr.get("name") == "deps":
                            deps = attr.get("stringListValue", [])
                        elif attr.get("name") == "tags":
                            tags = attr.get("stringListValue", [])
                    # e.g., //path/to/tests:test_file.py -> path/to/tests/test_file.py
                    srcs = [src.replace("//", "").replace(":", "/") for src in srcs]

                    target = TargetInfo(
                        name=rule.get("name", ""),
                        rule_class=rule_class,
                        srcs=set(srcs),
                        deps=set(deps),
                        tags=set(tags),
                    )
                    targets.append(target)
            except (json.JSONDecodeError, KeyError):
                continue

    return targets


class TargetResolver:
    """A simple utility to resolve file paths to their owning Bazel targets."""

    def __init__(self, monorepo_root: str, within: str | None = None):
        """
        Initialize the target resolver.

        :param monorepo_root: Root directory of the monorepo
        """
        self.monorepo_root = monorepo_root
        self.within = within
        if self.within.endswith("/"):
            self.within = self.within[:-1]
        self._targets: dict[str, TargetInfo] = {}
        self._file_to_targets: dict[str, list[str]] = {}
        self._initialized = False

    def _ensure_initialized(self):
        """Ensure the target mapping has been built."""
        if not self._initialized:
            self._build_target_mapping()
            self._initialized = True

    def _build_target_mapping(self):
        """Build mappings from files to targets and targets to their information."""
        logger.info("Building target mapping...")
        # Query all targets in the workspace
        targets = self._query_all_targets()

        # Build file to target mapping
        for target in targets:
            self._targets[target.name] = target

            # Map each source file to this target
            for src in target.srcs:
                # use relative path to the monorepo root
                file_path = os.path.relpath(src, self.monorepo_root)
                if file_path not in self._file_to_targets:
                    self._file_to_targets[file_path] = []
                self._file_to_targets[file_path].append(target.name)

        logger.info(f"Built mapping for {len(self._targets)} targets")

    def _query_all_targets(self) -> list[TargetInfo]:
        """Query all targets in the workspace using Bazel."""
        try:
            cmd = [
                "bazel",
                "query",
                "--output=streamed_jsonproto",
                "--order_output=no",
                f"//{self.within}/...",
            ]

            result = subprocess.run(
                cmd,
                cwd=self.monorepo_root,
                capture_output=True,
                text=True,
                check=True,
            )
            return extract_targets_from_bazel_query_result(result)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to query Bazel targets: {e}")
            return []

    def resolve(self, file_path: str, only_one_owner: bool = False) -> list[TargetInfo] | TargetInfo | None:
        """
        Resolve a file path to its owning target.

        :param file_path: Path to the file (relative to monorepo root)
        :return: If only_one_owner is True, return one target only, otherwise return a list of targets
        """
        self._ensure_initialized()

        # Normalize the file path
        rel_path = os.path.relpath(file_path, self.monorepo_root)

        if rel_path in self._file_to_targets:
            result = [self._targets[target_name] for target_name in self._file_to_targets[rel_path]]
            if only_one_owner:
                # prefer library > binary > test > other
                for each in result:
                    if each.rule_class.endswith("library"):
                        return each
                for each in result:
                    if each.rule_class.endswith("binary"):
                        return each
                for each in result:
                    if each.rule_class.endswith("test"):
                        return each
                return result[0]
            return result
        if only_one_owner:
            return None
        return []  # empty list

    def get_all_targets(self) -> dict[str, TargetInfo]:
        """
        Get all targets in the workspace.

        :return: Dictionary mapping target names to TargetInfo
        """
        self._ensure_initialized()
        return self._targets.copy()

    def get_target_info(self, target_name: str) -> TargetInfo | None:
        """
        Get information about a specific target.

        :param target_name: Name of the target
        :return: TargetInfo or None if not found
        """
        self._ensure_initialized()
        return self._targets.get(target_name)


def resolve(monorepo_root, within, files, only_one_owner: bool = False) -> dict[str, list[TargetInfo] | TargetInfo | None]:
    resolver = TargetResolver(monorepo_root, within)
    result = {}
    for file_path in files:
        target = resolver.resolve(file_path, only_one_owner)
        result[file_path] = target
    return result


def resolve_single_target(monorepo_root, target_name: str) -> TargetInfo | None:
    try:
        cmd = [
            "bazel",
            "query",
            "--output=streamed_jsonproto",
            "--order_output=no",
            target_name,
        ]

        result = subprocess.run(
            cmd,
            cwd=monorepo_root,
            capture_output=True,
            text=True,
            check=True,
        )
        result = extract_targets_from_bazel_query_result(result)
        if len(result) == 0:
            return None
        return result[0]
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to query Bazel targets: {e}")
        return None
