"""Build error fixing utilities for flaky test fixes.

This module provides functionality to fix common build errors that occur after
applying flaky test fixes, including format issues, import errors, and compilation errors.
"""

from __future__ import annotations

import os
import subprocess
from typing import NamedTuple

from flakyguard.analysis.domain_specific.compilation_defect.bazel_log_analyzer import parse_bazel_log
from flakyguard.analysis.domain_specific.compilation_defect.compilation_defect import CompilationDefect
from flakyguard.editing.search_replace_editor import (
    apply_edits_by_file_atomically,
    extract_search_replace_edits,
    get_search_replace_edits_and_explanation_format,
)
from flakyguard.utils.around_line import extract_lines_around_defect
from flakyguard.llm.llm import LLMWrapper, CHAT_MODEL


class BuildFixResult(NamedTuple):
    """Result of attempting to fix build errors."""

    success: bool
    error_message: str


def get_head_version_of_file(file_path: str, monorepo_root: str) -> str:
    """
    Get the content of the file from the filesystem.

    :param file_path: The relative path to the file.
    :return: The content of the file as a string.
    :raises FileNotFoundError: If the file does not exist.
    """
    if not file_path.startswith(monorepo_root):
        file_path = os.path.join(monorepo_root, file_path)
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        raise FileNotFoundError(f"File {file_path} not found")


def get_current_version_of_file(file_path: str) -> str:
    """
    Get the content of the file at the current working directory version.

    :param file_path: The absolute path to the file.
    :return: The content of the file as a string.
    :raises FileNotFoundError: If the file does not exist.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError as e:
        raise FileNotFoundError(f"File {file_path} not found in current working directory") from e


def _extract_context_for_file_version(file_content: str, file_defects: list[CompilationDefect]) -> str | None:
    """
    Extract context around defects for a single file version.

    :param file_content: The content of the file
    :param file_defects: List of defects in the file (should be sorted by line number)
    :return: Concatenated context string around all defects, or None if no contexts found
    """
    file_contexts = []
    for defect in file_defects:
        if defect.line:
            context_around_line = extract_lines_around_defect(file_content, defect.line)
            if context_around_line:
                file_contexts.append(f"Around line {defect.line}:\n{context_around_line}")

    return "\n\n".join(file_contexts) if file_contexts else None


def extract_defect_contexts_for_files(defects_by_file: dict[str, list[CompilationDefect]], monorepo_root: str) -> tuple[dict[str, str], dict[str, str]]:
    """
    Extract context around defects for both current and original (HEAD) versions of files.

    :param defects_by_file: Dictionary mapping file paths to lists of defects in that file
    :param monorepo_root: The monorepo root directory
    :return: Tuple of (current_contexts, original_contexts) where each is a dict mapping
             file_path to concatenated context strings around all defects in that file
    """
    current_contexts = {}
    original_contexts = {}

    for file_path, file_defects in defects_by_file.items():
        # sort by line number
        file_defects.sort(key=lambda x: x.line)

        # Get current version context
        try:
            full_file_path = get_full_path(file_path, monorepo_root)
            current_content = get_current_version_of_file(full_file_path)
            current_context = _extract_context_for_file_version(current_content, file_defects)
            if current_context:
                current_contexts[file_path] = current_context
        except FileNotFoundError:
            # If we can't get the current version, continue without it
            pass

        # Get original version context
        try:
            original_content = get_head_version_of_file(file_path, monorepo_root)
            # original_context = _extract_context_for_file_version(original_content, file_defects)
            if original_content:
                original_contexts[file_path] = original_content
        except FileNotFoundError:
            # If we can't get the HEAD version, continue without it
            pass

    return current_contexts, original_contexts


def get_prompt_for_fixing_build_errors(defects: list[CompilationDefect], language: str, current_content: str = "", original_content_hint: str = "") -> str:
    """Generate a prompt for fixing build errors using LLM."""
    # Format defects for the prompt
    defect_descriptions = []
    for defect in defects:
        defect_desc = f"File: {defect.path}"
        if defect.line:
            defect_desc += f", Line: {defect.line}"
        if defect.check:
            defect_desc += f", Check: {defect.check}"
        defect_desc += f"\nSeverity: {defect.severity}\nMessage: {defect.message}\n"
        defect_descriptions.append(defect_desc)

    defects_str = "\n".join(defect_descriptions)

    return f"""You are an expert at fixing build errors in {language}. Your goal is to analyze compilation errors and provide precise search-replace edits to fix them.

## Build Errors to Fix

{defects_str}

{current_content}

{original_content_hint}

## Instructions

1. Analyze each build error carefully
2. For format/import errors (like missing imports), add the necessary import statements
3. For compilation errors, fix the syntax or type issues
4. Provide precise search-replace edits that will resolve all the issues
5. Make minimal changes - only fix what's broken
6. If original working code is provided above, use it as reference for what the code should look like
7. The search and replace edits should be made against the current code context, not the original working code.

{get_search_replace_edits_and_explanation_format()}

Focus on fixing the compilation errors while preserving the original logic and functionality."""


def apply_llm_build_fixes(
    defects: list[CompilationDefect],
    monorepo_root: str,
    language: str,
) -> BuildFixResult:
    """Use LLM to generate and apply fixes for build defects."""
    try:
        # Group defects by file path
        defects_by_file = {}
        for defect in defects:
            if defect.path not in defects_by_file:
                defects_by_file[defect.path] = []
            defects_by_file[defect.path].append(defect)

        # Extract context around defects for both current and original versions
        current_contexts, original_contexts = extract_defect_contexts_for_files(defects_by_file, monorepo_root)

        # Format current content
        current_content = ""
        for file_path, content in current_contexts.items():
            current_content += f"""
**Current code context for {file_path} (with defects):**
```{language}
{content}
```

"""

        # Format original content hint
        original_content_hint = ""
        for file_path, content in original_contexts.items():
            original_content_hint += f"""
**Original working code context for {file_path}:**
```{language}
{content}
```

"""

        prompt = get_prompt_for_fixing_build_errors(defects, language, current_content, original_content_hint)

        # Get LLM response
        llm = LLMWrapper.get_instance()
        # uses temperature 0.0 to get the most proper response.
        response = llm.get_completion(message=prompt, temperature=0.0, model=CHAT_MODEL)

        if not response:
            return BuildFixResult(success=False, error_message="LLM failed to generate response")

        # Extract search-replace edits from response
        all_edits = extract_search_replace_edits(response)

        if not all_edits:
            return BuildFixResult(success=False, error_message="No valid edits found in LLM response")

        # Group edits by full filepath (resolve paths)
        edits_by_file = {}
        for edit in all_edits:
            filepath = edit.filepath
            if not os.path.isabs(filepath):
                full_filepath = os.path.join(monorepo_root, filepath)
            else:
                full_filepath = filepath

            if full_filepath not in edits_by_file:
                edits_by_file[full_filepath] = []
            edits_by_file[full_filepath].append(edit)

        if not edits_by_file:
            return BuildFixResult(success=False, error_message="No valid edits.")

        # Apply edits atomically
        success, result = apply_edits_by_file_atomically(edits_by_file)
        if success:
            return BuildFixResult(success=True, error_message="")
        else:
            return BuildFixResult(success=False, error_message=f"Failed to apply edits: {result}")

    except Exception as e:
        return BuildFixResult(success=False, error_message=f"Error applying LLM fixes: {str(e)}")


def validate_via_build_report_defects(
    targets: list[str],
    monorepo_root: str,
    language: str,
) -> tuple[int, list[CompilationDefect]]:
    """Validate build and return defects."""

    prefix = f"cd {monorepo_root} && WORKSPACE_ROOT={monorepo_root} PROJECT_ROOT={monorepo_root}"

    # Write the pattern file to build.
    if os.path.exists(os.path.join(monorepo_root, "build")):
        result_dir = os.path.join(monorepo_root, "build")
    elif os.path.exists(os.path.join(monorepo_root, "bazel-out")):
        result_dir = os.path.join(monorepo_root, "bazel-out")
    else:
        result_dir = os.path.join("/tmp", "bazel-out")
        os.makedirs(result_dir, exist_ok=True)

    build_event_log = os.path.join(result_dir, "build_event_log.json")

    flag_file_name = os.path.join(result_dir, "targets_to_build")
    if os.getenv("BUILDKITE") == "true":
        buildkite_build_number = os.getenv("BUILDKITE_BUILD_NUMBER")
        flag_file_name = os.path.join(result_dir, f"{buildkite_build_number}_targets_to_build")

    with open(flag_file_name, "w") as flag_file:
        flag_file.write("\n".join(targets))

    cmd = [
        prefix,
        "bazel",
        "build",
        "--keep_going",
        "--output_filter=",
        "--target_pattern_file",
        flag_file_name,
        "--build_event_json_file",
        build_event_log,
    ]

    result = subprocess.run(
        " ".join(cmd),
        capture_output=True,
        text=True,
        cwd=monorepo_root,
        shell=True,
    )

    return_code = result.returncode
    defects = parse_bazel_log(build_event_log)
    return return_code, defects


def get_full_path(cur_file_path: str, monorepo_root: str) -> str:
    """Get the full path of a file relative to the monorepo root."""
    if not cur_file_path.startswith(monorepo_root):
        return os.path.join(monorepo_root, cur_file_path)
    return cur_file_path


def fix_build_errors(
    files_modified: list[str] | None,
    test_target: str,
    monorepo_root: str,
    language: str,
) -> BuildFixResult:
    """Fix build errors for a test target.

    This function attempts to fix common build errors that occur after applying
    flaky test fixes by:
    1. Running formatting commands (e.g., goimports for Go)
    2. Validating the build and getting compilation defects
    3. Using LLM to automatically fix build errors with original git HEAD content as reference

    Args:
        test_target: The Bazel test target to validate
        monorepo_root: The monorepo root directory
        language: The programming language (e.g., "go")
        files_modified: List of files that were modified by the fix

    Returns:
        BuildFixResult with success status and error message if any
    """
    files_modified = [get_full_path(file_path, monorepo_root) for file_path in files_modified]
    # Step 1: Run formatting command based on language
    if language == "go":
        prefix = f"cd {monorepo_root} && WORKSPACE_ROOT={monorepo_root} PROJECT_ROOT={monorepo_root}"
        # Format each file individually
        for file_path in files_modified:
            format_cmd = f"bin/goimports -w {file_path}"
            # it is ok if the formatting command fails, we will try to fix the build errors with LLM
            _ = subprocess.run(
                f"{prefix} {format_cmd}",
                capture_output=True,
                text=True,
                cwd=monorepo_root,
                shell=True,
            )

    # Step 2: Validate build and get defects
    return_code, defects = validate_via_build_report_defects([test_target], monorepo_root, language)
    if return_code == 0:  # early return
        return BuildFixResult(success=True, error_message="")

    if not defects:
        return BuildFixResult(success=False, error_message="Build failed, but cannot get any build defects")

    # Step 3: If build failed, try to fix using LLM only once (deliberate tradeoff between quality and speed)
    llm_fix_result = apply_llm_build_fixes(defects, monorepo_root, language)

    if llm_fix_result.success:
        return_code, _ = validate_via_build_report_defects([test_target], monorepo_root, language)

        if return_code == 0:
            return BuildFixResult(success=True, error_message="Fixed using LLM")
        else:
            return BuildFixResult(success=False, error_message="Did not pass validation after LLM fixing")
    else:
        return BuildFixResult(success=False, error_message=llm_fix_result.error_message)
