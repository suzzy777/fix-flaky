from __future__ import annotations

import os
import re

from typing import Callable

import tree_sitter as ts

import flakyguard.llm.tree_sitter_util as ts_util
from flakyguard.utils.core_parser import get_root_from_file


def get_tree(file_abs_path):
    file_ext = os.path.splitext(file_abs_path)[1]  # for example: .java
    language = file_ext[1:]
    parser, _ = ts_util.create_parser(language)
    with open(file_abs_path) as f:
        content = f.read()
    tree = parser.parse(content.encode())
    return tree


def find_in_directory(directory: str, file_filter: Callable[[str], bool], node_types: [str], condition: Callable[[ts.Node], bool]):
    """
    Find the function with certain function name in the directory
    """

    for root, _, files in os.walk(directory):
        for file in files:
            if file_filter(file):
                file_path = os.path.join(root, file)
                tree = get_tree(file_path)
                func = find_first_qualified_node(tree.root_node, node_types, condition)
                if func:
                    return file_path, func
    return None, None


def find_first_qualified_node(node, node_types: [str], condition: Callable[[ts.Node, ...], bool], *args):
    """
    Find the first node in a tree-sitter tree that is a certain node type, and satisfies a condition
    """
    if node.type in node_types and condition(node, *args):
        return node
    for child in node.children:
        result = find_first_qualified_node(child, node_types, condition, *args)
        if result:
            return result
    return None


def find_test_function(directory: str, test_func_name: str):
    def file_filter(file):
        return "test" in file and file.endswith(".go")

    def cond(node: ts.Node) -> bool:
        return test_func_name == node.child_by_field_name("name").text.decode("utf-8")

    file_path, test_func = find_in_directory(directory, file_filter, ["function_declaration", "method_declaration"], cond)
    return file_path, test_func


def get_test_func_node_from_file(file_path: str, test_case: str) -> ts.Node | None:
    root_node = get_root_from_file(file_path)
    if not root_node:
        return None
    
    result = get_test_func_node(root_node, test_case)
    return result


# Due to the fact that we already find the root node at the very beginning of FlakyGuard, the test_func should not be None.
# 1. If we can find the all the part separated by / in the test case in the same file, we should be able to match as far as possible until the last part in the test case.
# 2. If we can not, then our fallback logic should also work.
def get_test_func_node(root: ts.Node, test_case: str) -> ts.Node | None:
    funcs = ts_util.find_nodes_by_type(root, ["function_declaration", "method_declaration"])
    
    result = re.split(r"[/#]", test_case)  # split by / or #
    
    test_func = iterate_far(funcs, result)
    
    # fallback logic; only match the last possible one
    if not test_func:
        for each in reversed(result):
            for func in funcs:
                func_name = func.child_by_field_name("name").text.decode()
                if func_name == each:
                    test_func = func
                    return test_func
    
    return test_func


def iterate_far(funcs: [ts.Node], result: [str]):
    test_func = None
    # scan as far as possible until the last test func.
    for each in result:
        exist = False
        for func in funcs:
            if func.child_by_field_name("name").text.decode() == each:
                test_func = func
                exist = True
                break
        # stop here if we can not continue extending
        if not exist:
            break
    return test_func


def _get_directory_from_test_target(test_target: str, monorepo_root) -> str:
    directory = test_target.split(":")[0][2:]
    return os.path.join(monorepo_root, directory)


def find_test_file_with_test_case(test_target: str, test_case: str, monorepo_root: str):
    """
    Find the function with certain function name in the directory.
    This function is used by flakyguard to figure out which file contains the test case at the beginning.
    Thus, it needs to be accurate.
    """
    directory = _get_directory_from_test_target(test_target, monorepo_root)
    result = re.split(r"[/#]", test_case)  # split by / or #

    # This part is to do fine-grained search to match every component in the test case name from the same file.
    # Start with the full accumulated path and reduce by one part per iteration
    for i in range(len(result)):
        # Slice the result to get the parts up to the current index
        accumulated_path = "/".join(result[: len(result) - i])
        last_part = result[len(result) - i - 1]
        match_last_part = False
        match_all = False
        for root, _, files in os.walk(directory):
            for file in files:
                if "test" in file and file.endswith(".go"):
                    file_path = os.path.join(root, file)
                    root_node = get_root_from_file(file_path)
                    funcs = ts_util.find_nodes_by_type(root_node, ["function_declaration", "method_declaration"])
                    # find the last part of the test case
                    test_func = iterate_far(funcs, re.split(r"[/#]", last_part))
                    # If we can find the last part from the file, the next step is to match all the part before the last part.
                    if test_func:
                        match_last_part = True
                        new_test_func = iterate_far(funcs, re.split(r"[/#]", accumulated_path))
                        # If we can successfully match all the part, the file path should be accurate enough.
                        if new_test_func == test_func:
                            return file_path
                        else:
                            match_all = False
        if match_last_part and not match_all:
            break

    # If we can not find the file path in which it contains all the part separated by / in the test case,
    # we just find the last possible function which appears first in the directory.
    for each in reversed(result):
        file_path, test_func = find_test_function(directory, each)
        if test_func:
            return file_path
    return None
