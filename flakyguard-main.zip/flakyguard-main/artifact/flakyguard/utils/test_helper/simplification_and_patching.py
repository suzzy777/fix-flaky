from __future__ import annotations

import os
import re

import tree_sitter as ts

import flakyguard.llm.tree_sitter_util as ts_util
from flakyguard.utils.core_parser import get_root_from_content, get_root_from_file
from flakyguard.analysis.repograph.ast_util import find_nodes_by_type_and_lines
from flakyguard.utils.bazel_cmd import run_format_cmd
from flakyguard.utils.edit import (
    insert_after_edit,
    replace_edit,
)
from flakyguard.utils.edit_tracker import EditTracker
from flakyguard.utils.test_helper.finder import get_test_func_node
from flakyguard.utils.file_backup import FileBackup

FLAKYGUARD_PREFIX_COMMENTED = "// FLAKYGUARD_PREFIX: "
FLAKYGUARD_WITH_UNUSED_VAR_COMMENTED = "// FLAKYGUARD_UNUSED: "


def children_by_type(node: ts.Node, type_name: str):
    """Returns a list of children nodes with the specified type."""
    matching_children = []

    # Iterate over all children of the node
    for child in node.children:
        if child.type == type_name:
            matching_children.append(child)

    return matching_children


def get_test_func_node_from_file(full_path: str, test_case: str) -> ts.Node | None:
    root_node = get_root_from_file(full_path)
    if root_node is None:
        return None
    test_func = get_test_func_node(root_node, test_case)
    return test_func


def get_T_param(test_func: ts.Node) -> ts.Node:
    t_param = None
    params = test_func.child_by_field_name("parameters")
    for param_decl in children_by_type(params, "parameter_declaration"):
        if param_decl.child_by_field_name("type").text.decode() == "*testing.T":
            t_param = param_decl.child_by_field_name("name")

    assert t_param, "f{t_param} should exist"
    return t_param


def get_test_case_node(root: ts.Node, test_case: str) -> ts.Node | None:
    # root can represent the whole file, or the test function
    test_func = get_test_func_node(root, test_case)
    if test_func is None:
        return None
    test_func_name = test_func.child_by_field_name("name").text.decode()

    assert test_func_name in test_case, f"{test_func_name} should be substring of {test_case}"
    # See the cases mentioned below in the testdata/test_cases
    # basic case: function name is same as the test_case
    if test_case.endswith(test_func_name):
        return test_func

    start_index = test_case.index(test_func_name) + len(test_func_name)
    assert test_case[start_index:].startswith("/")
    test_case = test_case[start_index + 1 :]
    # there may be nested subcases like TestFunc/case1/case1a/case1aa, but we stop at the top level case1 for simplicity and robustness.
    test_case = test_case.split("/")[0]

    t_param_str = get_T_param(test_func).text.decode()
    # t.Run("case1", ...)
    call_exprs = ts_util.find_nodes_by_type(test_func, ["call_expression"])
    for call_expr in call_exprs:
        if call_expr.text.decode().startswith(f"{t_param_str}.Run("):
            t_run_signatures = children_by_type(call_expr.child_by_field_name("arguments"), "interpreted_string_literal")
            for t_run_signature in t_run_signatures:
                if (
                    t_run_signature.text.decode().replace(" ", "_") == '"' + test_case + '"'
                    or t_run_signature.text.decode().replace(" ", "_") == test_case
                ):
                    call_statement = call_expr.parent
                    return call_statement

    # map case: tests := map[string]struct {... }{ "case1": ...
    short_var_decls = ts_util.find_nodes_by_type(test_func, ["short_var_declaration"])
    for short_var_decl in short_var_decls:
        right = short_var_decl.child_by_field_name("right")
        composite_literals = ts_util.find_nodes_by_type(right, ["composite_literal"])
        for composite_literal in composite_literals:
            childtype = composite_literal.child_by_field_name("type").type
            if childtype == "map_type":
                keyed_elements = children_by_type(composite_literal.child_by_field_name("body"), "keyed_element")
                for keyed_element in keyed_elements:
                    key = keyed_element.children[0]
                    if key.text.decode().replace(" ", "_") == '"' + test_case + '"' or key.text.decode().replace(" ", "_") == test_case:
                        return keyed_element
            elif childtype == "slice_type":
                literal_elements = children_by_type(composite_literal.child_by_field_name("body"), "literal_element")
                for literal_element in literal_elements:
                    for literal_value in children_by_type(literal_element, "literal_value"):
                        for keyed_element in children_by_type(literal_value, "keyed_element"):
                            field = children_by_type(keyed_element, "literal_element")[1]  # value of the key/value pair
                            # we only handle the case with hardcoded test_case string values
                            field_val = field.text.decode()
                            if field_val.replace(" ", "_") == '"' + test_case + '"' or field_val.replace(" ", "_") == test_case:
                                return literal_element

    # others.
    return test_func  # fallback logic


def get_simplified_test_func_content(content: str, test_case: str) -> str | None:
    test_func = get_test_func_node(get_root_from_content(content), test_case)
    t_param_str = get_T_param(test_func).text.decode()

    test_case_node = get_test_case_node(test_func, test_case)
    test_case_str = test_case_node.text.decode()
    if test_case_node.type in ["function_declaration", "method_declaration"]:
        return test_case_str

    edit_tracker = EditTracker(content=content)
    if test_case_node.type == "expression_statement" and test_case_str.startswith(f"{t_param_str}.Run("):
        scope = test_case_node.parent
        for expression_statement in children_by_type(scope, "expression_statement"):
            if expression_statement != test_case_node:
                expression_str = expression_statement.text.decode()
                if expression_str.startswith(f"{t_param_str}.Run("):
                    edit_tracker.add_edit(replace_edit(expression_statement, "", content))
        new_content = edit_tracker.apply_edits()
        simplified_test_func = get_test_func_node(get_root_from_content(new_content), test_case)
        return simplified_test_func.text.decode()

    if test_case_node.type == "keyed_element":  # map
        scope = test_case_node.parent
        edit_tracker.add_edit(
            replace_edit(
                scope,
                f"""{{
    {test_case_str},
}}""",
                content,
            )
        )
        new_content = edit_tracker.apply_edits()
        simplified_test_func = get_test_func_node(get_root_from_content(new_content), test_case)
        return simplified_test_func.text.decode()

    if test_case_node.type == "literal_element":  # slice
        scope = test_case_node.parent
        edit_tracker.add_edit(
            replace_edit(
                scope,
                f"""{{
    {test_case_str},
}}""",
                content,
            )
        )

        new_content = edit_tracker.apply_edits()
        simplified_test_func = get_test_func_node(get_root_from_content(new_content), test_case)
        return simplified_test_func.text.decode()

    return test_case_str  # fallback for unknown cases


def extract_variable_names_and_indices(comment_text):
    """Extract variable names and their indices dynamically from the comment."""
    # Regex to extract variable names and indices from the comment format
    # Example: "FLAKYGUARD_UNUSED: localBucket:0, anotherBucket:1"
    match = re.search(r"FLAKYGUARD_UNUSED:\s*(.*)", comment_text)
    if match:
        var_list = match.group(1).strip().split(",")
        # Extract variable name and index from each entry in the list
        result = []
        for var in var_list:
            var_name, index_str = var.split(":")
            index = int(index_str.strip())  # Convert index to integer
            result.append((var_name.strip(), index))
        return result
    return []


def get_previous_node(node):
    """Manually find the previous node to the given node."""
    # Start from the parent node and look at the previous sibling
    parent_node = node.parent
    if not parent_node:
        return None  # No parent means no previous node in this context

    # Traverse the children of the parent node and find the previous sibling
    for i in range(parent_node.child_count):
        current_child = parent_node.child(i)
        if current_child.start_byte == node.start_byte:
            # The current node is the one we're looking for, so the previous one is before it
            if i > 0:
                return parent_node.child(i - 1)
            else:
                return None  # No previous node

    return None  # If not found, return None


# I had tried the smart patching that leverages the sourranding context for patching, rather than line number
# However, the context could be ambiguous, leading to failure in patching.
# Instead, here, we leverage the patterns and domain knowledge of AST structure for patching
def patching(simplified_func: str, fixed_simplified_func: str, original_func: str, test_case: str) -> str | None:
    # Goal: compute the transformation from simplified_func to fixed_simplified_func, then apply
    # the transformation to the original function in the file
    test_func = get_test_func_node(get_root_from_content(original_func), test_case)
    test_case_node = get_test_case_node(test_func, test_case)
    t_param_str = get_T_param(test_func).text.decode()
    result = None
    if test_case_node.type in ["function_declaration", "method_declaration"]:
        edit_tracker = EditTracker(content=original_func)
        edit_tracker.add_edit(replace_edit(test_func, fixed_simplified_func, original_func))
        result = edit_tracker.apply_edits()

    if test_case_node.type == "expression_statement" and test_case_node.text.decode().startswith(f"{t_param_str}.Run("):
        # assume all changes are within the t.Run() block,
        # TODO: we will handle it more comprehensively: start with fixed_simplified_func, copy all t.Run() and overwrite the t.Run case under fixing.
        fixed_test_case_node = get_test_case_node(get_root_from_content(fixed_simplified_func), test_case)
        if fixed_test_case_node is None:
            return None

        edit_tracker = EditTracker(content=original_func)
        edit_tracker.add_edit(replace_edit(test_case_node, fixed_test_case_node.text.decode(), original_func))
        result = edit_tracker.apply_edits()

    if test_case_node.type == "keyed_element" or test_case_node.type == "literal_element":  # slie or  map
        # we want the test func to start with the fixed_simplified_func, (1) restore the original scope but (2) replace the test case with the fixed version
        edit_tracker = EditTracker(content=fixed_simplified_func)
        original_scope_copy = test_case_node.parent.text.decode()

        fixed_test_case_node = get_test_case_node(get_root_from_content(fixed_simplified_func), test_case)
        if fixed_test_case_node is None:
            return None
        fixed_test_case_copy = fixed_test_case_node.text.decode()
        edit_tracker.add_edit(
            replace_edit(
                fixed_test_case_node.parent,
                original_scope_copy,
                fixed_simplified_func,
            )
        )
        content_after_step1 = edit_tracker.apply_edits()
        edit_tracker = EditTracker(content=content_after_step1)
        test_case_to_be_replaced = get_test_case_node(
            get_root_from_content(content_after_step1),
            test_case,
        )
        edit_tracker.add_edit(replace_edit(test_case_to_be_replaced, fixed_test_case_copy, content_after_step1))
        result = edit_tracker.apply_edits()

    if result:
        edit_tracker = EditTracker(content=result)
        result_node = get_root_from_content(result)
        comment_nodes = ts_util.find_nodes_by_type(result_node, ["comment"])
        # Traverse the syntax tree
        for comment_node in comment_nodes:
            # Look for the FLAKYGUARD comment node
            if "FLAKYGUARD_UNUSED" in comment_node.text.decode("utf-8"):
                prev_node = get_previous_node(comment_node)
                if prev_node and prev_node.type == "short_var_declaration":
                    left_expr_list = prev_node.child_by_field_name("left")
                    left_ids = [child.text.decode("utf-8") for child in left_expr_list.children if child.type == "identifier"]
                    # Extract variable names from the FLAKYGUARD comment
                    var_names_and_indices = extract_variable_names_and_indices(comment_node.text.decode("utf-8"))
                    for var_name, index in var_names_and_indices:
                        if index < len(left_ids) and left_ids[index] == "_":
                            edit_tracker.add_edit(replace_edit(left_expr_list.children[index], var_name, result))
                        else:
                            raise Exception(
                                "The index to be replaced during patching is beyond the number of declarations of the left side \
                                            or the corresponding unused var is not replaced with _ during simplification."
                            )
                elif prev_node and prev_node.type == "var_declaration":
                    var_spec = None
                    for var_dec_child in prev_node.children:
                        if var_dec_child.type == "var_spec":
                            var_spec = var_dec_child
                            break
                    if var_spec:
                        left_ids = [child.text.decode("utf-8") for child in var_spec.children if child.type == "identifier"]
                        var_names_and_indices = extract_variable_names_and_indices(comment_node.text.decode("utf-8"))
                        for var_name, index in var_names_and_indices:
                            if index < len(left_ids) and left_ids[index] == "_":
                                edit_tracker.add_edit(replace_edit(var_spec.children[index], var_name, result))

                edit_tracker.add_edit(replace_edit(comment_node, "", result))
        result = edit_tracker.apply_edits()
        result = result.replace(FLAKYGUARD_PREFIX_COMMENTED, "")
        return result
    return None  # not sure what happened


def extract_unused_variable(message: str) -> str:
    """
    Extract the variable name from a defect message of the form:
    "declared and not used: varName"
    """
    # Look for the part of the message after "declared and not used:"
    match = re.search(r"declared and not used:\s*(\w+)", message)
    if match:
        return match.group(1)  # Return the single variable name
    return ""


def fix_declared_but_unused_vars(monorepo_root, test_target, test_file: str) -> tuple[bool, str]:
    # True means the fix is successful, False otherwise.
    while True:
        # Compilation defects collection removed - not needed for core pipeline
        return_code, defects = 0, []
        if return_code == 0:
            return True, ""

        if not all("declared and not used:" in defect.message or "too many errors" in defect.message for defect in defects):
            # we only know how to handle such types here
            return False, "there are types of defects that we don't know how to handle"

        # Create a map between the defect's line and the unused variable name
        unused_vars_map = {}
        for defect in defects:
            unused_var = extract_unused_variable(defect.message)
            if unused_var:
                if defect.line not in unused_vars_map:
                    unused_vars_map[defect.line] = []
                unused_vars_map[defect.line].append(unused_var)

        edit_tracker = EditTracker(filepath=test_file)
        root_node = get_root_from_file(test_file)
        content = root_node.text.decode()

        for line_num, unused_vars in unused_vars_map.items():
            nodes = find_nodes_by_type_and_lines(root_node, ["var_declaration", "short_var_declaration"], [line_num])
            if not nodes:
                continue
            unused_var_with_index_list = []
            cur_node = nodes[0]
            if cur_node.type == "short_var_declaration":
                left_expr = cur_node.child_by_field_name("left")
                unused_var_nodes_of_cur_node = set()
                index = 0
                if left_expr:
                    for child in left_expr.children:
                        if child.type == "identifier":
                            var_name = child.text.decode()
                            if var_name in unused_vars:
                                unused_var_nodes_of_cur_node.add(child)
                                unused_var_with_index_list.append((var_name, index))
                            index += 1
                    # We deal with index for short_var_declaration because `_, _ := 10, 20` is invalid.
                    if index > len(unused_var_nodes_of_cur_node):
                        for unused_var_node_of_cur_node in unused_var_nodes_of_cur_node:
                            # Replace the unused variable (e.g., 'a') with "_"
                            edit_tracker.add_edit(replace_edit(unused_var_node_of_cur_node, "_", content))
                    elif index == len(unused_var_nodes_of_cur_node):
                        node_text = cur_node.text.decode()  # Get the text of the node
                        node_lines = node_text.splitlines()  # Split the node text into lines
                        commented_lines = [f"{FLAKYGUARD_PREFIX_COMMENTED}{line}" for line in node_lines]  # Add the comment to each line
                        commented_text = "\n".join(commented_lines)  # Reassemble the commented lines into a single string
                        edit_tracker.add_edit(replace_edit(cur_node, commented_text, content))
                        node_lines = node_text.splitlines()  # Split the node text into lines
                        unused_var_with_index_list = []

            elif cur_node.type == "var_declaration":
                var_spec = None
                for var_dec_child in cur_node.children:
                    if var_dec_child.type == "var_spec":
                        var_spec = var_dec_child
                        break
                index = 0
                if var_spec:
                    for child in var_spec.children:
                        if child.type == "identifier":
                            # Get the identifier from the name field
                            var_name = child.text.decode()
                            if var_name in unused_vars:
                                unused_var_with_index_list.append((var_name, index))
                                # Replace the unused variable (e.g., 'a') with "_"
                                edit_tracker.add_edit(replace_edit(child, "_", content))
                            index += 1
                        # We do not deal with index for var_declaration because `var _, _ int = 10, 20` is valid.

            if len(unused_var_with_index_list) != 0:
                # We process the declared variables following the orders in the original lines
                # and unused_var_with_index_list should also output in the same order.
                unused_vars_str = ", ".join(f"{key}:{value}" for key, value in unused_var_with_index_list)
                commented_text = f" {FLAKYGUARD_WITH_UNUSED_VAR_COMMENTED}{unused_vars_str}"
                edit_tracker.add_edit(insert_after_edit(cur_node, commented_text, content))
        try:
            new_content = edit_tracker.apply_edits()
        except Exception:  # ValueError: diff has overlapping edits
            return False, "applying edits failed"

        with open(test_file, "w") as f:
            f.write(new_content)
            f.flush()  # Ensure the data is flushed to the OS buffers
            os.fsync(f.fileno())  # Force writing to disk if needed
        stdout, stderr, returncode = run_format_cmd(f"bin/goimports -w {test_file}", monorepo_root)  # remove unused imports
        if returncode:
            return False, "goimports failed"
            # move on to see if renovate can fix it.


def get_original_and_simplified_test_func(full_path: str, test_case: str, line_num_threshold: int = 100) -> tuple[str | None, str | None]:
    if not full_path:
        return None, None

    root_node = get_root_from_file(full_path)
    content = root_node.text.decode()
    test_func = get_test_func_node(root_node, test_case)
    if not test_func:
        return None, None
    test_func_str = test_func.text.decode()
    test_func_line_count = test_func.end_point[0] - test_func.start_point[0] + 1
    if test_func_line_count <= line_num_threshold:
        return test_func_str, None

    simplified_test_func_str = get_simplified_test_func_content(content, test_case)
    if simplified_test_func_str is None:
        return test_func_str, None
    return test_func_str, simplified_test_func_str


def simplify_test_file(full_path: str | None, test_case: str, line_num_threshold: int = 100) -> tuple[bool, str]:
    # find the test function, remove all the test cases except the one of interest in the test function.
    if not full_path:
        return False, f"cannot find the test file {full_path}"

    root_node = get_root_from_file(full_path)
    content = root_node.text.decode()
    test_func = get_test_func_node(root_node, test_case)
    test_func_line_count = test_func.end_point[0] - test_func.start_point[0] + 1
    if test_func_line_count <= line_num_threshold:
        return False, f"the test function is too short to simplify: {test_func_line_count} lines < threshold {line_num_threshold}"

    simplified_test_func_str = get_simplified_test_func_content(content, test_case)
    if simplified_test_func_str is None:
        return False, "cannot simplify the test function"
    edit_tracker = EditTracker(filepath=full_path)
    edit_tracker.add_edit(replace_edit(test_func, simplified_test_func_str, content))
    new_content = edit_tracker.apply_edits()
    return True, new_content


def prepare_simplified_test_file(test_file, test_target: str, test_case: str, monorepo_root: str, line_num_threshold: int = 200):
    # only if the func has more than line_num_threshold lines, we simplify the test file.
    success, new_content_or_error = simplify_test_file(test_file, test_case, line_num_threshold)
    if not success:
        return False, f"cannot simplify the test file: {new_content_or_error}"
    backup = FileBackup(test_file)
    new_content = new_content_or_error
    with open(test_file, "w") as f:
        f.write(new_content)
        f.flush()  # Ensure the data is flushed to the OS buffers
        os.fsync(f.fileno())  # Force writing to disk if needed
        stdout, stderr, returncode = run_format_cmd(f"bin/goimports -w {test_file}", monorepo_root)  # remove unused imports
        if returncode:
            backup.revert()
            return False, f"cannot format the test file {test_file}: {stderr}"

    success, _ = fix_declared_but_unused_vars(monorepo_root, test_target, test_file)
    if not success:
        backup.revert()
        return False, "cannot fix declared but unused vars"

    return True, ""
