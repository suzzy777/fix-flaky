"""Utilities for extracting lines around specific line numbers in file content."""

from __future__ import annotations


def extract_lines_around_defect(file_content: str, line_number: int, context_lines: int = 50, highlight_line: bool = False) -> str:
    """
    Extract lines around a specific line number from file content.

    Args:
        file_content: The full content of the file
        line_number: The line number around which to extract context (1-indexed)
        context_lines: Number of lines to include before and after the target line
        highlight_line: Whether to highlight the target line with ">>> " prefix

    Returns:
        A string containing the extracted lines with line numbers
    """
    if not file_content:
        return ""

    lines = file_content.split("\n")
    total_lines = len(lines)

    # Assert valid line number
    assert line_number > 0, f"Line number must be > 0, got {line_number}"
    assert line_number <= total_lines, f"Line number {line_number} exceeds total lines {total_lines}"

    # Convert to 0-indexed
    target_line_idx = line_number - 1

    # Calculate start and end indices
    start_idx = max(0, target_line_idx - context_lines)
    end_idx = min(total_lines, target_line_idx + context_lines + 1)

    # Extract lines with content
    result_lines = []
    for i in range(start_idx, end_idx):
        line_num = i + 1
        line_content = lines[i]
        # do not add any extra space to the prefix since that will mess up the search-and-replace editing.
        prefix = ">>> " if (line_num == line_number and highlight_line) else ""
        result_lines.append(f"{prefix}{line_content}")

    return "\n".join(result_lines)
