# Edit tracking utilities for file modifications
# The edits do not have to be applied to the file level content, they can be applied to the method content.

from __future__ import annotations

import os

from flakyguard.utils.edit import Edit, apply_edits


class EditTracker:
    def __init__(self, *, content: str | None = None, filepath: str | None = None):
        """Initialize the tracker for a single file."""
        if content:
            self._content = content
        else:
            if filepath and os.path.exists(filepath):
                with open(filepath, "r") as file:
                    self._content = file.read()
            else:
                raise ValueError("Content or filepath must be provided.")
        self.edits = []

    def add_edit(self, edit: Edit):
        """Add an edit for the tracked file."""
        self.edits.append(edit)

    def apply_edits(self) -> str:
        """Apply all tracked edits, does not really write to the file. the change reflects in the content."""
        updated_content = apply_edits(self._content, self.edits)
        self.edits.clear()
        self._content = updated_content
        return updated_content
