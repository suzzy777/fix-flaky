# Coverage Tool for Monorepos

This tool provides a unified interface to compute and inspect code coverage for monorepos, including Python and Go codebases. It is designed to help engineers quickly determine which lines of code are executed by tests, and to identify untested code.

## Features
- Supports multiple project types: `python`, `go`, `java`
- Handles both Python and Go test targets
- Filters out branch coverage by default (only line coverage is reported)
- Allows filtering by specific test case
- Optionally includes test files in coverage analysis
- Simple CLI and shell script interface

## Usage

### 1. Using the Python CLI

You can run the CLI directly (after building or in a suitable environment):

```bash
python -m flakyguard.utils.coverage.compute_coverage \
    --test-target //path/to:your_test_target \
    [--test-case test_case] \
    [--include-test-files] \
    [--project-root ~/your_project]
```

#### Arguments
- `--test-target`: Test target to run coverage on (required)
- `--test-case`: (Optional) Filter to a specific test case (substring match for Python, regex for Go)
- `--include-test-files`: (Optional) Include test files in coverage analysis
- `--project-root`: (Optional) Path to the project root. Defaults to current directory.

#### Example

```bash
python -m flakyguard.utils.coverage.compute_coverage \
    --test-target //your/project:test_target \
    --test-case TestClass::test_method \
    --include-test-files \
    --project-root ~/your_project
```

## Output
- For each file, prints the number of lines executed and the line numbers.
- For Python projects, function headers may appear as covered even if the body is not executed (due to how Python loads code).

## Notes
- Branch coverage (BRDA, BRF, BRH) is ignored by default; only line coverage is reported.
- The tool is designed for monorepo setups and can be adapted for various project structures.
