from __future__ import annotations

import traceback
from logging import getLogger
from flakyguard.utils.coverage.lcov_parser import parse_file, Report
from flakyguard.utils.bazel_cmd import run_bazel_cmd
from flakyguard.definitions.language import Language

logger = getLogger(__name__)


# we cannot use monorepo_root to determine the language because it can have any name due to the use of worktree.
def compute_coverage(
    monorepo_root: str, test_target: str, test_case: str | None = None, include_test_files: bool = False, language: Language = "go", retries: int = 10
) -> Report:
    try:
        if test_case:
            if language == "python":
                # pytest supports -k flag, which does not support regex.
                # it only supports simple substring matching
                simple_test_case = test_case
                if "/" in simple_test_case:
                    simple_test_case = simple_test_case.split("/")[-1]
                if "::" in simple_test_case:
                    simple_test_case = simple_test_case.split("::")[-1]
                test_case_filter = ["--test_filter", f'"{simple_test_case}"']
            elif language == "go":
                test_case_filter = ["--test_filter", f'"^{test_case}$"']
            elif language == "java":
                raise ValueError(f"need to figure out details for fievel later")
            else:
                raise ValueError(f"Unsupported monorepo root: {monorepo_root}")
        else:
            test_case_filter = []

        cmd = ["bazel", "coverage", test_target, *test_case_filter]

        if include_test_files:
            cmd.append("--instrument_test_targets")

        if language == "go":
            cmd.extend(["--instrumentation_filter", '"^//:"', "--@io_bazel_rules_go//go/config:cover_format=lcov", "--test_strategy=standalone"])
        elif language == "java":
            cmd.extend([
                "--collect_code_coverage",
                "--combined_report=lcov",
                "--test_strategy=standalone"  # avoid JacocoCoverageRunner conflicts
            ])
        elif language == "python":
            # match any package in the monorepo
            cmd.extend(["--instrumentation_filter", '"^//[^/]+[/:]"', "--combined_report=lcov"])
        else:
            raise ValueError(f"Unsupported monorepo root: {monorepo_root}")

        # look for the coverage.dat file in the output
        # shell=True is for ease of quoting/unquoting etc.
        for _ in range(retries):
            try:
                cmd.append("--nocache_test_results")  # avoid caching test results
                ret, err, code = run_bazel_cmd(" ".join(cmd), monorepo_root)
                # it is possible that the run fails due to flakiness, then coverage.dat is not generated.
                # we retry a few times to get the coverage.dat file.
                if code != 0:
                    logger.info(f"Error computing coverage: {err}")
                    continue
                coverage_file = next(s for s in ret.splitlines() if "/coverage.dat" in s).strip()
                result = parse_file(coverage_file, ignore_branch_coverage=True)
                return result
            except Exception as e:
                stack_trace = traceback.format_exc()
                logger.info(f"Error computing coverage: {e}\n{stack_trace}")
                continue

    except Exception as e:
        logger.error(f"Exception in compute_coverage: {e}")
        return None
