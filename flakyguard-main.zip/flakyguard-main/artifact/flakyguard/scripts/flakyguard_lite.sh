#!/bin/bash
# this script can be used locally or in BK (from flakyguard_lite_buildkite.sh)
# Example: bash flakyguard_lite.sh ~/project //path/to/your:test_target TestMethodName HEAD
set -o pipefail # if any command in a pipeline fails, the entire pipeline fails


if [[ $# -lt 3 ]]; then
    echo "Usage: bash flakyguard_lite.sh <repo_dir> <test_target> <test_case> [commit]"
    echo "Example: bash flakyguard_lite.sh ~/project //path/to/your:test_target TestMethodName HEAD"
    exit 1
fi


TIMEOUT_DURATION='1h'


PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}

# Get arguments
repo_dir=$1
test_target=$2
test_case=$3
commit=${4:-HEAD}

# Convert repo_dir to absolute path
repo_dir=$(cd "$repo_dir" && pwd)

timestamp=$(date +%s)
# Simple logging structure
logsDir="${repo_dir}/bazel-out/flakyguard_lite"
mkdir -p ${logsDir}

filename="log_${timestamp}"
log_file="${logsDir}/${filename}"
> "${log_file}" # ensures the log file exists and is empty
echo "logs can be found here: ${log_file}"

# Set PYTHONPATH to include local flakyguard package
# Find the flakyguard directory relative to the script location (before changing directory)
FLAKYGUARD_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
echo "FlakyGuard root: ${FLAKYGUARD_ROOT}" | tee -a "${log_file}"

# Activate virtual environment if it exists
VENV_PATH="${FLAKYGUARD_ROOT}/venv"
if [ -d "$VENV_PATH" ]; then
    echo "Activating virtual environment at: ${VENV_PATH}" | tee -a "${log_file}"
    source "${VENV_PATH}/bin/activate"
    echo "Using Python: $(which python3)" | tee -a "${log_file}"
else
    echo "Warning: Virtual environment not found at ${VENV_PATH}" | tee -a "${log_file}"
    echo "Please run setup_environment.sh first or ensure dependencies are installed" | tee -a "${log_file}"
fi

echo "Changing to repository directory: ${repo_dir}" | tee -a "${log_file}"
pushd "$repo_dir"  # push current to stack and cd to repository root
export PYTHONPATH="$FLAKYGUARD_ROOT:$PYTHONPATH"
echo "Current working directory: $(pwd)" | tee -a "${log_file}"

echo "Fixing test case: ${test_case} in target: ${test_target}" | tee -a "${log_file}"

# Run the fixer with timeout
fixer_command="python3 -m flakyguard.core.flaky_fixing_driver --test-target $test_target --test-case $test_case --monorepo-root $repo_dir"

echo "Running: ${fixer_command}" | tee -a "${log_file}"

# Check if running on macOS (timeout command not available)
if [[ "$(uname)" == "Darwin" ]]; then
    echo "Detected macOS - running without timeout" | tee -a "${log_file}"
    if $fixer_command | tee -a "${log_file}"; then
        echo "Process completed successfully" | tee -a "${log_file}"
    else
        echo "Process failed" | tee -a "${log_file}"
    fi
else
    if timeout $TIMEOUT_DURATION bash -c "eval \"$fixer_command\" | tee -a \"${log_file}\""; then
        echo "Process completed within timeout" | tee -a "${log_file}"
    else
        if [[ $? -eq 124 ]]; then
            echo "Process timed out after $TIMEOUT_DURATION" | tee -a "${log_file}"
        else
            echo "Process failed" | tee -a "${log_file}"
        fi
    fi
fi
popd  # pop the stack and cd back to the previous directory
