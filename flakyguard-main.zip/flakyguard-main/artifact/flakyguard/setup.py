#!/usr/bin/env python3

from setuptools import setup, find_packages

setup(
    name="flakyguard",
    version="0.1.0",
    description="Automated flaky test detection and fixing tool",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "tree-sitter>=0.20.0",
        "pocketflow",
        "typing-extensions",
    ],
    entry_points={
        "console_scripts": [
            "flakyguard=flakyguard.cli:main",
        ],
    },
    package_data={
        "flakyguard": [
            "core/best_practices.txt",
            "core/table_driven.txt",
            "llm/tree-sitter-grammars/*.so",
        ],
    },
    include_package_data=True,
)
