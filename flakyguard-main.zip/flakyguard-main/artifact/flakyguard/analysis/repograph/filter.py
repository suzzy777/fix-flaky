from __future__ import annotations

from flakyguard.utils.coverage.lcov_parser import Report
from flakyguard.analysis.repograph.repograph import Tag


def coverage_filter(report: Report, tag: Tag, is_python: bool = False) -> bool:
    """
    Filter out tags that are not covered by the coverage report.
    """
    if report is None:
        return True  # If no coverage report, include all tags
    
    file_to_lines = report.get_file_to_lines_executed()
    if tag.rel_fname not in file_to_lines:
        return False
    lines_executed = file_to_lines[tag.rel_fname]
    start, end = tag.line
    # both tags and coverage reports are 1-based
    if is_python:
        # python coverage reports are weird, since it is posible that the method header is covered but the method body is not.
        # so we only check the method body.
        return any(line in lines_executed for line in range(start + 1, end + 1))
    else:
        return any(line in lines_executed for line in range(start, end + 1))
