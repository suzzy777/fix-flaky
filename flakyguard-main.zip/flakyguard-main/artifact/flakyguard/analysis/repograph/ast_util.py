from __future__ import annotations

import os
from typing import Callable

import tree_sitter as ts

import flakyguard.llm.tree_sitter_util as ts_util
from flakyguard.utils.core_parser import get_root_from_file

ALL_POSSIBLE_FUNCTION_DECLARATION_TYPES = ["method_declaration", "function_declaration", "func_literal", "constructor_declaration", "function_definition"]


class TreesitterNode:
    def __init__(self, node: ts.Node, filename: str):
        self.node = node  # tree-sitter node loses the file information, so we need to store it.
        self.filename = filename

    def __str__(self):
        return f"file={self.filename}\n{self.node.text.decode()}"

    def __repr__(self):
        return self.__str__()

    def get_function_code(self) -> str:
        return self.node.text.decode("utf-8")


def find_nodes(node: ts.Node, fn: Callable[[ts.Node], bool]) -> list[ts.Node]:
    found_nodes = []

    # Apply the function to the current node
    if fn(node):
        found_nodes.append(node)

    # Recursively visit each child
    for child in node.children:
        found_nodes.extend(find_nodes(child, fn))

    return found_nodes


def find_nodes_by_type(node: ts.Node, types: list[str]) -> list[ts.Node]:
    return find_nodes(node, lambda n: n.type in types)


def find_nodes_by_type_and_lines(node: ts.Node, types: list[str], at_lines: list[int]) -> list[ts.Node]:
    return find_nodes(node, lambda n: n.type in types and n.start_point[0] + 1 in at_lines)


def find_nodes_by_type_and_including_line(node: ts.Node, types: list[str], included_line: int) -> list[ts.Node]:
    return find_nodes(node, lambda n: n.type in types and n.start_point[0] + 1 <= included_line <= n.end_point[0] + 1)




def get_cached_root(filename, file_root_cache):
    if filename not in file_root_cache:
        file_root_cache[filename] = get_root_from_file(filename)
    return file_root_cache[filename]


def tag_to_treesitter_node(filename: str, start: int) -> TreesitterNode | None:
    root = get_root_from_file(filename)
    func_nodes = find_nodes_by_type_and_lines(root, ALL_POSSIBLE_FUNCTION_DECLARATION_TYPES, [start])
    for func_node in func_nodes:
        return TreesitterNode(func_node, filename)
    return None


def get_pkg(root_node: ts.Node):
    """Get package declaration nodes."""
    return find_nodes_by_type(
        root_node,
        [
            "package_clause",
        ],
    )


def get_imports(root_node: ts.Node):
    """Get import declaration nodes."""
    return find_nodes_by_type(
        root_node,
        [
            "import_spec",
        ],
    )
