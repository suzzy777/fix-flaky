various tools for computing the scope, which is basically a set of files.

coverage_scope:
use the coverage to find the covered files

file_scope:
the basic way of finding files, find the files in the parent of n-th level.

target_scope:
find the owner targets, then optionally the deps targets, then the srcs of them.

see *_cli.py for examples at the file headers.
