from __future__ import annotations

import os
import re


def file_scope(file_or_dir: str, up_level: int = 0, include_test: bool = False, suffixes: list[str] | None = None) -> set[str]:
    """Find file scope without need for monorepo_root, returns absolute paths."""
    folder = file_or_dir
    if not os.path.isdir(file_or_dir):
        folder = os.path.dirname(file_or_dir)

    for _ in range(up_level):
        folder = os.path.dirname(folder)

    src_files = set()
    for root, _, files in os.walk(folder):
        for file in files:
            ext = file.rsplit(".", 1)[-1]
            if (not suffixes or (ext in suffixes)) and (not re.search(r"test", file, re.IGNORECASE) or include_test):
                full_path = os.path.join(root, file)
                src_files.add(full_path)
    return src_files


def file_scope_relative(
    monorepo_root: str, file_or_dir: str, up_level: int = 0, include_test: bool = False, suffixes: list[str] | None = None
) -> set[str]:
    results = file_scope(file_or_dir, up_level, include_test, suffixes)
    results = [os.path.relpath(result, monorepo_root) for result in results]
    return results
