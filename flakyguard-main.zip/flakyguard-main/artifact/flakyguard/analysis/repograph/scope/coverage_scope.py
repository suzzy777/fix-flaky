from __future__ import annotations

from flakyguard.utils.coverage.compute_coverage import compute_coverage
from flakyguard.utils.coverage.lcov_parser import Report
from flakyguard.definitions.language import Language


def coverage_scope(
    monorepo_root: str, test_target: str, test_case: str | None = None, *, language: Language = "go", include_test_files: bool = True, retries: int = 10
) -> set[str] | None:
    report = compute_coverage(monorepo_root, test_target, test_case, include_test_files, retries=retries)
    if report is None:
        return None
    return _coverage_scope_from_report(report, language)


def _coverage_scope_from_report(report: Report, language: Language) -> set[str]:
    file_to_lines = report.get_file_to_lines_executed()
    files = [k for k, v in file_to_lines.items() if len(v) > 0]

    # Filter files based on language - keep all files for now
    # if language == "go":
    #     files = [f for f in files if f.startswith("src/")]
    return set(files)
