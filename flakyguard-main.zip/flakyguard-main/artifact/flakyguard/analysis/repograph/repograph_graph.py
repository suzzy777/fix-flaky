# copied from agentless/graph_context.py
# but this is the latest version.
from __future__ import annotations

from typing import Callable

import networkx as nx

from flakyguard.analysis.repograph.ast_util import (
    ALL_POSSIBLE_FUNCTION_DECLARATION_TYPES,
    TreesitterNode,
    find_nodes_by_type_and_lines,
    get_cached_root,
)
from flakyguard.analysis.repograph.repograph import CodeGraph, Tag

LANG_TO_SUFFIX = {
    "java": "java",
    "go": "go",
    "python": "py",
    "javascript": "js",
    "typescript": "ts",
    "rust": "rs",
    "scala": "scala",
    "csharp": "cs",
    "php": "php",
}


# define a class to build graph while reusing the code graph
class RepographBuilder:
    def __init__(self, root_dir: str, scope: set[str], filter_func: Callable[[Tag], bool] | None = None):
        self.cg = CodeGraph(root=root_dir)
        # convert files in scope to absolute path by prefixing root_dir if not
        self.files = scope

        self.graph_tags, _ = self.cg.get_code_graph(self.files)
        if filter_func is not None:
            # performs the filtering.
            self.graph_tags = [tag for tag in self.graph_tags if filter_func(tag)]

        self.file_root_cache = {}

    def find_func_def_tags(self, func_names):
        tags = []
        for search_term in func_names:
            for tag in self.graph_tags:
                if tag.name == search_term and tag.kind == "def" and tag.category == "function":
                    tags.append(tag)
        return tags

    def find_direct_callers(self, func_def_tag: Tag) -> list[Tag]:
        caller_funcs_per_tag = []
        for tag in self.graph_tags:
            if tag.kind == "ref" and tag.category == "function" and tag.name == func_def_tag.name:
                # Find the enclosing function definition for this reference
                for potential_caller in self.graph_tags:
                    if (
                        potential_caller.kind == "def"
                        and potential_caller.category == "function"
                        and potential_caller.rel_fname == tag.rel_fname
                        and potential_caller.line[0] <= tag.line[0]
                        and potential_caller.line[1] >= tag.line[1]
                    ):
                        caller_funcs_per_tag.append(potential_caller.name)
        # my callers
        new_caller_func_tags = self.find_func_def_tags(caller_funcs_per_tag)
        return new_caller_func_tags

    def find_direct_callees(self, func_def_tag: Tag) -> list[Tag]:
        callee_funcs_per_tag = []
        # Find all function references within this function's body
        for tag in self.graph_tags:
            if tag.rel_fname == func_def_tag.rel_fname:
                start, end = func_def_tag.line
                if tag.line[0] >= start and tag.line[1] <= end and tag.kind == "ref" and tag.category == "function":
                    callee_funcs_per_tag.append(tag.name)
        # my callees
        new_callee_func_tags = self.find_func_def_tags(callee_funcs_per_tag)
        return new_callee_func_tags

    def find_transitive_callers(self, funcs: list[str], depth_limit: int = 1) -> list[Tag]:
        initial_tags = self.find_func_def_tags(funcs)
        # do not build graph, just use the above find_direct_callers.
        # write a recursive function to find the transitive callers.
        result = []

        def find_transitive_callers_recursive(func_def_tag: Tag, depth: int) -> list[Tag]:
            if depth > depth_limit:
                return result
            if func_def_tag in result:
                return result
            result.append(func_def_tag)
            callers = self.find_direct_callers(func_def_tag)
            for caller in callers:
                find_transitive_callers_recursive(caller, depth + 1)
            return result

        for func_def_tag in initial_tags:
            find_transitive_callers_recursive(func_def_tag, 0)
        return result

    def find_transitive_callees(self, funcs: list[str], depth_limit: int = 1) -> list[Tag]:
        initial_tags = self.find_func_def_tags(funcs)
        # do not build graph, just use the above find_direct_callees.
        # write a recursive function to find the transitive callees.
        result = []

        def find_transitive_callees_recursive(func_def_tag: Tag, depth: int) -> list[Tag]:
            if depth > depth_limit:
                return result
            if func_def_tag in result:
                return result
            result.append(func_def_tag)
            callees = self.find_direct_callees(func_def_tag)
            for callee in callees:
                find_transitive_callees_recursive(callee, depth + 1)
            return result

        for func_def_tag in initial_tags:
            find_transitive_callees_recursive(func_def_tag, 0)
        return result

    def tag_to_treesitter_node(self, tag: Tag) -> TreesitterNode | None:
        filename = tag.fname
        start, _ = tag.line  # 1- based line number
        root = get_cached_root(filename, self.file_root_cache)
        func_nodes = find_nodes_by_type_and_lines(root, ALL_POSSIBLE_FUNCTION_DECLARATION_TYPES, [start])
        for func_node in func_nodes:
            return TreesitterNode(func_node, filename)
        return None

    def tags_to_treesitter_nodes(self, tags: list[Tag]) -> list[TreesitterNode]:
        result = []
        for tag in tags:
            node = self.tag_to_treesitter_node(tag)
            if node is not None:
                result.append(node)
        return result

    # def build_calling_graph(self, funcs: list[str], depth_limit: int = 1) -> nx.DiGraph:
    #     # from bottom to top, build the graph, find the transitive callers of the given funcs.
    #     # from these transitive callers, more precisely the final callers, find their transitive callees.
    #     # eventually, the graph returned is a callee graph, with the given funcs as internal nodes.
    #     callerG = self.build_caller_graph(funcs, depth_limit)
    #     # find leaf nodes in callerG
    #     final_callers = [node for node in callerG.nodes() if callerG.out_degree(node) == 0]
    #     # build callee graph from the final callers
    #     final_caller_names = [node.name for node in final_callers]
    #     calleeG = self.build_callee_graph(final_caller_names, depth_limit)
    #     return calleeG

    def build_caller_graph(self, funcs: list[str], depth_limit: int = 1) -> nx.DiGraph:
        # build the graph, and return the graph.
        # this is mainly for visualization. The search utility does not rely on this graph.

        # Start with the initial set of function tags for the given functions
        initial_tags = self.find_func_def_tags(funcs)
        initial_tag_identifiers = set()
        tag_map = {}
        # init graph
        G = nx.DiGraph()

        for tag in initial_tags:
            identifier = (tag.fname, tag.name)
            G.add_node(tag)
            initial_tag_identifiers.add(identifier)
            tag_map[identifier] = tag  # Map the identifier to the full tag

        all_caller_tags = initial_tag_identifiers

        funcs_to_explore = initial_tags
        cur_depth = 0

        # Continue exploring until no more new function identifiers are found
        while funcs_to_explore:
            cur_depth += 1
            # Find all functions that call the current set of functions
            new_caller_func_tags_total = set()
            for func_def_tag in funcs_to_explore:
                new_caller_func_tags_local = self.find_direct_callers(func_def_tag)
                new_caller_func_tags_total.update(new_caller_func_tags_local)
                # add edges to the graph
                # each node has fname and line, add the node if it is not in the graph
                if func_def_tag not in G:
                    G.add_node(func_def_tag)
                for new_caller_func_tag in new_caller_func_tags_local:
                    if new_caller_func_tag not in G:
                        G.add_node(new_caller_func_tag)
                    # add edge if there is no edge between them:
                    if not G.has_edge(func_def_tag, new_caller_func_tag):
                        G.add_edge(func_def_tag, new_caller_func_tag)

            # Create a set of new identifiers for the newly found caller functions
            new_caller_func_identifiers = set()

            for tag in new_caller_func_tags_total:
                identifier = (tag.fname, tag.name)
                new_caller_func_identifiers.add(identifier)
                tag_map[identifier] = tag  # Map the identifier to the full tag

            # Update the set of function identifiers to explore with the new ones not yet explored
            funcs_to_explore = [tag_map[identifier] for identifier in new_caller_func_identifiers if identifier not in all_caller_tags]

            # Add the new function identifiers to the set of all caller function identifiers
            all_caller_tags.update(new_caller_func_identifiers)

            if cur_depth >= depth_limit:
                break

        return G

    def build_callee_graph(self, funcs: list[str], depth_limit: int = 1) -> nx.DiGraph:
        # build the graph, and return the graph.
        # this is mainly for visualization. The search utility does not rely on this graph.
        # Start with the initial set of function tags for the given functions
        initial_tags = self.find_func_def_tags(funcs)
        initial_tag_identifiers = set()
        tag_map = {}
        # init graph
        G = nx.DiGraph()

        for tag in initial_tags:
            identifier = (tag.fname, tag.name)
            G.add_node(tag)
            initial_tag_identifiers.add(identifier)
            tag_map[identifier] = tag  # Map the identifier to the full tag
        all_callee_tags = initial_tag_identifiers

        funcs_to_explore = initial_tags
        cur_depth = 0

        # Continue exploring until no more new function identifiers are found
        while funcs_to_explore:
            cur_depth += 1
            # Find all functions that are called by the current set of functions
            new_callee_func_tags_total = set()
            for func_def_tag in funcs_to_explore:
                new_callee_func_tags_local = self.find_direct_callees(func_def_tag)
                new_callee_func_tags_total.update(new_callee_func_tags_local)
                # add edges to the graph
                # each node has fname and line, add the node if it is not in the graph
                if func_def_tag not in G:
                    G.add_node(func_def_tag)
                for new_callee_func_tag in new_callee_func_tags_local:
                    if new_callee_func_tag not in G:
                        G.add_node(new_callee_func_tag)
                    # add edge if there is no edge between them:
                    if not G.has_edge(func_def_tag, new_callee_func_tag):
                        G.add_edge(func_def_tag, new_callee_func_tag)

            # Create a set of new identifiers for the newly found callee functions
            new_callee_func_identifiers = set()

            for tag in new_callee_func_tags_total:
                identifier = (tag.fname, tag.name)
                new_callee_func_identifiers.add(identifier)
                tag_map[identifier] = tag  # Map the identifier to the full tag

            # Update the set of function identifiers to explore with the new ones not yet explored
            funcs_to_explore = [tag_map[identifier] for identifier in new_callee_func_identifiers if identifier not in all_callee_tags]

            # Add the new function identifiers to the set of all callee function identifiers
            all_callee_tags.update(new_callee_func_identifiers)

            if cur_depth >= depth_limit:
                break

        return G


# def find_methods_given_class(graph_tags, class_name):
#     method_names = []
#     tags = []
#     for tag in graph_tags:
#         if tag.name == class_name and tag.kind == "def":
#             tags.append(tag)
#     for _, tag in enumerate(tags):
#         if tag.category == "class":
#             method_names.extend(get_function_names(tag.funcs_in_class))
#     return method_names


# def find_called_funcs(graph_tags, func_def_tags):
#     called_funcs = []
#     for _, func_def_tag in enumerate(func_def_tags):
#         for tag in graph_tags:
#             if tag.rel_fname == func_def_tag.rel_fname:
#                 start, end = func_def_tag.line
#                 if tag.line[0] >= start and tag.line[1] <= end and tag.kind == "ref" and tag.category == "function":
#                     called_funcs.append(tag.name)

#     return called_funcs
