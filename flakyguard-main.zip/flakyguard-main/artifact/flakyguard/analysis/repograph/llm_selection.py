from __future__ import annotations

import re

from flakyguard.llm.llm import LLMWrapper
from flakyguard.analysis.repograph.ast_util import tag_to_treesitter_node
from flakyguard.analysis.repograph.repograph import Tag
from flakyguard.analysis.repograph.repograph_graph import RepographBuilder


def default_llm_based_select(nodes: list[Tag], k: int, problem_statement: str) -> list[Tag]:
    """
    Use LLM to select k nodes from the given list.
    Follows the pattern from dynamic_call_graph_extraction.py.

    Args:
        nodes: List of nodes to select from
        k: Number of nodes to select

    Returns:
        List of selected nodes
    """
    if not nodes:
        return []

    llm = LLMWrapper.get_instance()
    treesitter_nodes = []
    for node in nodes:
        treesitter_node = tag_to_treesitter_node(node.fname, node.line[0])
        if treesitter_node is not None:
            treesitter_nodes.append(treesitter_node)

    candidates = "\n".join(f"index {i}\n file: {node.filename}\n code:{node.node.text.decode()}" for i, node in enumerate(treesitter_nodes))

    # Create a prompt for the LLM
    prompt = f"""{problem_statement}

Select {k} most relevant functions from the following list:
{candidates}

Return the indices of selected functions in <INDICES> tags, comma-separated.
Example: <INDICES>0,2,4</INDICES>"""

    # Get completion from LLM
    response = llm.get_completion(prompt, temperature=0.0)

    # Extract indices from response
    new_func_indices_str = re.search(r"<INDICES>(.*?)</INDICES>", response, re.DOTALL)
    if new_func_indices_str:
        new_func_indices_match = new_func_indices_str.group(1)
        new_func_indices = [int(id_str) for id_str in new_func_indices_match.split(",") if id_str.strip()]
        return [nodes[i] for i in new_func_indices if i >= 0 and i < len(nodes)]
    return []


if __name__ == "__main__":
    # change to your own path
    cg = RepographBuilder("/path/to/your/project", include_test=False)
    G = cg.build_calling_graph(["smart_bfs_search"], depth_limit=5)
    all_nodes = list(G.nodes())
    results = default_llm_based_select(all_nodes, 2, "which functions are most relevant to the function smart_bfs_search?")
    for result in results:
        print(result)
