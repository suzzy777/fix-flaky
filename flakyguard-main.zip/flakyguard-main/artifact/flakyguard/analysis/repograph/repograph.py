# what duts it do?
#  It generates the tags (like ctags) and a graph (like call graph) for a given codebase.
# How to use?
#   cg = CodeGraph(root=repo_folder)
#   graph_tags, code_graph = cg.get_code_graph(chat_fnames_new)
#   graph_tags is a list of tags, where one tag looks like this:
# (Pdb) p graph_tags[100]
# Example Tag: rel_fname='astropy/config/configuration.py', fname='<path>/astropy/astropy/config/configuration.py', line=[268, 268], name='isiterable', kind='ref', category='function'
#  code_graph is a networkx graph object, where each node is a str, e.g., `setup_package_py_8_get_extensions` means the function `get_extensions` in the file `setup_package.py` at line 8. The edges can be either call edges or class-has-method edges.
from __future__ import annotations

import os
import sqlite3
import warnings
from pathlib import Path
from typing import NamedTuple

import tree_sitter as ts

import flakyguard.llm.tree_sitter_util as ts_util

# tree_sitter is throwing a FutureWarning
warnings.simplefilter("ignore", category=FutureWarning)


# rewrite Tag as a subclass of NamedTuple
class Tag(NamedTuple):
    rel_fname: str
    fname: str
    # make it a tuple so that it is hashable for networkx
    line: tuple[int, int]  # start and end line number, 1-indexed
    name: str
    kind: str
    category: str
    # info: str
    # funcs_in_class: list[ts.Node] = None  # only for class tags


BIG_NUMBER = 1e10
SQLITE_ERRORS = (sqlite3.OperationalError, sqlite3.DatabaseError, OSError)

# we do not consider annoymous functions like lambda functions
LANG_NODE_TYPES = {
    "java": {
        # https://github.com/tree-sitter/tree-sitter-java/blob/master/src/grammar.json
        "method_declaration",
        "constructor_declaration",
        "annotation_type_element_declaration",
        "compact_constructor_declaration",
    },
    "go": {
        # https://github.com/tree-sitter/tree-sitter-go/blob/master/src/grammar.json
        # Named (top-level) function
        "function_declaration",
        # Named method with a receiver
        "method_declaration",
    },
    "python": {
        # https://github.com/tree-sitter/tree-sitter-python/blob/master/src/grammar.json
        "function_definition"
    },
}


def get_functions_in_class(root_node: ts.Node, language: str) -> list[ts.Node]:
    if language not in LANG_NODE_TYPES:
        raise ValueError(f"Unsupported language: {language}")

    node_types = LANG_NODE_TYPES[language]
    function_nodes = ts_util.find_nodes_by_type(root_node, list(node_types))
    return_nodes = []
    for fn_node in function_nodes:
        func_name = get_function_name(fn_node)
        if func_name != "" and not func_name.startswith("__"):  # let us skip the magic methods like __init__
            return_nodes.append(fn_node)
    return return_nodes


def get_function_name(function_node: ts.Node) -> str:
    name_node = function_node.child_by_field_name("name")
    if name_node is not None:
        func_name = name_node.text.decode("utf-8")
        return func_name
    return ""


def get_function_names(function_nodes: list[ts.Node]) -> list[str]:
    function_names = []
    for fn_node in function_nodes:
        func_name = get_function_name(fn_node)
        if func_name != "":
            function_names.append(func_name)
    return function_names



def get_scm_fname(lang):
    # Load the tags queries
    try:
        path = f"{os.path.dirname(os.path.abspath(__file__))}/queries/tree-sitter-{lang}-tags.scm"
        return Path(path)
    except KeyError:
        return


# read_text function reads content from a file
def read_text(fname):
    with open(fname, "r") as f:
        return f.read()


def filename_to_lang(file_abs_path):
    file_ext = os.path.splitext(file_abs_path)[1]  # for example: .java
    language = file_ext[1:]
    mapping = {"py": "python", "java": "java", "go": "go", "swift": "swift"}
    if language in mapping:
        language = mapping[language]
        return language
    else:
        return None


class CodeGraph:
    def __init__(
        self,
        root=None,
        verbose=False,
    ):
        self.verbose = verbose

        self.warned_files = set()
        if not root:
            root = os.getcwd()
        self.root = root

    def get_code_graph(self, other_files, mentioned_fnames=None):
        if not other_files:
            return None, None
        if not mentioned_fnames:
            mentioned_fnames = set()

        tags = self.get_tag_files(other_files, mentioned_fnames)
        # code_graph = self.tag_to_graph(tags)
        return tags, None  # keep None forbackward compatibility

    def get_tag_files(self, other_files, mentioned_fnames=None):
        try:
            tags = self.get_ranked_tags(other_files, mentioned_fnames)
            return tags
        except RecursionError:
            print("Disabling code graph, git repo too large?")
            return

    def get_rel_fname(self, fname):
        return os.path.relpath(fname, self.root)

    def split_path(self, path):
        path = os.path.relpath(path, self.root)
        return [path + ":"]

    def get_mtime(self, fname):
        try:
            return os.path.getmtime(fname)
        except FileNotFoundError:
            print(f"File not found error: {fname}")

    def get_tags(self, fname, rel_fname):
        # Check if the file is in the cache and if the modification time has not changed
        file_mtime = self.get_mtime(fname)
        if file_mtime is None:
            return []
        # miss!
        data = list(self.get_tags_raw(fname, rel_fname))
        return data

    def get_tags_raw(self, fname, rel_fname):
        lang = filename_to_lang(fname)
        if not lang:
            return

        with open(str(fname), "r", encoding="utf-8") as f:
            codelines = f.readlines()

        lang_str = filename_to_lang(fname)
        if not lang_str:
            return
        try:
            parser, language = ts_util.create_parser(lang_str)
        except Exception as err:
            print(f"Skipping file {fname}: {err}")
            return

        query_scm = get_scm_fname(lang_str)
        if not query_scm.exists():
            return
        query_scm = query_scm.read_text()

        code = read_text(fname)
        if not code:
            return
        tree = parser.parse(bytes(code, "utf-8"))

        # Run the tags queries
        query = language.query(query_scm)
        captures = query.captures(tree.root_node)
        captures = list(captures)

        saw = set()
        for node, tag in captures:
            if tag.startswith("name.definition."):
                kind = "def"
            elif tag.startswith("name.reference."):
                kind = "ref"
            else:
                continue

            saw.add(kind)
            cur_cdl = codelines[node.start_point[0]]
            # this simple keyword based approach works for Python/Java.
            # For go, it is more complicated: the struct and its methods may not even be in the same file.
            # For simplicity, we will ignore the class-has-methods relationship.
            category = "class" if "class " in cur_cdl else "function"
            tag_name = node.text.decode("utf-8")
            if category == "class":  # imply that this is a class def.
                try:
                    # in python, it is class_definition. In Java, it is class_declaration.
                    # do not distinguish them for simplicity.
                    class_node = ts_util.find_first_parent_of_type(node, ["class_definition", "class_declaration"])
                    # class_function_nodes = get_functions_in_class(class_node, lang_str)
                    # class_function_names = get_function_names(class_function_nodes)
                except Exception:
                    pass
                    # class_function_names = []
                    # class_function_nodes = []
                line_nums = (node.start_point[0] + 1, node.end_point[0] + 1)
                if kind == "def":
                    # if it is class definition, line nums refer to the start and end line number of the class.
                    line_nums = [class_node.start_point[0] + 1, class_node.end_point[0] + 1]

                result = Tag(
                    rel_fname=rel_fname,
                    fname=fname,
                    name=tag_name,
                    kind=kind,
                    category=category,
                    # info="\n".join(class_function_names),  # list unhashable, use string instead
                    # funcs_in_class=class_function_nodes,
                    line=line_nums,
                )

            elif category == "function":
                line_nums = [node.start_point[0] + 1, node.end_point[0] + 1]
                if kind == "def":
                    # if it is method definition, line nums refer to the start and end line number of the method.
                    method_types = LANG_NODE_TYPES[lang]
                    method_node = ts_util.find_first_parent_of_type(node, method_types)
                    if method_node:
                        line_nums = (method_node.start_point[0] + 1, method_node.end_point[0] + 1)
                result = Tag(
                    rel_fname=rel_fname,
                    fname=fname,
                    name=tag_name,
                    kind=kind,
                    category=category,
                    # info=cur_cdl,
                    line=line_nums,
                )

            yield result

        return

    def get_ranked_tags(self, other_fnames, mentioned_fnames):
        tags_of_files = list()
        personalization = dict()
        fnames = set(other_fnames)
        fnames = sorted(fnames)

        # Default personalization for unspecified files is 1/num_nodes
        # https://networkx.org/documentation/stable/_modules/networkx/algorithms/link_analysis/pagerank_alg.html#pagerank
        personalize = 10 / len(fnames)

        for fname in fnames:
            if not os.path.isabs(fname):
                # help convert to absolute path if it is not already
                fname = os.path.join(self.root, fname)
            if not Path(fname).is_file():
                if fname not in self.warned_files:
                    if Path(fname).exists():
                        print(f"Code graph can't include {fname}, it is not a normal file")
                    else:
                        print(f"Code graph can't include {fname}, it no longer exists")

                self.warned_files.add(fname)
                continue

            rel_fname = self.get_rel_fname(fname)
            if fname in mentioned_fnames:
                personalization[rel_fname] = personalize
            tags = list(self.get_tags(fname, rel_fname))

            tags_of_files.extend(tags)

            if tags is None:
                continue

        return tags_of_files
