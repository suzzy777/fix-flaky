# Repograph

Repograph is a static call graph analysis tool that helps you understand function relationships in your codebase. It builds a graph of function calls and provides utilities to explore caller-callee relationships.

## Key Features

### 1. Scope

Control which files to analyze using scope functions:

```python
from repograph.scope.file_scope import file_scope

# Analyze all files in a directory
scope = file_scope("/path/to/project", include_test=True)

# Build the graph with the specified scope
builder = RepographBuilder("/path/to/project", scope=scope)
```

### 2. Filter

Apply filters to focus on specific functions based on criteria like test coverage:

```python
from repograph.filter.coverage_filter import coverage_filter

# Create a filter function for coverage-based filtering
def filter_func(tag):
    return coverage_filter(coverage_report, tag, is_python=True)

# Build graph with filtering
builder = RepographBuilder("/path/to/project", scope=scope, filter_func=filter_func)
```

## Basic Usage

```python
from repograph.repograph_graph import RepographBuilder
from repograph.scope.file_scope import file_scope

# Define scope
scope = file_scope("/path/to/project")

# Create builder
builder = RepographBuilder("/path/to/project", scope=scope)

# Find functions that call a specific function
callers = builder.find_direct_callers(func_tag)

# Find functions called by a specific function  
callees = builder.find_direct_callees(func_tag)

# Build complete caller/callee graphs
caller_graph = builder.build_caller_graph(["function_name"], depth_limit=2)
callee_graph = builder.build_callee_graph(["function_name"], depth_limit=2)
```