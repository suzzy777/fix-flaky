from __future__ import annotations

import logging
from collections import deque
from enum import Enum
from typing import Callable

from flakyguard.analysis.repograph.llm_selection import default_llm_based_select
from flakyguard.analysis.repograph.repograph import Tag
from flakyguard.analysis.repograph.repograph_graph import RepographBuilder


class SearchStrategy(Enum):
    BFS = "bfs"
    BEAM = "beam"
    RANDOM_WALK = "random_walk"
    SMART_BFS = "smart_bfs"


class RepographSearcher:
    def __init__(
        self,
        *,
        builder: RepographBuilder | None = None,
        root_dir: str | None = None,
        scope: set[str] | None = None,
        problem_statement: str = "",
        llm_select: Callable[[list[Tag], int], list[Tag]] | None = None,
        beam_width: int = 3,
        number_of_children_per_node: int = 3,
        random_walk_samples: int = 100,
        callee_only: bool = False,
        callers_only: bool = False,
    ):
        if builder is not None:
            self.builder = builder
        else:
            if root_dir is None or scope is None:
                raise ValueError("root_dir and scope must be provided when builder is not given")
            self.builder = RepographBuilder(root_dir, scope)
        self.logger = logging.getLogger(__name__)
        self.beam_width = beam_width
        self.random_walk_samples = random_walk_samples
        self.llm_select = llm_select if llm_select is not None else default_llm_based_select
        self.number_of_children_per_node = number_of_children_per_node
        self.callee_only = callee_only
        self.callers_only = callers_only
        assert not (callee_only and callers_only), "callee_only and callers_only cannot be both True"
        self.problem_statement = problem_statement

    def bfs_search(self, start_funcs: list[str], depth_limit: int = -1) -> list[Tag]:
        """
        Perform a breadth-first search starting from the given functions.

        Args:
            start_funcs: List of function names to start the search from
            depth_limit: Maximum depth to traverse (-1 for no limit)

        Returns:
            List of Tags visited in BFS order
        """
        source_nodes = self.builder.find_func_def_tags(start_funcs)
        visited = set(source_nodes)
        # Use a queue of (node, depth) pairs
        queue = deque((node, 0) for node in source_nodes)

        while queue:
            current, depth = queue.popleft()
            if depth_limit != -1 and depth >= depth_limit:
                continue  # Don't expand this node's neighbors
            mycallers, mycallees = self.builder.find_direct_callers(current), self.builder.find_direct_callees(current)
            if self.callee_only:
                my_neighbors = mycallees
            elif self.callers_only:
                my_neighbors = mycallers
            else:
                # put callees first, then callers.
                my_neighbors = mycallees + mycallers
            for neighbor in my_neighbors:
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, depth + 1))

        return list(visited)

    def smart_bfs_search(self, start_funcs: list[str], depth_limit: int = -1) -> list[Tag]:
        """
        Perform a breadth-first search starting from the given functions.

        Args:
            start_funcs: List of function names to start the search from
            depth_limit: Maximum depth to traverse (-1 for no limit)

        Returns:
            List of Tags visited in BFS order
        """
        source_nodes = self.builder.find_func_def_tags(start_funcs)

        visited = source_nodes  # we need order, so we need a list instead of set.
        queue = deque((node, 0) for node in source_nodes)

        while queue:
            current, depth = queue.popleft()
            if depth_limit != -1 and depth >= depth_limit:
                continue  # Don't expand this node's neighbors
            mycallers, mycallees = self.builder.find_direct_callers(current), self.builder.find_direct_callees(current)
            if self.callee_only:
                my_neighbors = mycallees
            elif self.callers_only:
                my_neighbors = mycallers
            else:
                # put callees first, then callers
                my_neighbors = mycallees + mycallers
            # llm based selection:
            my_neighbors_not_visited = [neighbor for neighbor in my_neighbors if neighbor not in visited]

            # add current function to the problem statement since its control flow logic matters in the selection.
            problem_statement_with_current = self.problem_statement
            current_node = self.builder.tag_to_treesitter_node(current)
            if current_node:
                problem_statement_with_current += f"\nCurrent function to decide the selection: {current_node.node.text.decode()}"

            my_neighbors = self.llm_select(my_neighbors_not_visited, self.number_of_children_per_node, problem_statement_with_current)
            for neighbor in my_neighbors:
                if neighbor not in visited:
                    visited.append(neighbor)
                queue.append((neighbor, depth + 1))
        return visited

    def beam_search(self, start_funcs: list[str], depth_limit: int = -1) -> list[Tag]:
        """
        Perform a beam search starting from the given functions.
        At each level, only the top beam_width nodes are kept for exploration.

        Args:
            start_funcs: List of function names to start the search from
            depth_limit: Maximum depth to traverse (-1 for no limit)

        Returns:
            List of Tags visited in beam search order
        """
        # Build a caller graph starting from the given functions
        source_nodes = self.builder.find_func_def_tags(start_funcs)
        result = []
        result.extend(source_nodes)

        # Perform beam search using the graph
        current_level = source_nodes
        depth = 0
        while current_level and (depth_limit == -1 or depth < depth_limit):
            next_level = []
            for node in current_level:
                # Get all neighbors (callees)
                mycallers, mycallees = self.builder.find_direct_callers(node), self.builder.find_direct_callees(node)
                if self.callee_only:
                    my_neighbors = mycallees
                elif self.callers_only:
                    my_neighbors = mycallers
                else:
                    # put callees first, then callers
                    my_neighbors = mycallees + mycallers
                for neighbor in my_neighbors:
                    if neighbor not in result:
                        next_level.append(neighbor)

            if next_level:
                current_level = self.llm_select(next_level, self.beam_width, self.problem_statement)
                result.extend(current_level)
            else:
                current_level = []

            depth += 1

        return result

    def random_walk(self, start_funcs: list[str], depth_limit: int = -1) -> list[Tag]:
        """
        Perform multiple random walks starting from the given functions.
        For each sample:
            - Start from each source node
            - Walk downstream until hitting depth limit
            - Collect all nodes visited

        Args:
            start_funcs: List of function names to start the search from
            depth_limit: Maximum depth to traverse (-1 for no limit)

        Returns:
            List of Tags visited in all random walks
        """
        # Build a caller graph starting from the given functions
        source_nodes = self.builder.find_func_def_tags(start_funcs)
        result = []

        if not source_nodes:
            return result

        # Take multiple samples
        for _ in range(self.random_walk_samples):
            # For each sample, start from each source node
            for source_node in source_nodes:
                current_node = source_node
                result.append(current_node)
                current_depth = 0

                # Walk downstream until hitting depth limit
                while depth_limit == -1 or current_depth < depth_limit:
                    mycallees, mycallers = self.builder.find_direct_callees(current_node), self.builder.find_direct_callers(current_node)
                    if self.callee_only:
                        my_neighbors = mycallees
                    elif self.callers_only:
                        my_neighbors = mycallers
                    else:
                        # put callees first, then callers.
                        my_neighbors = mycallees + mycallers
                    if not my_neighbors:
                        break

                    # Randomly choose next node
                    current_node = self.llm_select(my_neighbors, 1, self.problem_statement)[0]
                    result.append(current_node)
                    current_depth += 1

        return result

    def search(self, start_funcs: list[str], strategy: SearchStrategy = SearchStrategy.BFS, depth_limit: int = -1) -> list[Tag]:
        """
        Perform a search using the specified strategy.

        Args:
            start_funcs: List of function names to start the search from
            strategy: The search strategy to use
            depth_limit: Maximum depth to traverse (-1 for no limit)
            include_itself: Whether to include the start functions in the result
            beam_width: Width of the beam for beam search
            num_steps: Number of steps for random walk

        Returns:
            List of Tags visited according to the search strategy
        """

        if strategy == SearchStrategy.BFS:
            return self.bfs_search(start_funcs, depth_limit)
        elif strategy == SearchStrategy.SMART_BFS:
            return self.smart_bfs_search(start_funcs, depth_limit)
        elif strategy == SearchStrategy.BEAM:
            return self.beam_search(start_funcs, depth_limit)
        elif strategy == SearchStrategy.RANDOM_WALK:
            return self.random_walk(start_funcs, depth_limit)
        else:
            raise NotImplementedError(f"Strategy {strategy} not implemented yet")
