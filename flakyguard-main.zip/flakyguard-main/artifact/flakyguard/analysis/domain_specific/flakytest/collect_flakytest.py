from __future__ import annotations

import os

from flakyguard.utils.bazel_cmd import run_bazel_cmd
from flakyguard.analysis.domain_specific.flakytest.bazel_log_analyzer import (
    FlakyInfo,
    extract_failure_details_for_golong,
    parse_flaky_info_from_log_golang,
)
from flakyguard.analysis.domain_specific.flakytest.flakyinfo import TEST_TIMEOUT_LIMIT


def _collect_flakytest_target_level(
    test_target: str,
    test_case: str,
    monorepo_root: str,
    runs_per_test: int = 1000,
    enable_mini_batching: bool = True,
) -> FlakyInfo | None:
    return _collect_flakytest_batched(
        test_target=test_target,
        test_case=test_case,
        monorepo_root=monorepo_root,
        runs_per_test=runs_per_test,
        use_test_filter=False,
        enable_mini_batching=enable_mini_batching,
    )


def _collect_flakytest_batched(
    test_target: str,
    test_case: str,
    monorepo_root: str,
    runs_per_test: int,
    use_test_filter: bool = True,
    enable_mini_batching: bool = True,
) -> FlakyInfo | None:
    # Use batched approach: start with 1/10 of runs, then continue if needed
    if enable_mini_batching:
        batch_size = max(1, runs_per_test // 10)
        remaining_runs = runs_per_test
    else:
        batch_size = runs_per_test
        remaining_runs = runs_per_test

    result_dir = os.path.join(monorepo_root, "bazel-out")
    os.makedirs(result_dir, exist_ok=True)
    build_event_log = os.path.abspath(os.path.join(result_dir, "build_event_log.json"))

    while remaining_runs > 0:
        current_batch = min(batch_size, remaining_runs)
        remaining_runs -= current_batch

        # Build command with or without test filter
        if use_test_filter:
            test_target_cmd = f"bazel test --test_timeout={TEST_TIMEOUT_LIMIT} {test_target} --runs_per_test={current_batch} --cache_test_results=no --test_env=GO_TEST_WRAP_TESTV=1 --@io_bazel_rules_go//go/config:race --build_event_json_file {build_event_log} --test_filter {test_case}"
        else:
            test_target_cmd = f"bazel test --test_timeout={TEST_TIMEOUT_LIMIT} {test_target} --runs_per_test={current_batch} --cache_test_results=no --test_env=GO_TEST_WRAP_TESTV=1 --@io_bazel_rules_go//go/config:race --build_event_json_file {build_event_log}"

        print(f"running batch with {current_batch} runs: {test_target_cmd}")
        stdout, _, return_code = run_bazel_cmd(test_target_cmd, monorepo_root)
        
        if return_code != 0:
            # both test failure and test timeout are not OK.
            failure_details = extract_failure_details_for_golong(stdout)
            if failure_details != []:
                for failure_log in failure_details:
                    # the test target starts with //, we need to remove the // and get the dir_path that contains the flaky test
                    dir_path = test_target[2 : test_target.find(":")]
                    failure_xml = failure_log.replace("test.log", "test.xml")
                    flakyinfos_from_logs = parse_flaky_info_from_log_golang(failure_xml, failure_log, dir_path, test_target, test_case, monorepo_root)
                    for flakyinfo_from_log in flakyinfos_from_logs:
                        # exact match only
                        if flakyinfo_from_log.test_name == test_case:  # or flakyinfo_from_log.test_name.startswith(test_case + "/"):
                            flakyinfo = flakyinfo_from_log
                            print(f"Flaky test detected in batch! Returning early after {runs_per_test - remaining_runs} runs.")
                            return flakyinfo

    return None


def collect_flakytest(
    test_target: str,
    test_case: str,
    monorepo_root: str,
    runs_per_test: int = 1000,
    also_try_target_level: bool = True,
    enable_mini_batching: bool = True,
) -> FlakyInfo | None:
    # Try test case level first with batched approach
    result = _collect_flakytest_batched(
        test_target=test_target,
        test_case=test_case,
        monorepo_root=monorepo_root,
        runs_per_test=runs_per_test,
        use_test_filter=True,
        enable_mini_batching=enable_mini_batching,
    )

    if result is not None:
        return result

    if also_try_target_level:
        # give it a chance to collect the flaky info at target level
        # some flaky tests are not caused by the test case itself, but by other tests in the same target.
        return _collect_flakytest_target_level(test_target, test_case, monorepo_root, runs_per_test, enable_mini_batching)
    return None
