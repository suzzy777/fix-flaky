from __future__ import annotations

from flakyguard.analysis.domain_specific.flakytest.collect_flakytest import collect_flakytest


def validate_flakiness_gone(
    test_target: str,
    test_case: str,
    monorepo_root: str,
    runs_per_test: int = 1000,
) -> tuple[bool, str | None]:
    """
    Validates the flakiness of the test is gone.

    It returns the validation status and the stacktrace of the flaky test.
    If the test is not flaky, it returns True, None, which stands for the flakiness is gone.
    Otherwise, it returns False, the stacktrace of the flaky test.
    """
    result = collect_flakytest(test_target, test_case, monorepo_root, runs_per_test, enable_mini_batching=False)
    if result is None:
        return True, None
    return False, result.error_trace
