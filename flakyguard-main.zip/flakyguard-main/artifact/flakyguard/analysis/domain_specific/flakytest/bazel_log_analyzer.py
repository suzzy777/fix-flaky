from __future__ import annotations

import html
import os
import re
import xml.etree.ElementTree as ET

from flakyguard.analysis.domain_specific.flakytest.flakyinfo import FlakyInfo
from flakyguard.utils.test_helper.finder import find_test_file_with_test_case

_ANSI_ESCAPE_REGEX = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")

_GOLANG_TEST_FAILURE_REGEX = re.compile(
    r"(?P<file_name>[^:\s]+\.go):(?P<line>\d+):\s+Error Trace:\s+"
    r"(?P<error_trace>.+?)\s+Error:\s+(?P<error>.+?)Test:\s+"
    r"(?P<test_name>[^\s]+)\s+(Messages:\s+[^\s]+)?",
    re.DOTALL,
)


_GOLANG_TEST_ERROR_NAME_REGEX = re.compile(
    r"---\s+FAIL:\s+(?P<test_name>[^\s]+)\s+",
    re.DOTALL,
)


def _strip_ansi_codes(text: str) -> str:
    return _ANSI_ESCAPE_REGEX.sub("", text)


def get_test_cases_from_xml(failed_test_item_xml: str):
    # find all test cases in the xml file, including the root itself and its descendants
    try:
        tree = ET.parse(failed_test_item_xml)
        root = tree.getroot()

        test_cases = []

        if root.tag == "testcase":
            test_cases.append(root)

        test_cases.extend(root.findall(".//testcase"))
        return test_cases
    except ET.ParseError as e:
        print("XML Parse Error:", e)
    except Exception as e:
        print("Error:", e)


def get_flaky_info_from_failed_xml_golang(
    failed_test_item_xml: str, desired_test_case: str, relative_test_file_path: str, dir_path: str = ""
) -> list[FlakyInfo]:
    # Parse the XML string
    test_cases = get_test_cases_from_xml(failed_test_item_xml)
    issues: list[FlakyInfo] = []

    fallback_triggered = False
    for test_case_obj in test_cases:
        test_name = test_case_obj.get("name")
        # exact match only, no need to check the prefix
        if (
            test_name != desired_test_case
        ):  # and (not test_name.startswith(desired_test_case + "/"))) and (not desired_test_case.startswith(test_name + "/")
            continue
        # Find all failure elements
        failures = test_case_obj.findall(".//failure") + test_case_obj.findall(".//error")

        for failure in failures:
            # At this point, we definitely already found the stack trace for the flaky test case,
            # we should return a FlakyInfo at least for validation.
            # see a concrete example in test_bazel_log_analyzer.py, or testdata/test.xml
            if failure is not None:
                # Unescape HTML entities
                stacktrace = html.unescape(failure.text).strip()
                print("stacktrace: " + str(stacktrace))
                stacktrace = _strip_ansi_codes(stacktrace)
                matches = _GOLANG_TEST_FAILURE_REGEX.finditer(stacktrace, re.DOTALL)
                issues.extend(
                    [
                        FlakyInfo(
                            language="go",
                            test_name=test_name,
                            file_name=match.group("file_name"),
                            path=match.group("error_trace").split(":")[0].strip(),
                            test_file_path=relative_test_file_path,
                            line=int(match.group("line")),
                            error_trace=match.group("error_trace"),
                            error=match.group("error"),
                        )
                        for match in matches
                    ]
                )
                if len(issues) == 0:
                    # just match the whole stack trace for the test case
                    # match the file_name and line number such that they are the go file under the flaky test target.
                    # rf"{re.escape(dir_path)}/" tries to match the the directory of the test target.
                    # r"(?P<file_name>[^:\s]+(?<!_)\.go) tries to match the go file name that does not end with "_" like "go_default_test_.go"
                    _GOLANG_TEST_PATH_REGEX = re.compile(
                        rf"{re.escape(dir_path)}/" r"(?P<file_name>[^:\s]+(?<!_)\.go):(?P<line>\d+)",
                        re.DOTALL,
                    )
                    another_matches = list(_GOLANG_TEST_PATH_REGEX.finditer(stacktrace, re.DOTALL))
                    if len(another_matches) > 0:
                        another_match = another_matches[0]
                        issues.append(
                            FlakyInfo(
                                language="go",
                                test_name=test_name,
                                file_name=another_match.group("file_name"),
                                path=relative_test_file_path,
                                test_file_path=relative_test_file_path,
                                line=int(another_match.group("line")),
                                error_trace=stacktrace,
                                error=stacktrace,
                            )
                        )
                    else:
                        _GOLANG_BROAD_TEST_PATH_REGEX = re.compile(
                            rf"({re.escape(dir_path)}/)?" r"(?P<file_name>[^:\s]+\_test\.go):(?P<line>\d+)",
                            re.DOTALL,
                        )
                        another_match = _GOLANG_BROAD_TEST_PATH_REGEX.search(stacktrace, re.DOTALL)
                        if another_match:
                            issues.append(
                                FlakyInfo(
                                    language="go",
                                    test_name=test_name,
                                    file_name=another_match.group("file_name"),
                                    path=relative_test_file_path,
                                    test_file_path=relative_test_file_path,
                                    line=int(another_match.group("line")),
                                    error_trace=stacktrace,
                                    error=stacktrace,
                                )
                            )
                        else:
                            # fallback logic
                            fallback_triggered = True

    if fallback_triggered:
        error_msg = f"The test of interest is {desired_test_case}, only look at the entries associated with it or its prefix test cases, as listed below. "

        for test_case_obj in test_cases:
            test_name = test_case_obj.get("name")
            # relaxed matching: we also consider its prefix since sometimes the error msg is associated with the prefix test cases.
            # while we are interested in TestGetActiveSessions/Successful, the useful error message about the mock call is attached to TestGetActiveSessions.
            # to fix the problem, we need to get the entry for TestGetActiveSessions and use it as the error trace.
            # instead of parsing, we simply collect the relevant entries and let LLM figure out what to use.
            if (test_name != desired_test_case) and not desired_test_case.startswith(test_name + "/"):
                continue
            # Find all failure elements
            failures = test_case_obj.findall(".//failure") + test_case_obj.findall(".//error")

            for failure in failures:
                if failure is not None:
                    # Unescape HTML entities
                    stacktrace = html.unescape(failure.text).strip()
                    error_msg += f"\nThe error message for {test_name} is: {stacktrace}"

        file_name = os.path.basename(relative_test_file_path)
        issues.append(
            FlakyInfo(
                language="go",
                test_name=desired_test_case,
                file_name=file_name,
                path=relative_test_file_path,
                test_file_path=relative_test_file_path,
                line=None,
                error_trace=error_msg,
                error=error_msg,
            )
        )

    return issues


def validate_flaky_from_failed_xml_golang(failed_test_item_xml: str, test_case: str):
    test_cases = get_test_cases_from_xml(failed_test_item_xml)

    for test_case_obj in test_cases:
        test_name = test_case_obj.get("name")
        # exact match only
        if test_name != test_case:  # and (not test_name.startswith(test_case + "/")):
            continue
        # Find all failure elements
        failures = test_case_obj.findall(".//failure") + test_case_obj.findall(".//error")

        if len(list(failures)) > 0:
            # Unescape HTML entities
            stacktrace = html.unescape(list(failures)[0].text).strip()
            return True, stacktrace
    return False, None


def get_test_file_path_from_error_trace(error_trace: str) -> str:
    # Regular expression to find all .go files
    # see a concrete example in test_bazel_log_analyzer.py, the last .go is the test file started by src/runtime/asm_arm64.s
    go_files = re.findall(r"(src/[^:\s]+\.go):\d+", error_trace)

    if go_files:
        last_go_file = go_files[-1]
        return last_go_file
    else:
        return ""


def get_mock_flaky_info_from_log_golang(contents: str, dir_path: str, test_case: str, relative_test_file_path: str) -> list[FlakyInfo]:
    # deal with mock error/failure match
    # Why do we directly extract from the whole log file?
    # It's because there are mismatches between the test name and the stack trace.
    # TODO: let us discuss the reason in details.
    issues: list[FlakyInfo] = []
    # panic = ""
    # _GOLANG_PANIC_REGEX = re.compile(
    #     r"(panic:|ERROR)\s+" r"(?P<panic>.+?)\s+(\n|===|---|$)",
    #     re.DOTALL,
    # )
    # panic_matches = _GOLANG_PANIC_REGEX.finditer(contents)
    # for panic_match in panic_matches:
    #     panic = panic_match.group("panic")
    matched_test_names = _GOLANG_TEST_ERROR_NAME_REGEX.finditer(contents, re.DOTALL)
    for matched_test_name in matched_test_names:
        test_name = matched_test_name.group("test_name")
        # exact match only
        if test_name != test_case:  # and (not test_name.startswith(test_case + "/"))) and (not test_case.startswith(test_name + "/")):
            continue
        _GOLANG_TEST_ERROR_REGEX = re.compile(
            rf"===\s+(RUN|NAME|CONT)\s+{re.escape(test_name)}\n(?!===\s+(RUN|PAUSE|CONT|NAME)|---)" r"(?P<error_trace>.+?)\s+" r"(===\s+(RUN|CONT)|---|$)",
            re.DOTALL,
        )
        matched_error_traces = _GOLANG_TEST_ERROR_REGEX.finditer(contents)
        error_trace = ""
        for matched_error_trace in matched_error_traces:
            error_trace += matched_error_trace.group("error_trace")
            # Will only deal with one kind of error_trace; there also should be only one
            break
        _GOLANG_TEST_PATH_REGEX = re.compile(
            rf"{re.escape(dir_path)}/" r"(?P<file_name>[^:\s]+\_test\.go):(?P<line>\d+)",
            re.DOTALL,
        )
        # concatenate both the error trace and the panic error
        # error_trace = error_trace + "\n" + panic
        matched_file_names = _GOLANG_TEST_PATH_REGEX.finditer(error_trace)
        file_name = ""
        line = ""
        for matched_file_name in matched_file_names:
            file_name = matched_file_name.group("file_name")
            line = matched_file_name.group("line")
            break
        path = dir_path + "/" + file_name
        if error_trace != "" and line != "" and file_name != "" and path != "":
            # Print stack trace
            print("The other parsed stacktrace (the mocked error and panic error)")
            print(error_trace)
            error = error_trace.split("\n")[-1]
            issues.append(
                FlakyInfo(
                    language="go",
                    test_name=test_name,
                    file_name=file_name,
                    path=path,
                    test_file_path=relative_test_file_path,
                    line=int(line),
                    error_trace=error_trace,
                    error=error,
                )
            )

    return issues


def parse_flaky_info_from_log_golang(xml_path: str, log_path: str, dir_path: str, test_target: str, test_case: str, monorepo_root: str) -> list[FlakyInfo]:
    """
    Parses the contents of a failure log (in plain text) and returns
    a list of FlakyInfos. If there are log files, it means the flaky test
    comes from go language.
    build_event_log is to find the exact xml that contains the failed test and assertion errors.
    the log_path contains the whole log results, in which we can find the mocked error and panic.
    The dir_path is used to match the test name.
    """
    issues: list[FlakyInfo] = []
    with open(log_path) as f:
        contents = _strip_ansi_codes(f.read())

    test_file_path = find_test_file_with_test_case(test_target, test_case, monorepo_root)
    if test_file_path is None:
        return issues
    relative_test_file_path = test_file_path[len(monorepo_root) + 1 :]

    xml_issues = get_flaky_info_from_failed_xml_golang(xml_path, test_case, relative_test_file_path, dir_path)
    issues.extend(xml_issues)

    if len(issues) == 0:
        issues.extend(get_mock_flaky_info_from_log_golang(contents, dir_path, test_case, relative_test_file_path))

    return issues


def extract_failure_details_for_golong(test_output) -> list[str]:
    # Regex pattern to extract the failure details and test log path
    fail_pattern = re.compile(r"//.*?:.*?FAILED.*")
    log_pattern = re.compile(r"(/.*?/test\.log)")

    fail_matches = fail_pattern.findall(test_output)
    log_matches = log_pattern.findall(test_output)
    if not fail_matches:
        return []

    exist_log_matches = log_matches
    for log_match in log_matches:
        if not os.path.exists(log_match):
            exist_log_matches.remove(log_match)
    return exist_log_matches
