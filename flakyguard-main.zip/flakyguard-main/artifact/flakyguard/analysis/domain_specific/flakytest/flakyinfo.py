from __future__ import annotations

import dataclasses
import json
from typing import Any

from flakyguard.definitions.language import Language

TEST_TIMEOUT_LIMIT = 300  # seconds, the --test_timeout flag in Bazel specifies the timeout for each individual test rather than the entire test run or all shards collectively.


@dataclasses.dataclass(frozen=True)
class FlakyInfo:
    """Represents a flaky failure."""

    language: Language
    test_name: str
    file_name: str
    path: str
    line: int
    error_trace: str
    error: str

    # the `path` field above is the file where the error was raised, while the test_file_path is file where the test function lives in
    # they are not necessarily the same. For example, a test file may invoke a function in another file that performs the assertions.
    test_file_path: str = ""
    # computed on demand
    line_of_assertions: str = ""  # this field is for fixing and manual inspection.

    def serialize(self) -> str:
        """
        Serializes a frozen instance to a human-readable JSON string.
        """
        return json.dumps(dataclasses.asdict(self), indent=4)

    @staticmethod
    def from_json(input: str | dict[str, Any]) -> FlakyInfo:
        """
        Deserializes a JSON string back into a frozen instance.
        """
        result = FlakyInfo(
            **(json.loads(input) if isinstance(input, str) else input),
        )
        return result
