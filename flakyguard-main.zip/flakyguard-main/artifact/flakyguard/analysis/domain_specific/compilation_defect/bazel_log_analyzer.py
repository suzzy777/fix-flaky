from __future__ import annotations

import json
import re


from flakyguard.analysis.domain_specific.compilation_defect.compilation_defect import CompilationDefect, Severity


_GO_DIAGNOSTIC = "builder failed: "
_NOGO_DIAGNOSTIC = "nogo: errors found by nogo during build-time code analysis"


_JAVAC_ISSUE_REGEX = re.compile(
    # The message can end in three way:
    # 1. The end of the string
    # 2. A newline followed by a bazel progress message (which starts with [)
    # 3. A message indicating that the target failed to build
    # 4. Another javac issue
    r"\n(?P<path>[^:\s]+):(?P<line>\d+): (?P<severity>warning|error):( \[(?P<checker>\w+)\])? (?P<msg>.*?)(?=$|\n\[|Target .* failed to build\n|\n[^:\s]+:\d+: (warning|error):)",
    re.DOTALL,
)

# In the compilation error like the following, the ending string included inside () could be mistakenly extracted as a check.
# To avoid the complexity of distinguishing the cases in one regex,  we prepare two regex below,
# one for the compilation error without check, the other for the nogo check.
# \nsrc/example/path/to/simple_compile_error.go:7:14:
#  cannot use 0.5 (untyped float constant)
#  as int value in variable declaration (truncated)\ncompilepkg
# We rely on some keyword phrases to decide which regex to apply.

_GOLANG_COMPILATION_ERROR_REGEX = re.compile(
    r"(?P<path>[^:\s]+\.go):(?P<line>\d+):(?P<column>\d+): (?P<msg>.+?)(?=\n|$)",
)
_NOGO_ISSUE_REGEX = re.compile(
    r"(?P<path>[^:\s]+\.go):(?P<line>\d+):(?P<column>\d+): (?P<msg>.+?) \((?P<checker>[\w]+)\)(?=\n|$)",
)
_IMPORT_DEPENDENCY_ERROR_REGEX = re.compile(
    r"compilepkg: missing strict dependencies:\n(?P<lines>(\s+(?P<path>[^:]+\.go): import of (?P<package>.+)\n)+)No dependencies were provided\."
)

_ANSI_ESCAPE_REGEX = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def _strip_ansi_codes(text: str) -> str:
    return _ANSI_ESCAPE_REGEX.sub("", text)

def parse_bazel_log(path: str) -> list[CompilationDefect]:
    """
    Parses the contents of a bazel build event log (in streamed JSON format) and returns
    a list of CompilationDefects. The log can be obtained by running bazel
    with the --build_event_json_file flag.
    """
    issues: list[CompilationDefect] = []

    with open(path) as f:
        for line in f:
            event = json.loads(line)
            if "progress" in event and "stderr" in event["progress"]:
                stderr = _strip_ansi_codes(event["progress"]["stderr"])
                if _GO_DIAGNOSTIC in stderr:
                    if _NOGO_DIAGNOSTIC in stderr:
                        matches = _NOGO_ISSUE_REGEX.finditer(stderr)
                        issues.extend(
                            [
                                CompilationDefect(
                                    language="go",
                                    path=match.group("path"),
                                    line=int(match.group("line")),
                                    check=match.group("checker"),
                                    message=match.group("msg").strip(),
                                    severity=Severity("ERROR"),
                                )
                                for match in matches
                            ]
                        )
                    else:
                        matches = _GOLANG_COMPILATION_ERROR_REGEX.finditer(stderr)
                        issues.extend(
                            [
                                CompilationDefect(
                                    language="go",
                                    path=match.group("path"),
                                    line=int(match.group("line")),
                                    check=None,
                                    message=match.group("msg").strip(),
                                    severity=Severity("ERROR"),
                                )
                                for match in matches
                            ]
                        )
                else:
                    matches = _JAVAC_ISSUE_REGEX.finditer(stderr)
                    issues.extend(
                        [
                            CompilationDefect(
                                language="java",
                                path=match.group("path"),
                                line=int(match.group("line")),
                                check=match.group("checker"),
                                message=match.group("msg").strip(),
                                severity=Severity(match.group("severity").upper()),
                            )
                            for match in matches
                        ]
                    )
    return list(set(issues))
