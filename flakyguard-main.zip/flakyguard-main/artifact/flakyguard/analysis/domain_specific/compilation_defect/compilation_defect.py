from __future__ import annotations

import dataclasses
import enum
import json
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from flakyguard.definitions.language import Language


class Severity(str, enum.Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"


@dataclass(frozen=True)
class CompilationDefect:
    """Represents a compiler warning or error."""

    language: Language
    path: str
    line: int
    check: str | None
    message: str
    severity: Severity

    def serialize(self) -> str:
        """
        Serializes a CompilationDefect instance to a human-readable JSON string.
        """
        return json.dumps(asdict(self), indent=4)

    @staticmethod
    def from_json(input: str | dict[str, Any]) -> CompilationDefect:
        """
        Deserializes a JSON string back into a CompilationDefect instance.
        """
        result = CompilationDefect(
            **(json.loads(input) if isinstance(input, str) else input),
        )
        result = dataclasses.replace(result, severity=Severity(result.severity))
        return result
