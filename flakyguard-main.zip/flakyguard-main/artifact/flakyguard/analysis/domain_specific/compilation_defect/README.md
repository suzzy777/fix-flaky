# Compilation Defect Detection

This module provides tools for detecting and analyzing compilation defects (errors and warnings) in Bazel builds.

## Overview

The compilation defect detection system helps identify compiler warnings and errors by:
- Running Bazel builds with comprehensive logging
- Parsing build event logs to extract compilation issues
- Providing structured data about defects for analysis and remediation

## Key Components

### Core Classes

- **`CompilationDefect`** (`compilation_defect.py`): Data class representing a compiler warning or error
  - Contains: language, file path, line number, check type, message, and severity
  - Supports JSON serialization/deserialization

- **`Severity`**: Enum for defect severity levels (ERROR, WARNING)

### Main Functions

- **`collect_compilation_defects()`** (`collect_compilation_defects.py`): 
  - Runs Bazel build on specified targets
  - Captures build event logs
  - Returns build status and list of compilation defects

- **`parse_bazel_log()`** (`bazel_log_analyzer.py`): 
  - Parses Bazel build event JSON logs
  - Extracts compilation defects from build failures

- **`validate_defects_gone()`** (`validate_defects_gone.py`): 
  - Validates that previously identified defects have been resolved

## Usage

### Installation

```bash
# Install the package
pip install -e .
```

### Example Usage

```python
from flakyguard.analysis.domain_specific.compilation_defect import collect_compilation_defects

# Collect compilation defects for specific targets
targets = ["//path/to/target:name"]
monorepo_root = "/path/to/repo"

return_code, defects = collect_compilation_defects(targets, monorepo_root)

# Process defects
for defect in defects:
    print(f"{defect.severity}: {defect.path}:{defect.line} - {defect.message}")
```

## Features

- **Comprehensive Error Detection**: Captures both errors and warnings from compilation
- **Structured Output**: Provides machine-readable defect information
- **Build Integration**: Works with Bazel's build event protocol
- **Validation Support**: Includes tools to verify defect resolution
- **JSON Serialization**: Easy data exchange and storage

## Implementation

The module provides core functionality for compilation defect detection and analysis in software projects.