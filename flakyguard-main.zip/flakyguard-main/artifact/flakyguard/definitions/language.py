"""Language definitions for FlakyGuard."""

from enum import Enum


class Language(Enum):
    """Supported programming languages."""

    GO = "go"
    PYTHON = "python"
    JAVA = "java"
    CPP = "cpp"
    JAVASCRIPT = "javascript"
    TYPESCRIPT = "typescript"
    RUST = "rust"
    UNKNOWN = "unknown"

    @classmethod
    def from_file_extension(cls, file_path: str) -> "Language":
        """Determine language from file extension."""
        if file_path.endswith(".go"):
            return cls.GO
        elif file_path.endswith((".py", ".pyx")):
            return cls.PYTHON
        elif file_path.endswith(".java"):
            return cls.JAVA
        elif file_path.endswith((".cpp", ".cc", ".cxx", ".c", ".h", ".hpp")):
            return cls.CPP
        elif file_path.endswith(".js"):
            return cls.JAVASCRIPT
        elif file_path.endswith(".ts"):
            return cls.TYPESCRIPT
        elif file_path.endswith(".rs"):
            return cls.RUST
        else:
            return cls.UNKNOWN

    @classmethod
    def from_test_target(cls, test_target: str) -> "Language":
        """Determine language from test target."""
        if "go_default_test" in test_target or ":go_" in test_target:
            return cls.GO
        elif "py_test" in test_target or ":py_" in test_target:
            return cls.PYTHON
        elif "java_test" in test_target or ":java_" in test_target:
            return cls.JAVA
        else:
            return cls.UNKNOWN
