"""Definitions module for FlakyGuard."""
