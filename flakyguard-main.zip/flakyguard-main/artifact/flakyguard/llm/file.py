from __future__ import annotations

import dataclasses
import logging
from typing import Optional

import tree_sitter

from flakyguard.llm.formatting import get_indentation, increase_indentation
from flakyguard.llm.location import (
    byte_offset_to_character_offset,
)

logger = logging.getLogger(__name__)


@dataclasses.dataclass(frozen=True)
class Edit:
    """
    An edit to a file, represented by a start and end character offset, as well as the updated contents. Zero-based offsets. End is exclusive.
    """

    start: int
    end: int
    new_content: str


@dataclasses.dataclass
class File:
    """
    Represents a file in memory, and allows for modifications to the contents of that file by performing edit operations.
    All edits are collected and can be applied by calling current_content.

    Does not support overlapping edits.
    """

    initial_content: str
    _edits: list[Edit] = dataclasses.field(default_factory=list[Edit])

    def get_sorted_edits(self) -> list[Edit]:
        """
        Returns a sorted list of edits, starting from the last edit in the file. This way,
        the edits can be applied one after the other without having to re-compute offsets.
        """
        edits = sorted(self._edits, key=lambda e: e.start, reverse=True)
        return edits

    def current_content(self) -> str:
        result = self.initial_content
        edits = self.get_sorted_edits()
        # Note: edits are non-overlapping.
        for edit in edits:
            result = result[: edit.start] + edit.new_content + result[edit.end :]
        return result

    def replace_tree_sitter_node(
        self,
        node: tree_sitter.Node,
        new_content: str,
    ) -> None:
        """
        Add an edit that replaces the given tree sitter AST node with new_content.
        """
        start = byte_offset_to_character_offset(node.start_byte, self.initial_content)
        indentation = get_indentation(self.initial_content, start)
        end = byte_offset_to_character_offset(node.end_byte, self.initial_content)
        self.add_edit(Edit(start, end, increase_indentation(new_content, indentation)))

    def delete_tree_sitter_node(self, node: tree_sitter.Node, handle_comma: bool = False) -> None:
        """
        Add an edit that deletes the given tree sitter AST node.
        Leading empty new lines, whitespace and leading/trailing commas (depending on position) are also removed.
        """
        start_offset = byte_offset_to_character_offset(node.start_byte, self.initial_content)
        end_offset = byte_offset_to_character_offset(node.end_byte, self.initial_content)

        # Check for leading whitespace
        leading_whitespace_range = self.find_leading_whitespace_range(start_offset)
        if leading_whitespace_range:
            # Make sure we don't delete part of the previous sibling
            prev_sibling_end_offset = byte_offset_to_character_offset(node.prev_sibling.end_byte, self.initial_content) if node.prev_sibling else -1
            start_offset = max(leading_whitespace_range[0], prev_sibling_end_offset)  # Delete up to previous sibling

        # Check for leading/trailing comma
        if handle_comma:
            content = self.initial_content
            # Check for trailing comma
            i = end_offset
            while i < len(content) and content[i].isspace():
                i += 1
            if i < len(content) and content[i] == ",":
                # Check if the comma is not already deleted in any previous edit
                comma_already_deleted = self._is_index_deleted(i)
                if not comma_already_deleted:
                    end_offset = i + 1  # Extend deletion range to include the comma
            else:
                # Check for leading comma (only if not at the start)
                j = start_offset - 1
                while j >= 0 and content[j].isspace():
                    j -= 1
                if j >= 0 and content[j] == ",":
                    # Check if the comma is not already deleted in any previous edit
                    comma_already_deleted = self._is_index_deleted(j)
                    if not comma_already_deleted:
                        start_offset = j  # Extend deletion range to include the comma
        logger.info(f"Deleting node {node.text.decode()} from {start_offset} to {end_offset}")
        self.add_edit(Edit(start_offset, end_offset, ""))

    def _is_index_deleted(self, index: int) -> bool:
        """
        Check if the index is already deleted in any of the edits.
        """
        return any(edit.start <= index < edit.end and edit.new_content == "" for edit in self._edits)

    def find_leading_whitespace_range(self, start_pos: int) -> Optional[tuple[int, int]]:  # noqa: UP045
        """
        Identifies the range of leading whitespace characters (including newlines)
        before the specified start character in the content. Returns the range as a tuple if found;
        otherwise, returns None.
        """
        end_pos = start_pos - 1  # Move one position back from the start_pos of the node
        found = False
        code = self.initial_content
        while end_pos >= 0:
            cur_char = code[end_pos]
            if cur_char.isspace():
                if cur_char == "\n":
                    found = True
                    break
                end_pos -= 1
            else:
                break
        if found:
            return end_pos, start_pos
        else:
            return None


    def insert(self, position: int, new_content: str) -> None:
        """
        Add an edit that inserts new_content at the given character offset.
        Important: Does not handle indentation changes.
        """
        self.add_edit(Edit(position, position, new_content))

    def add_edit(self, edit: Edit) -> None:
        """
        Append an edit to the list of edits. Checks for overlap and raises an exception if there is overlap.
        """
        if any(not (edit.end <= e.start or edit.start >= e.end) for e in self._edits):
            raise ValueError("Overlapping edits are not supported")
        self._edits.append(edit)

    def update_initial_content_and_reset_edits(self) -> None:
        self.initial_content = self.current_content()
        self._edits = []

