from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def get_indentation(content: str, character_offset: int) -> str:
    """
    Get the indentation of the line at the given position (0-based character offset).
    """
    start = character_offset
    while start > 0 and content[start - 1] != "\n":
        start -= 1
    end = start
    while end < len(content) and content[end] in [" ", "\t"]:
        end += 1
    return content[start:end]


def increase_indentation(fragment: str, indentation: str) -> str:
    """
    Increase the indentation of the given fragment by the given indentation.
    Does not modify the indentation of the first line.
    """
    lines = fragment.split("\n")
    return "\n".join([lines[0]] + [indentation + line for line in lines[1:]])
