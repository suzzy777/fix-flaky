from __future__ import annotations

import dataclasses
import json
from dataclasses import asdict


@dataclasses.dataclass(frozen=True)
class Location:
    """
    A source code location
    """

    file_path: str
    """The path to the file in question."""
    line: int
    """The line number, 1-based index."""

    def to_json(self) -> str:
        """
        Serializes a Location instance to a human-readable JSON string.
        """
        return json.dumps(asdict(self), indent=4)

    @staticmethod
    def from_json(content: str | bytes | bytearray) -> Location:
        return Location(**json.loads(content))


@dataclasses.dataclass(frozen=True)
class Position:
    """
    A position in a file.
    """

    line: int
    """The line number, 1-based index."""
    column: int
    """The column number, 1-based index."""

    def __str__(self) -> str:
        return f"L{self.line}:{self.column}"

    def __le__(self, other: Position) -> bool:
        return (self.line, self.column) <= (other.line, other.column)


@dataclasses.dataclass(frozen=True)
class Range:
    start: Position
    end: Position

    def __str__(self) -> str:
        return f"{self.start!s}-{self.end!s}"

    def intersect(self, other: Range) -> bool:
        # Without loss of generality, non-intersection always looks like this
        #
        #  self.start       self.end
        #     |---------------|
        #                        |---------------|
        #                      other.start       other.end
        return not (self.end <= other.start or other.end <= self.start)




def byte_offset_to_character_offset(bytes: int, contents: str) -> int:
    """
    Convert a byte offset to a character offset in the given contents
    """
    return len(contents.encode()[:bytes].decode())
