"""Simple wrapper around OpenAI API.

This library is on purpose kept simple, e.g., it hardcoded the model, organization, and headers.
"""

from __future__ import annotations

import os
import subprocess
import sys
import time
from typing import Any

import openai
from openai import OpenAI

MAX_RETRY_COUNT = 5

# Read model and API key from environment variables
CHAT_MODEL = os.getenv("OPENAI_CHAT_MODEL", "gpt-4")
API_KEY = os.getenv("OPENAI_API_KEY", "")

if not API_KEY:
    print("Warning: OPENAI_API_KEY environment variable not set")
    sys.exit(1)


class ChatAgent:
    def __init__(self):
        self.client = OpenAI(api_key=API_KEY)

    def send_completion(
        self,
        messages: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        how_many_responses: int = 1,
        extra_params: dict[str, Any] | None = None,
    ) -> str | list[str] | None:
        if messages is None:
            messages = []

        retry_count = 0
        while retry_count < MAX_RETRY_COUNT:
            try:
                # Send the completion request using the new API format
                if "o1" in CHAT_MODEL:
                    # o1 models don't support temperature, n, or top_p parameters
                    filtered_params = {}
                    if extra_params:
                        # Filter out unsupported parameters for o1 models
                        unsupported = {"temperature", "top_p", "n", "presence_penalty", "frequency_penalty"}
                        filtered_params = {k: v for k, v in extra_params.items() if k not in unsupported}
                    response = self.client.chat.completions.create(
                        model=CHAT_MODEL,
                        messages=messages,
                        **filtered_params,
                    )
                else:
                    response = self.client.chat.completions.create(
                        model=CHAT_MODEL,
                        messages=messages,
                        temperature=temperature,
                        n=how_many_responses,
                        **(extra_params or {}),
                    )
                if len(response.choices) == 1:
                    return response.choices[0].message.content
                if len(response.choices) > 1:
                    return [choice.message.content for choice in response.choices]
            except (
                openai.RateLimitError,
                openai.APIConnectionError,
                openai.APIError,
            ) as e:
                if retry_count == (MAX_RETRY_COUNT - 1):
                    print(f"Max retries reached. Raising exception: {e}")
                    raise  # Re-raise the exception if max retries reached

                # Exponential back-off
                retry_count += 1
                wait_time = 2**retry_count
                print(f"Error: {e}. Retrying in {wait_time} seconds... (Retry {retry_count}/{MAX_RETRY_COUNT})")
                time.sleep(wait_time)

        return None  # If all retries failed


# Compatibility wrapper to maintain existing LLMWrapper interface
class LLMWrapper:
    _instance = None

    @classmethod
    def get_instance(cls):
        """Get the singleton instance of LLMWrapper.
        Usage:
            llm = LLMWrapper.get_instance()
        """
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        if LLMWrapper._instance is not None:
            raise RuntimeError("Use LLMWrapper.get_instance() instead of constructor")
        self.chat_agent = ChatAgent()

    def get_completion(
        self,
        message: str,
        system_message: str = "You are an expert in software engineering.",
        temperature: float = 0.0,
        batch_size: int = 1,
        model: str = CHAT_MODEL,
        extra_params: dict[str, Any] | None = None,
    ) -> str | list[str] | None:
        messages = [{"role": "system", "content": system_message}, {"role": "user", "content": message}]
        return self.chat_agent.send_completion(messages, temperature, batch_size, extra_params)

    def get_completion_with_messages(
        self,
        messages: list[dict[str, Any]],
        temperature: float = 0.0,
        batch_size: int = 1,
        model: str = CHAT_MODEL,
        extra_params: dict[str, Any] | None = None,
    ) -> str | list[str] | None:
        return self.chat_agent.send_completion(messages, temperature, batch_size, extra_params)


if __name__ == "__main__":
    chat_agent = ChatAgent()

    sample_messages = [{"role": "assistant", "content": "Ok."}, {"role": "user", "content": "tell a joke."}]

    try:
        # Send completion request using ChatAgent
        response = chat_agent.send_completion(
            messages=sample_messages,
            temperature=0.7,
            how_many_responses=2,
            extra_params={"top_p": 0.95},
        )
        print("LLM Response:", response)
    except Exception as e:
        print("Error during LLM completion:", e)
