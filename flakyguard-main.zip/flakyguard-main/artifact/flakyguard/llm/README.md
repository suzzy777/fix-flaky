# LLM Libraries

## Overview
This directory contains two Python libraries for LLM (Large Language Model) interactions.
## Libraries

### llm.py
A minimalist library following the KISS (Keep It Simple, Stupid) principle. This library provides basic LLM interaction capabilities through the `LLMWrapper` class, which implements a singleton pattern for efficient resource management.

**Key Features:**
- Simple and straightforward implementation
- Singleton pattern for efficient resource usage
- No caller information needed
- Support for both single-message and multi-message completions
- Each get_completion call can specify the model.

### llm_with_tool_call.py
An advanced library that extends LLM capabilities with tool calling support through the `LLMToolCalling` class. This enables the LLM to interact with external functions and tools.

**Key Features:**
- Parses the tool call suggestions from LLM and actually executes them to produce results.
- Adds the tool call support to the models like Claude that do not support tool calls or do not follow the standard openai tool call formats.

## Usage
See llm_demo.py and llm_with_tool_call_demo.py for examples.
