#!/bin/bash

set -e

SCRIPT_DIR="$(dirname "$0")"
SOURCES="$SCRIPT_DIR/sources"

# Check if the directory exists
if [ -d "$SOURCES" ]; then
    # If it exists, delete it
    echo "Directory $SOURCES exists. Deleting..."
    rm -rf "$SOURCES"
fi
mkdir -p "$SOURCES/objects"

# Clone all languages
echo "Cloning all language repos..."
git clone --branch v0.21.0 --depth 1 https://github.com/tree-sitter/tree-sitter-java.git "$SOURCES/tree-sitter-java" > /dev/null 2>&1
git clone --branch v0.21.0 --depth 1 https://github.com/tree-sitter/tree-sitter-go.git "$SOURCES/tree-sitter-go" > /dev/null 2>&1
git clone --branch v0.21.0 --depth 1 https://github.com/tree-sitter/tree-sitter-python.git "$SOURCES/tree-sitter-python" > /dev/null 2>&1

OS=$(uname -s)

if [ "$OS" = "Darwin" ]; then
    echo "Compiling for OSX..."

    # Compile languages
    gcc -fPIC -arch arm64 -mmacosx-version-min=10.6 -c "$SOURCES/tree-sitter-java/src/parser.c" -o "$SOURCES/objects/java.o"
    gcc -fPIC -arch arm64 -mmacosx-version-min=10.6 -c "$SOURCES/tree-sitter-go/src/parser.c" -o "$SOURCES/objects/go.o"
    gcc -fPIC -arch arm64 -mmacosx-version-min=10.6 -c "$SOURCES/tree-sitter-python/src/parser.c" -o "$SOURCES/objects/python.o"
    gcc -fPIC -arch arm64 -mmacosx-version-min=10.6 -c "$SOURCES/tree-sitter-python/src/scanner.c" -o "$SOURCES/objects/python-scanner.o"

    # Link the object files into a shared library
    gcc -shared -arch arm64 -mmacosx-version-min=10.6 -o "$SCRIPT_DIR/tree-sitter-java-darwin-universal.so" "$SOURCES/objects/java.o"
    gcc -shared -arch arm64 -mmacosx-version-min=10.6 -o "$SCRIPT_DIR/tree-sitter-go-darwin-universal.so" "$SOURCES/objects/go.o"
    gcc -shared -arch arm64 -mmacosx-version-min=10.6 -o "$SCRIPT_DIR/tree-sitter-python-darwin-universal.so" "$SOURCES/objects/python.o" "$SOURCES/objects/python-scanner.o"

    echo "Done."
elif [ "$OS" = "Linux" ]; then
    echo "Compiling for Linux..."
    echo "Make sure you have the aarch64-linux-gnu-gcc package installed: sudo apt-get install gcc-aarch64-linux-gnu"

    # Compile languages
    gcc -fPIC  -c "$SOURCES/tree-sitter-java/src/parser.c" -o "$SOURCES/objects/java.o"
    gcc -fPIC  -c "$SOURCES/tree-sitter-go/src/parser.c" -o "$SOURCES/objects/go.o"
    gcc -fPIC  -c "$SOURCES/tree-sitter-python/src/parser.c" -o "$SOURCES/objects/python.o"
    gcc -fPIC  -c "$SOURCES/tree-sitter-python/src/scanner.c" -o "$SOURCES/objects/python-scanner.o"
    aarch64-linux-gnu-gcc -fPIC -c "$SOURCES/tree-sitter-java/src/parser.c" -o "$SOURCES/objects/java-arm.o"
    aarch64-linux-gnu-gcc -fPIC -c "$SOURCES/tree-sitter-go/src/parser.c" -o "$SOURCES/objects/go-arm.o"
    aarch64-linux-gnu-gcc -fPIC -c "$SOURCES/tree-sitter-python/src/parser.c" -o "$SOURCES/objects/python-arm.o"
    aarch64-linux-gnu-gcc -fPIC -c "$SOURCES/tree-sitter-python/src/scanner.c" -o "$SOURCES/objects/python-scanner-arm.o"


    # Link the object files into a shared library
    gcc -shared -o "$SCRIPT_DIR/tree-sitter-java-linux-x86_64.so" "$SOURCES/objects/java.o"
    gcc -shared -o "$SCRIPT_DIR/tree-sitter-go-linux-x86_64.so" "$SOURCES/objects/go.o"
    gcc -shared -o "$SCRIPT_DIR/tree-sitter-python-linux-x86_64.so" "$SOURCES/objects/python.o" "$SOURCES/objects/python-scanner.o"
    aarch64-linux-gnu-gcc -shared -o "$SCRIPT_DIR/tree-sitter-java-linux-arm64.so" "$SOURCES/objects/java-arm.o"
    aarch64-linux-gnu-gcc -shared -o "$SCRIPT_DIR/tree-sitter-go-linux-arm64.so" "$SOURCES/objects/go-arm.o"
    aarch64-linux-gnu-gcc -shared -o "$SCRIPT_DIR/tree-sitter-python-linux-arm64.so" "$SOURCES/objects/python-arm.o" "$SOURCES/objects/python-scanner-arm.o"

    echo "Done."
else
    echo "Unsupported operating system: $OS"
    exit 1
fi
