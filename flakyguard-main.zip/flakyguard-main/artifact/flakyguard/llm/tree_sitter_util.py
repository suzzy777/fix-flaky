from __future__ import annotations

import operator
import os
import platform
import re
from typing import TYPE_CHECKING, Literal

from typing_extensions import assert_never

if TYPE_CHECKING:
    from collections.abc import Callable, Collection, Container

from collections import defaultdict
from ctypes import c_void_p, cdll

import tree_sitter as ts

from flakyguard.definitions.language import Language
from .location import Position, Range


COMMENT_NODE_TYPES: dict[Language, list[str]] = {
    "java": ["block_comment", "line_comment"],
    "swift": ["multiline_comment", "comment"],
    "go": ["comment"],
    "python": ["comment"],
    "tsx": ["comment"],
    "typescript": ["comment"],
    "yaml": ["comment"],
    "thrift": ["comment"],
}

IMPORT_NODE_TYPES: dict[Language, list[str]] = {
    "java": ["import_declaration"],
    "go": ["import_declaration"],
    "python": [
        "import_statement",
        "future_import_statement",
        "import_from_statement",
    ],
    "swift": ["import_declaration"],
    "typescript": ["import_statement", "import_alias"],
    "tsx": ["import_statement", "import_alias"],
    "yaml": [],
}

# Function-like nodes in supported languages
FUNCTION_DECLARATION_NODE_TYPES: dict[Language, list[str]] = {
    "java": ["method_declaration", "constructor_declaration"],
    "swift": ["function_declaration", "init_declaration"],
    "go": ["function_declaration", "method_declaration"],
    "python": ["function_definition"],
    "typescript": ["method_definition", "function_declaration", "generator_function_declaration"],
    "tsx": ["method_definition", "function_declaration", "generator_function_declaration"],
    "yaml": [],
    "thrift": ["function_definition"],
}

# Name of the node type for function body
FUNCTION_BODY_NODE_TYPES: dict[Language, str] = {
    "java": "body",
    "swift": "function_body",
    "go": "body",
    "python": "body",
    "typescript": "body",
    "tsx": "body",
    "yaml": "",
}

CONSTANT_DECLARATION_NODE_TYPES: dict[Language, list[str]] = {
    "java": ["constant_declaration"],
}






def create_parser(language: Language) -> tuple[ts.Parser, ts.Language]:
    """Create a tree-sitter parser and language constructs for further uses."""
    os_name = platform.system()
    arch = platform.machine()

    # We compile our own tree-sitter-languages library for each platform, as the open-source
    # community does not provide pre-compiled binaries.
    language_file = ""
    if os_name == "Linux":
        if arch == "x86_64":
            language_file = f"tree-sitter-{language}-linux-x86_64.so"
        elif arch in ["aarch64", "arm64"]:
            language_file = f"tree-sitter-{language}-linux-arm64.so"
        else:
            raise NotImplementedError(f"Unsupported architecture: {arch}")
    elif os_name == "Darwin":
        language_file = f"tree-sitter-{language}-darwin-universal.so"
    else:
        raise NotImplementedError(f"Unsupported OS: {os_name}")

    # Load the language dynamic library and get the pointer to the language implementation.
    path = f"{os.path.dirname(os.path.abspath(__file__))}/tree-sitter-grammars/{language_file}"
    lib = cdll.LoadLibrary(path)
    language_function: Callable[[], int] = getattr(lib, f"tree_sitter_{language}")
    language_function.restype = c_void_p  # pyright: ignore[reportFunctionMemberAccess]
    language_ptr = language_function()

    # Construct the language via the pointer.
    ts_language = ts.Language(language_ptr, language)
    parser = ts.Parser()
    parser.set_language(ts_language)
    return parser, ts_language


def tree_sitter_position(tree_sitter_position: tuple[int, int]) -> Position:
    return Position(
        line=tree_sitter_position[0] + 1,
        column=tree_sitter_position[1] + 1,
    )


def find_nodes(
    start_node: ts.Node,
    predicate: Callable[[ts.Node], bool],
    at_lines: Collection[int] | None = None,
) -> list[ts.Node]:
    """Recursively finds all nodes in the subtree(start_node) that match the given predicate and
    start at any of the given 1-indexed lines (if specified)."""
    result: list[ts.Node] = []

    def recurse(node: ts.Node):
        if predicate(node) and is_node_at_lines(node, at_lines):
            result.append(node)
        for child in node.children:
            recurse(child)

    recurse(start_node)
    return result


def find_nodes_by_type(
    start_node: ts.Node,
    node_types: Container[str],
    at_lines: Collection[int] | None = None,
) -> list[ts.Node]:
    """Recursively finds all nodes in the subtree(start_node) that match the given type and
    start at any of the given 1-indexed lines (if specified).

    For Java's (class|method)_declaration nodes the line is matched at the identifier
    node instead of the declaration node since it can start with modifiers (annotations
    visibility modifiers etc.) that are at different lines.
    """
    return find_nodes(start_node, lambda n: n.type in node_types, at_lines=at_lines)


def is_node_at_lines(n: ts.Node, at_lines: Collection[int] | None) -> bool:
    """Return True if the node is at specific line numbers with special handling
    for nodes where the actual start lines in tree-sitter are slightly different from
    other systems (e.g., ErrorProne) such as Java's (class|method)_declaration nodes."""
    if not at_lines:
        return True

    check_node: ts.Node = n
    # ErrorProne reports the error for the classes/methods at the identifier line:
    # @Test        // L1
    # public void  // L2
    # foo () {}    // L3
    # EP will report an error at L3. However, method_declaration nodes captured by
    # tree-sitter actually start at L1 (where the annotations are "modifiers" and are
    # children of the method declaration node). We should handle such mismatches
    # gracefully such that the callers do not have to.
    if n.type in ("class_declaration", "method_declaration"):
        identifier = n.child_by_field_name("name")
        if identifier:
            check_node = identifier

    # Tree-sitter uses 0-indexed line numbers.
    return check_node.start_point[0] + 1 in at_lines


def is_comment(node: ts.Node, language: Language) -> bool:
    """Return True if the node is a comment."""
    return node.type in COMMENT_NODE_TYPES[language]









def find_first_parent_of_type(node: ts.Node, node_type: Container[str]) -> ts.Node | None:
    """Returns the first found parent of the node that matches any `node_type`. Returns `None` if not the parent is not found."""
    n = node
    while n.parent:
        n = n.parent
        if n.type in node_type:
            return n

    return None








def find_first_immediate_child_by_type(node: ts.Node, node_type: str) -> ts.Node | None:
    """Finds the first immediate child of a node with the given type. This function *does not* recursively traverse the node's children."""
    return next((child for child in node.children if child.type == node_type), None)





def get_method_name(node: ts.Node, language: Literal["java", "swift", "go"]) -> str | None:
    """Returns the name of the method of the node."""
    name_node = get_method_name_node(node, language)
    return name_node.text.decode() if name_node and name_node.text else None


def get_method_name_node(node: ts.Node, language: Literal["java", "swift", "go"]) -> ts.Node | None:
    """Returns the ts.node corresponding to the method name."""
    if node.type in FUNCTION_DECLARATION_NODE_TYPES[language]:
        if language == "java" or language == "swift" or language == "go":
            name = node.child_by_field_name("name")
            if name:
                return name
        else:
            assert_never(language)








def find_next_sibling_of_type(node: ts.Node, node_types: list[str]) -> ts.Node | None:
    cur = node.next_sibling
    while cur:
        if cur.type in node_types:
            return cur
        cur = cur.next_sibling






def check_node_intersection_with_ranges(node: ts.Node, ranges: list[Range]) -> bool:
    node_range = Range(tree_sitter_position(node.start_point), tree_sitter_position(node.end_point))
    return any(node_range.intersect(affected_range) for affected_range in ranges)




def label_tree_nodes(tree: ts.Tree, label_node_fn: Callable[[ts.Node], bool]) -> dict[ts.Node, bool]:
    """
    Traverse a syntax tree in-order and determine the label of each node based on a given function.
    This function applies `label_node_fn` to each node to determine its label. If a node is labeled as False,
    then all of its descendant nodes are automatically labeled as False without further traversal.
    """
    cursor: ts.TreeCursor = tree.walk()
    # All nodes are by default False
    labels: dict[ts.Node, bool] = defaultdict(lambda: False)

    while True:
        node: ts.Node = cursor.node
        labels[node] = label_node_fn(node)

        # If the node is labelled as False, then all of its children are also false
        if labels[node] and cursor.goto_first_child():
            continue
        while not cursor.goto_next_sibling():
            if not cursor.goto_parent():
                return labels
