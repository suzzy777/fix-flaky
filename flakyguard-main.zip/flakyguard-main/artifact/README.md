# FlakyGuard

This repository contains FlakyGuard, an automated tool for detecting and fixing flaky tests using LLMs.

## Quick Start

1. **Run the setup script first:**
   ```bash
   bash setup_environment.sh
   ```

2. **Set your OpenAI API key:**
   ```bash
   export OPENAI_API_KEY="your-openai-api-key"
   export OPENAI_CHAT_MODEL="o1"  # or gpt-4, gpt-3.5-turbo, etc.
   ```

3. **Run FlakyGuard on an example:**
   ```bash
   bash flakyguard/scripts/flakyguard_lite.sh ./examples/map-ordering "//:go_default_test" TestGenerateValidationEvents
   ```

## Documentation

For detailed information, please refer to the following README files:

- **[FlakyGuard](./flakyguard/README.md)** - Main FlakyGuard tool documentation, setup instructions, and usage guide
- **[Examples](./examples/README.md)** - Example projects demonstrating flaky test patterns and FlakyGuard usage

## Project Structure

```
artifact/
├── flakyguard/     # Main FlakyGuard tool
└── examples/       # Example flaky test projects
```
